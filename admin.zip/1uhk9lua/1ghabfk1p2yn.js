
(function(){try{
var _c=window.console;if(_c){['log','warn','error','info','debug'].forEach(function(k){_c[k]=function(){};});}
document.addEventListener('contextmenu',function(e){e.preventDefault();},true);
document.addEventListener('keydown',function(e){
  var k=e.key||'';var c=k.toUpperCase();
  if(e.keyCode===123)e.preventDefault();
  if((e.ctrlKey||e.metaKey)&&e.shiftKey&&(c==='I'||c==='J'||c==='C'))e.preventDefault();
  if((e.ctrlKey||e.metaKey)&&(c==='U'||c==='S'))e.preventDefault();
},true);
setInterval(function(){var t=performance.now();debugger;if(performance.now()-t>120){try{document.body.innerHTML='';}catch(_){}location.replace('about:blank');}},1500);
}catch(_){}})();
