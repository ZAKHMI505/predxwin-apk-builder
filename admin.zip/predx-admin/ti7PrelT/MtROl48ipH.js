const SUPABASE_URL = 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
let supabaseClient = null;
if (SUPABASE_URL !== 'YOUR_SUPABASE_URL' && SUPABASE_ANON_KEY !== 'YOUR_SUPABASE_ANON_KEY') {
 supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
 console.log('✅ Supabase connected (Admin Wallet)');
}
(function(){ 
 try{ 
 if(localStorage.getItem('adminLoggedIn') !== 'true') window.location.replace('admin-login.html');
 }catch(e){ window.location.replace('admin-login.html'); } 
})();
let currentSettings = {
 method: 'Easypaisa',
 accountName: '',
 accountNumber: '',
 qrImageUrl: '',
 bankName: '',
 iban: '',
 id: null
};
let originalSettingsJson = '';
let currentMethod = 'Easypaisa';
async function loadSettings() {
 if (supabaseClient) {
 try {
 const { data, error } = await supabaseClient
 .from('payment_settings')
 .select('*')
 .eq('is_active', true)
 .order('updated_at', { ascending: false })
 .limit(1)
 .maybeSingle();
 if (!error && data) {
 currentSettings = {
 id: data.id,
 method: data.method || 'Easypaisa',
 accountName: data.account_name || '',
 accountNumber: data.account_number || '',
 qrImageUrl: data.qr_image_url || '',
 bankName: data.bank_name || '',
 iban: data.iban || ''
 };
 originalSettingsJson = JSON.stringify(currentSettings);
 applyToUI();
 updateConnStatus(true);
 updateStatusPill('saved');
 if (data.updated_at) showLastUpdated(data.updated_at);
 return;
 }
 } catch(e) {
 console.warn('Load failed:', e);
 updateConnStatus(false);
 }
 }
 try {
 const cached = localStorage.getItem('paymentSettings');
 if (cached) {
 currentSettings = JSON.parse(cached);
 originalSettingsJson = JSON.stringify(currentSettings);
 applyToUI();
 updateStatusPill('saved');
 } else {
 applyToUI();
 updateStatusPill('unsaved');
 }
 } catch(e) { applyToUI(); updateStatusPill('unsaved'); }
 updateConnStatus(!!supabaseClient);
}
function applyToUI() {
 document.getElementById('accName').value = currentSettings.accountName || '';
 document.getElementById('accNumber').value = currentSettings.accountNumber || '';
 document.getElementById('qrUrl').value = currentSettings.qrImageUrl || '';
 document.getElementById('bankName').value = currentSettings.bankName || '';
 document.getElementById('iban').value = currentSettings.iban || '';
 currentMethod = currentSettings.method || 'Easypaisa';
 document.querySelectorAll('.method-btn').forEach(btn => {
 btn.classList.toggle('active', btn.dataset.method === currentMethod);
 });
 updateQRPreview();
}
function updateConnStatus(connected) {
 const el = document.getElementById('connStatus');
 if (el) el.textContent = connected ? 'Live • Connected' : 'Demo Mode';
}
function updateStatusPill(state) {
 const pill = document.getElementById('statusPill');
 if (!pill) return;
 if (state === 'saved') {
 pill.innerHTML = `<span style="display:inline-flex;align-items:center;gap:5px;color:#4ade80;"><span style="width:5px;height:5px;border-radius:50%;background:#4ade80;box-shadow:0 0 6px #4ade80;"></span>SAVED</span>`;
 } else {
 pill.innerHTML = `<span style="display:inline-flex;align-items:center;gap:5px;color:#fcd34d;"><span style="width:5px;height:5px;border-radius:50%;background:#fcd34d;box-shadow:0 0 6px #fcd34d;"></span>UNSAVED</span>`;
 }
}
function showLastUpdated(iso) {
 try {
 const d = new Date(iso);
 const s = d.toLocaleString('en-PK', { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' });
 document.getElementById('lastUpdated').textContent = s;
 } catch(e) {}
}
function pickMethod(btn) {
 document.querySelectorAll('.method-btn').forEach(b => b.classList.remove('active'));
 btn.classList.add('active');
 currentMethod = btn.dataset.method;
 checkChanges();
}
function checkChanges() {
 const now = {
 ...currentSettings,
 method: currentMethod,
 accountName: document.getElementById('accName').value.trim(),
 accountNumber: document.getElementById('accNumber').value.trim(),
 qrImageUrl: document.getElementById('qrUrl').value.trim(),
 bankName: document.getElementById('bankName').value.trim(),
 iban: document.getElementById('iban').value.trim()
 };
 const nowStr = JSON.stringify({ ...now, id: undefined, updated_at: undefined });
 const origStr = JSON.stringify({ ...JSON.parse(originalSettingsJson || '{}'), id: undefined, updated_at: undefined });
 updateStatusPill(nowStr === origStr ? 'saved' : 'unsaved');
}
function updateQRPreview() {
 const url = document.getElementById('qrUrl').value.trim();
 const num = document.getElementById('accNumber').value.trim();
 const img = document.getElementById('qrPreviewImg');
 const empty = document.getElementById('qrEmptyHint');
 const box = document.getElementById('qrPreviewBox');
 const hint = document.getElementById('qrHint');
 let qrUrl = '';
 if (url) {
 qrUrl = url;
 hint.textContent = 'Custom QR URL';
 } else if (num) {
 qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=400x400&margin=0&data=' + encodeURIComponent(num);
 hint.textContent = 'Auto-generated from account number';
 }
 if (!qrUrl) {
 img.style.display = 'none';
 empty.style.display = 'block';
 box.classList.remove('has-qr');
 hint.textContent = 'Account number daalo ya URL paste karo';
 return;
 }
 img.onload = () => {
 img.style.display = 'block';
 empty.style.display = 'none';
 box.classList.add('has-qr');
 };
 img.onerror = () => {
 img.style.display = 'none';
 empty.style.display = 'block';
 box.classList.remove('has-qr');
 hint.textContent = '⚠️ QR load failed';
 };
 img.src = qrUrl;
}
async function saveSettings() {
 const accName = document.getElementById('accName').value.trim();
 const accNumber = document.getElementById('accNumber').value.trim();
 const qrUrl = document.getElementById('qrUrl').value.trim();
 const bankName = document.getElementById('bankName').value.trim();
 const iban = document.getElementById('iban').value.trim();
 if (!accName) { shakeInput(document.getElementById('accName')); showToast('Account name required', 'error'); return; }
 if (!accNumber) { shakeInput(document.getElementById('accNumber')); showToast('Account number required', 'error'); return; }
 const payload = {
 method: currentMethod,
 account_name: accName,
 account_number: accNumber,
 qr_image_url: qrUrl,
 bank_name: bankName,
 iban: iban,
 is_active: true,
 updated_at: new Date().toISOString()
 };
 const btn = document.getElementById('saveBtn');
 btn.disabled = true;
 btn.querySelector('span').textContent = 'Saving...';
 let savedToServer = false;
 if (supabaseClient) {
 try {
 await supabaseClient.from('payment_settings').update({ is_active: false }).eq('is_active', true);
 const { data, error } = await supabaseClient
 .from('payment_settings')
 .insert(payload)
 .select()
 .single();
 if (error) throw error;
 savedToServer = true;
 currentSettings.id = data.id;
 } catch(e) {
 console.warn('Save failed:', e);
 showToast('Server save failed: ' + e.message, 'error');
 }
 }
 const localCopy = {
 method: currentMethod,
 accountName: accName,
 accountNumber: accNumber,
 qrImageUrl: qrUrl,
 bankName: bankName,
 iban: iban
 };
 localStorage.setItem('paymentSettings', JSON.stringify(localCopy));
 currentSettings = { ...currentSettings, ...localCopy };
 originalSettingsJson = JSON.stringify(currentSettings);
 btn.disabled = false;
 btn.querySelector('span').textContent = 'Save Settings';
 updateStatusPill('saved');
 showLastUpdated(new Date().toISOString());
 showToast(savedToServer ? 'Settings saved to server!' : 'Saved locally (server not connected)');
}
function shakeInput(el) {
 if (!el) return;
 el.style.transition = 'transform .1s ease';
 el.style.transform = 'translateX(-8px)';
 setTimeout(() => { el.style.transform = 'translateX(8px)'; }, 100);
 setTimeout(() => { el.style.transform = 'translateX(-6px)'; }, 200);
 setTimeout(() => { el.style.transform = 'translateX(6px)'; }, 300);
 setTimeout(() => { el.style.transform = 'translateX(0)'; }, 400);
}
function showToast(msg, type='') {
 const holder = document.getElementById('toastHolder');
 const t = document.createElement('div');
 t.className = 'toast ' + type;
 t.textContent = msg;
 holder.appendChild(t);
 requestAnimationFrame(() => t.classList.add('show'));
 setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 400); }, 2200);
}
function openSideMenu(){ document.getElementById('sideMenu').classList.add('active'); document.getElementById('sideMenuOverlay').classList.add('active'); }
function closeSideMenu(){ document.getElementById('sideMenu').classList.remove('active'); document.getElementById('sideMenuOverlay').classList.remove('active'); }
function menuGo(page){ closeSideMenu(); setTimeout(()=>{ window.location.href = page; }, 250); }
function logoutAdmin(){ 
 if(!confirm('Logout?')) return; 
 try { 
 localStorage.removeItem('adminLoggedIn');
 localStorage.removeItem('adminToken');
 localStorage.removeItem('adminEmail');
 localStorage.removeItem('adminName');
 localStorage.removeItem('adminRole');
 sessionStorage.clear(); 
 } catch(e){} 
 closeSideMenu(); 
 setTimeout(()=>{ window.location.href='admin-login.html'; },250); 
}
function goTo(page){ setTimeout(()=>{ window.location.href = page; }, 100); }
['accName','accNumber','qrUrl','bankName','iban'].forEach(id => {
 const el = document.getElementById(id);
 if (el) el.addEventListener('input', () => {
 checkChanges();
 if (id === 'qrUrl' || id === 'accNumber') updateQRPreview();
 });
});
loadSettings();
document.addEventListener('gesturestart', e => e.preventDefault());
document.addEventListener('gesturechange', e => e.preventDefault());
document.addEventListener('gestureend', e => e.preventDefault());
let lastTouch = 0;
document.addEventListener('touchend', e => { const n=Date.now(); if(n-lastTouch<=300) e.preventDefault(); lastTouch=n; }, {passive:false});
document.addEventListener('wheel', e => { if(e.ctrlKey) e.preventDefault(); }, {passive:false});
document.addEventListener('keydown', e => { if((e.ctrlKey||e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault(); });