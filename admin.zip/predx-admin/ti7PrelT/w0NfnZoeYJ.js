window.ADMIN_APP_MODE = {
 DEMO_MODE: true 
 };
 window.ADMIN_API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 getPendingWithdraws: "/admin/withdraws/pending",
 approveWithdraw: "/admin/withdraws/:id/approve",
 rejectWithdraw: "/admin/withdraws/:id/reject"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const token = localStorage.getItem('adminToken');
 if (token) h["X-Admin-Token"] = token;
 return h;
 }
 };
 window.ADMIN_API = {
 async call(endpoint, method = "GET", body = null) {
 if (!ADMIN_API_CONFIG.baseURL) return { success: false, error: "Admin server not configured" };
 const url = ADMIN_API_CONFIG.baseURL + endpoint;
 const options = { method, headers: ADMIN_API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) return { success: false, error: data.message || data.error || "Request failed", data };
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); },
 put(ep, body) { return this.call(ep, "PUT", body); }
 };
(function checkAuth() {
 try {
 const logged = localStorage.getItem('adminLoggedIn');
 const demo = window.ADMIN_APP_MODE.DEMO_MODE;
 if (demo) {
 if (logged !== 'true') {
 localStorage.setItem('adminLoggedIn', 'true');
 localStorage.setItem('adminEmail', 'demo-admin@predxprofit.pk');
 localStorage.setItem('adminName', 'Demo Admin');
 }
 return;
 }
 if (logged !== 'true') window.location.replace('admin-login.html');
 } catch(e) { window.location.replace('admin-login.html'); }
 })();
 const PX_ICON = 'https://premium-host.ct.ws//uploads/1791979416.png';
 const DEMO_REQUESTS = [
 { id:'WD1001', uid:'PX-1002', name:'Sara Malik', amount:1360, method:'Easypaisa', tid:'1008850', date:'14 Oct 2026', time:'06:45 PM',
 accountName:'Sara Malik', accountNumber:'03011234567',
 dashboard:6000, invested:6000, dailyProfit:120, remaining:4640, activePlans:2, totalEarned:6400, totalWithdrawn:2400,
 adminSS:'' },
 { id:'WD1002', uid:'PX-1010', name:'Maryam Iqbal', amount:1200, method:'Easypaisa', tid:'1000510', date:'11 Oct 2026', time:'01:15 PM',
 accountName:'Maryam Iqbal', accountNumber:'03091234567',
 dashboard:15000, invested:15000, dailyProfit:300, remaining:13800, activePlans:3, totalEarned:19200, totalWithdrawn:5600,
 adminSS:'' },
 { id:'WD1003', uid:'PX-1005', name:'Usman Tariq', amount:2500, method:'JazzCash', tid:'1004998', date:'14 Oct 2026', time:'03:20 PM',
 accountName:'Usman Tariq', accountNumber:'03041234567',
 dashboard:18000, invested:18000, dailyProfit:360, remaining:16640, activePlans:4, totalEarned:21000, totalWithdrawn:6800,
 adminSS:'' }
 ];
 let REQUESTS = [];
 let pendingRejectIdx = null;
 let currentDetailIdx = null;
 let adminScreenshotData = '';
 async function loadRequests() {
 if (window.ADMIN_API_CONFIG.baseURL && !window.ADMIN_APP_MODE.DEMO_MODE) {
 try {
 const res = await window.ADMIN_API.get(ADMIN_API_CONFIG.endpoints.getPendingWithdraws);
 if (res.success) {
 const list = res.data.withdraws || res.data.requests || res.data || [];
 REQUESTS = list.map(normalizeRequest);
 render();
 return;
 }
 } catch(e) { console.warn('API pending failed, using local'); }
 }
 try {
 const saved = localStorage.getItem('pendingWithdraws');
 if (saved) {
 REQUESTS = JSON.parse(saved).map(normalizeRequest);
 } else {
 REQUESTS = DEMO_REQUESTS.map(normalizeRequest);
 saveRequestsToLocal();
 }
 } catch(e) { REQUESTS = []; }
 render();
 }
 function normalizeRequest(r) {
 return {
 id: r.id || ('WD' + Date.now() + Math.random()),
 uid: r.uid || 'PX-0000',
 name: r.name || 'User',
 amount: Number(r.amount || r.withdrawAmount || 0),
 method: r.method || r.paymentMethod || 'Easypaisa',
 tid: r.tid || r.transactionId || '—',
 date: r.date || '—',
 time: r.time || '—',
 accountName: r.accountName || r.name || 'User',
 accountNumber: r.accountNumber || r.number || '—',
 dashboard: Number(r.dashboard || r.totalDashboard || 0),
 invested: Number(r.invested || r.totalInvested || 0),
 dailyProfit: Number(r.dailyProfit || r.daily || 0),
 remaining: Number(r.remaining || r.remainingBalance || 0),
 activePlans: Number(r.activePlans || 0),
 totalEarned: Number(r.totalEarned || 0),
 totalWithdrawn: Number(r.totalWithdrawn || 0),
 adminSS: r.adminSS || ''
 };
 }
 function saveRequestsToLocal() {
 try { localStorage.setItem('pendingWithdraws', JSON.stringify(REQUESTS)); }
 catch(e) {}
 }
 function render(){
 const list = document.getElementById('wdList');
 const countEl = document.getElementById('pendingCount');
 if(!list) return;
 countEl.textContent = REQUESTS.length + ' REQ';
 document.getElementById('statPending').textContent = REQUESTS.length;
 const totalAmt = REQUESTS.reduce((s,r)=>s+r.amount, 0);
 document.getElementById('statAmount').textContent = 'Rs ' + totalAmt.toLocaleString('en-IN');
 if(REQUESTS.length === 0){
 list.innerHTML = `
 <div class="empty-state">
 <div class="empty-icon"><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg></div>
 <div class="empty-title">All Caught Up!</div>
 <div class="empty-desc">No pending withdraw requests</div>
 </div>`;
 return;
 }
 list.innerHTML = REQUESTS.map((r, idx) => `
 <div class="wd-item" onclick="openDetail(${idx})">
 <div class="wd-avatar"><img src="${PX_ICON}" alt="PX"></div>
 <div class="wd-info">
 <div class="wd-name">${escapeHtml(r.name)}</div>
 <div class="wd-uid">
 <svg viewBox="0 0 24 24"><path d="M4 7V4h16v3"/><path d="M9 20h6"/><path d="M12 4v16"/></svg>
 <span>${r.uid} • ${r.method}</span>
 </div>
 </div>
 <div class="wd-right">
 <div class="wd-amt">Rs ${r.amount.toLocaleString('en-IN')}</div>
 <span class="wd-status"><span class="sdot"></span>Pending</span>
 </div>
 </div>
 `).join('');
 }
 function openDetail(idx){
 const r = REQUESTS[idx];
 if(!r) return;
 currentDetailIdx = idx;
 adminScreenshotData = r.adminSS || '';
 document.getElementById('ddScroll').innerHTML = `
 <div class="dd-hero">
 <div class="dd-avatar"><img src="${PX_ICON}" alt="PX"></div>
 <div class="dd-name">${escapeHtml(r.name)}</div>
 <div class="dd-uid">
 <svg viewBox="0 0 24 24"><path d="M4 7V4h16v3"/><path d="M9 20h6"/><path d="M12 4v16"/></svg>
 ${r.uid}
 </div>
 <div><span class="dd-status-pill"><span class="sdot"></span>Pending Withdrawal</span></div>
 </div>
 <div class="dd-amount-box">
 <div class="dd-amount-lbl">Withdraw Amount</div>
 <div class="dd-amount-val">Rs ${r.amount.toLocaleString('en-IN')}</div>
 </div>
 <div class="dd-account-card">
 <div class="dd-account-head">
 <svg viewBox="0 0 24 24"><path d="M3 21h18M5 21V7l7-4 7 4v14M9 21v-6h6v6"/></svg>
 <span>Send Payment To</span>
 </div>
 <div class="dd-account-row">
 <span class="dd-account-lbl">Method</span>
 <span class="dd-account-val">${escapeHtml(r.method)}</span>
 </div>
 <div class="dd-account-row">
 <span class="dd-account-lbl">Account Name</span>
 <span class="dd-account-val">${escapeHtml(r.accountName)}</span>
 </div>
 <div class="dd-account-row">
 <span class="dd-account-lbl">Account Number</span>
 <span class="dd-account-val mono">${escapeHtml(r.accountNumber)}</span>
 <button class="dd-copy-btn" onclick="copyAcct('${escapeHtml(r.accountNumber)}')">
 <svg viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
 </button>
 </div>
 </div>
 <div class="dd-section-lbl">
 <svg viewBox="0 0 24 24" style="width:11px;height:11px;stroke:#f87171;stroke-width:2.8;fill:none;stroke-linecap:round;stroke-linejoin:round;"><rect x="3" y="4" width="18" height="16" rx="2"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
 Balance Details
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><rect x="2" y="6" width="20" height="12" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>Dashboard</span>
 <span class="dd-row-val green">Rs ${r.dashboard.toLocaleString('en-IN')}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>Invested</span>
 <span class="dd-row-val blue">Rs ${r.invested.toLocaleString('en-IN')}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>Daily Profit</span>
 <span class="dd-row-val gold">Rs ${r.dailyProfit.toLocaleString('en-IN')}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>Remaining</span>
 <span class="dd-row-val green">Rs ${r.remaining.toLocaleString('en-IN')}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>Total Earned</span>
 <span class="dd-row-val green">Rs ${r.totalEarned.toLocaleString('en-IN')}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>Total Withdrawn</span>
 <span class="dd-row-val gold">Rs ${r.totalWithdrawn.toLocaleString('en-IN')}</span>
 </div>
 <div class="dd-section-lbl">
 <svg viewBox="0 0 24 24" style="width:11px;height:11px;stroke:#f87171;stroke-width:2.8;fill:none;stroke-linecap:round;stroke-linejoin:round;"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
 Request Details
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><line x1="4" y1="9" x2="20" y2="9"/><line x1="4" y1="15" x2="20" y2="15"/><line x1="10" y1="3" x2="8" y2="21"/><line x1="16" y1="3" x2="14" y2="21"/></svg>TID</span>
 <span class="dd-row-val mono">${escapeHtml(r.tid)}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>Date</span>
 <span class="dd-row-val blue">${escapeHtml(r.date)} • ${escapeHtml(r.time)}</span>
 </div>
 <div class="dd-section-lbl">
 <svg viewBox="0 0 24 24" style="width:11px;height:11px;stroke:#4ade80;stroke-width:2.8;fill:none;stroke-linecap:round;stroke-linejoin:round;"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
 Upload Payment Proof
 </div>
 <div class="dd-upload-section">
 <div class="dd-upload-head">
 <svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
 <span>Attach Screenshot</span>
 </div>
 <button class="dd-upload-btn" onclick="document.getElementById('adminSSInput').click()">
 <svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
 <span id="uploadBtnText">${r.adminSS ? 'Change Screenshot' : 'Choose Screenshot'}</span>
 </button>
 <div class="dd-upload-preview ${r.adminSS ? 'show' : ''}" id="uploadPreview">
 <img id="uploadPreviewImg" src="${r.adminSS || ''}" alt="Payment Proof" onclick="viewAdminSS()">
 <div class="filename" id="uploadFilename">${r.adminSS ? '✓ Screenshot Uploaded' : ''}</div>
 </div>
 </div>
 <div class="dd-actions">
 <button class="dd-btn reject" onclick="openRejectFromDetail()">
 <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>Reject
 </button>
 <button class="dd-btn accept" onclick="approveFromDetail()">
 <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>Accept
 </button>
 </div>
 `;
 document.getElementById('detailOverlay').classList.add('active');
 }
 function closeDetail(){ document.getElementById('detailOverlay').classList.remove('active'); currentDetailIdx = null; }
 function closeDetailOutside(e){ if(e.target.id==='detailOverlay') closeDetail(); }
 function copyAcct(num){
 if(navigator.clipboard && window.isSecureContext){
 navigator.clipboard.writeText(num).then(()=>showToast('Account number copied!')).catch(()=>legacyCopy(num));
 } else legacyCopy(num);
 }
 function legacyCopy(text){
 const ta = document.createElement('textarea');
 ta.value = text; ta.style.position='fixed'; ta.style.opacity='0';
 document.body.appendChild(ta); ta.select();
 try { document.execCommand('copy'); showToast('Account number copied!'); } catch(e) {}
 document.body.removeChild(ta);
 }
 function handleAdminSS(input){
 const file = input.files && input.files[0];
 if(!file) return;
 if(file.size > 5 * 1024 * 1024){
 showToast('Image too large (max 5MB)', 'error');
 input.value = '';
 return;
 }
 const reader = new FileReader();
 reader.onload = e => {
 adminScreenshotData = e.target.result;
 if(currentDetailIdx !== null){
 REQUESTS[currentDetailIdx].adminSS = adminScreenshotData;
 saveRequestsToLocal();
 }
 const preview = document.getElementById('uploadPreview');
 const previewImg = document.getElementById('uploadPreviewImg');
 const filename = document.getElementById('uploadFilename');
 const btnTxt = document.getElementById('uploadBtnText');
 if(previewImg) previewImg.src = adminScreenshotData;
 if(preview) preview.classList.add('show');
 if(filename) filename.textContent = '✓ ' + file.name;
 if(btnTxt) btnTxt.textContent = 'Change Screenshot';
 showToast('Screenshot attached!');
 };
 reader.readAsDataURL(file);
 input.value = '';
 }
 function viewAdminSS(){
 if(!adminScreenshotData) return;
 document.getElementById('ssViewerImg').src = adminScreenshotData;
 document.getElementById('ssViewer').classList.add('active');
 }
 function closeSSViewer(){ document.getElementById('ssViewer').classList.remove('active'); }
 function approveFromDetail(){
 if(currentDetailIdx === null) return;
 approve(currentDetailIdx);
 }
 function openRejectFromDetail(){
 if(currentDetailIdx === null) return;
 openReject(currentDetailIdx);
 }
 async function approve(idx){
 const r = REQUESTS[idx];
 if(!r) return;
 if(!r.adminSS){
 if(!confirm('You have not uploaded payment screenshot. Continue anyway?')) return;
 } else {
 if(!confirm('Accept this withdrawal of Rs ' + r.amount.toLocaleString('en-IN') + ' from ' + r.name + '?\nScreenshot attached ✓')) return;
 }
 if (window.ADMIN_API_CONFIG.baseURL && !window.ADMIN_APP_MODE.DEMO_MODE) {
 try {
 const ep = ADMIN_API_CONFIG.endpoints.approveWithdraw.replace(':id', r.id);
 const res = await window.ADMIN_API.put(ep, { screenshot: r.adminSS || '' });
 if (!res.success) {
 showToast(res.error || 'Failed to approve', 'error');
 return;
 }
 } catch(e) {
 showToast('Network error', 'error');
 return;
 }
 }
 updateUserWithdrawOnApprove(r);
 updateAdminStatsOnApprove(r);
 addToWithdrawHistory(r, 'success');
 showSuccessDialog(r, 'accept');
 REQUESTS.splice(idx, 1);
 saveRequestsToLocal();
 closeDetail();
 render();
 }
 function updateUserWithdrawOnApprove(r){
 try {
 const allUsers = JSON.parse(localStorage.getItem('allUsers') || '[]');
 const target = allUsers.find(u => u.uid === r.uid);
 if (target) {
 target.totalWithdrawn = (target.totalWithdrawn || 0) + r.amount;
 target.withdrawable = Math.max(0, (target.withdrawable || 0) - r.amount);
 target.withdraws = target.withdraws || [];
 target.withdraws.unshift({
 id: 'WD' + Date.now(),
 amount: r.amount,
 method: r.method,
 accountNumber: r.accountNumber,
 tid: r.tid,
 status: 'success',
 adminSS: r.adminSS || '',
 approvedAt: new Date().toISOString()
 });
 target.transactions = target.transactions || [];
 target.transactions.unshift({
 id: 'WD' + Date.now(),
 type: 'withdrawal',
 amount: r.amount,
 method: r.method,
 status: 'success',
 approvedAt: new Date().toISOString()
 });
 localStorage.setItem('allUsers', JSON.stringify(allUsers));
 }
 const loggedUser = JSON.parse(localStorage.getItem('loggedUser') || '{}');
 if (loggedUser && loggedUser.uid === r.uid) {
 loggedUser.totalWithdrawn = (loggedUser.totalWithdrawn || 0) + r.amount;
 loggedUser.withdrawable = Math.max(0, (loggedUser.withdrawable || 0) - r.amount);
 loggedUser.withdraws = loggedUser.withdraws || [];
 loggedUser.withdraws.unshift({
 id: 'WD' + Date.now(),
 amount: r.amount,
 method: r.method,
 accountNumber: r.accountNumber,
 tid: r.tid,
 status: 'success',
 adminSS: r.adminSS || '',
 approvedAt: new Date().toISOString()
 });
 loggedUser.transactions = loggedUser.transactions || [];
 loggedUser.transactions.unshift({
 id: 'WD' + Date.now(),
 type: 'withdrawal',
 amount: r.amount,
 method: r.method,
 status: 'success',
 approvedAt: new Date().toISOString()
 });
 localStorage.setItem('loggedUser', JSON.stringify(loggedUser));
 }
 const notifs = JSON.parse(localStorage.getItem('userNotifications') || '[]');
 notifs.unshift({
 uid: r.uid,
 title: 'Withdrawal Approved ✅',
 message: 'Rs ' + r.amount.toLocaleString('en-IN') + ' sent to your ' + r.method + ' account (' + r.accountNumber + '). Check your account!',
 read: false,
 createdAt: new Date().toISOString()
 });
 localStorage.setItem('userNotifications', JSON.stringify(notifs));
 } catch(e) { console.warn('Local user update failed:', e); }
 }
 function updateAdminStatsOnApprove(r){
 try {
 const stats = JSON.parse(localStorage.getItem('adminStats') || '{}');
 stats.totalWithdrawals = (stats.totalWithdrawals || 0) + r.amount;
 stats.todayWithdraw = (stats.todayWithdraw || 0) + r.amount;
 stats.todayWithdrawCount = (stats.todayWithdrawCount || 0) + 1;
 localStorage.setItem('adminStats', JSON.stringify(stats));
 } catch(e) {}
 }
 function addToWithdrawHistory(r, status, reason){
 try {
 const history = JSON.parse(localStorage.getItem('withdrawHistory') || '[]');
 history.unshift({
 ...r,
 status: status,
 rejectReason: reason || '',
 approvedAt: status === 'success' ? new Date().toISOString() : null,
 rejectedAt: status === 'rejected' ? new Date().toISOString() : null
 });
 localStorage.setItem('withdrawHistory', JSON.stringify(history));
 } catch(e) {}
 }
 function openReject(idx){
 pendingRejectIdx = idx;
 document.getElementById('rejectReason').value = '';
 document.getElementById('rejectOverlay').classList.add('active');
 setTimeout(()=>{ document.getElementById('rejectReason').focus(); }, 250);
 }
 function closeReject(){ document.getElementById('rejectOverlay').classList.remove('active'); pendingRejectIdx = null; }
 function closeRejectOutside(e){ if(e.target.id==='rejectOverlay') closeReject(); }
 async function confirmReject(){
 const reason = (document.getElementById('rejectReason').value || '').trim();
 if(!reason){
 const el = document.getElementById('rejectReason');
 el.style.borderColor = '#dc2626';
 setTimeout(()=>{ el.style.borderColor=''; }, 1000);
 showToast('Please enter rejection reason', 'error');
 return;
 }
 if(pendingRejectIdx === null) return;
 const r = REQUESTS[pendingRejectIdx];
 if (window.ADMIN_API_CONFIG.baseURL && !window.ADMIN_APP_MODE.DEMO_MODE) {
 try {
 const ep = ADMIN_API_CONFIG.endpoints.rejectWithdraw.replace(':id', r.id);
 const res = await window.ADMIN_API.put(ep, { reason: reason });
 if (!res.success) {
 showToast(res.error || 'Failed to reject', 'error');
 return;
 }
 } catch(e) {
 showToast('Network error', 'error');
 return;
 }
 }
 try {
 const notifs = JSON.parse(localStorage.getItem('userNotifications') || '[]');
 notifs.unshift({
 uid: r.uid,
 title: 'Withdrawal Rejected ❌',
 message: 'Your withdrawal of Rs ' + r.amount.toLocaleString('en-IN') + ' was rejected. Reason: ' + reason,
 read: false,
 createdAt: new Date().toISOString()
 });
 localStorage.setItem('userNotifications', JSON.stringify(notifs));
 } catch(e) {}
 try {
 const allUsers = JSON.parse(localStorage.getItem('allUsers') || '[]');
 const target = allUsers.find(u => u.uid === r.uid);
 if (target) {
 target.withdraws = target.withdraws || [];
 target.withdraws.unshift({
 id: 'WD' + Date.now(),
 amount: r.amount,
 method: r.method,
 status: 'rejected',
 rejectReason: reason,
 rejectedAt: new Date().toISOString()
 });
 localStorage.setItem('allUsers', JSON.stringify(allUsers));
 }
 const loggedUser = JSON.parse(localStorage.getItem('loggedUser') || '{}');
 if (loggedUser && loggedUser.uid === r.uid) {
 loggedUser.withdraws = loggedUser.withdraws || [];
 loggedUser.withdraws.unshift({
 id: 'WD' + Date.now(),
 amount: r.amount,
 method: r.method,
 status: 'rejected',
 rejectReason: reason,
 rejectedAt: new Date().toISOString()
 });
 localStorage.setItem('loggedUser', JSON.stringify(loggedUser));
 }
 } catch(e) {}
 addToWithdrawHistory(r, 'rejected', reason);
 showSuccessDialog(r, 'reject');
 REQUESTS.splice(pendingRejectIdx, 1);
 saveRequestsToLocal();
 closeReject();
 closeDetail();
 render();
 }
 function showSuccessDialog(r, type){
 const icon = document.getElementById('suIcon');
 const title = document.getElementById('suTitle');
 const sub = document.getElementById('suSub');
 const info = document.getElementById('suInfo');
 if (type === 'accept') {
 icon.classList.remove('reject');
 title.classList.remove('reject');
 sub.classList.remove('reject');
 info.classList.remove('reject');
 title.textContent = 'Withdrawal Accepted!';
 sub.textContent = 'Payment sent to user';
 document.querySelectorAll('.su-info-row').forEach(el => el.classList.remove('reject'));
 document.querySelectorAll('.su-info-lbl').forEach(el => el.classList.remove('reject'));
 } else {
 icon.classList.add('reject');
 title.classList.add('reject');
 sub.classList.add('reject');
 info.classList.add('reject');
 title.textContent = 'Request Rejected';
 sub.textContent = 'User notified';
 document.querySelectorAll('.su-info-row').forEach(el => el.classList.add('reject'));
 document.querySelectorAll('.su-info-lbl').forEach(el => el.classList.add('reject'));
 }
 document.getElementById('suUser').textContent = r.name;
 document.getElementById('suAmount').textContent = 'Rs ' + r.amount.toLocaleString('en-IN');
 document.getElementById('successOverlay').classList.add('active');
 }
 function closeSuccess(){ document.getElementById('successOverlay').classList.remove('active'); }
 function openSideMenu(){ document.getElementById('sideMenu').classList.add('active'); document.getElementById('sideMenuOverlay').classList.add('active'); }
 function closeSideMenu(){ document.getElementById('sideMenu').classList.remove('active'); document.getElementById('sideMenuOverlay').classList.remove('active'); }
 function menuGo(page){ closeSideMenu(); setTimeout(()=>{ window.location.href = page; }, 250); }
 function logoutAdmin(){ if(!confirm('Logout?')) return; try{ localStorage.removeItem('adminLoggedIn'); localStorage.removeItem('adminToken'); }catch(e){} closeSideMenu(); setTimeout(()=>{ window.location.href='admin-login.html'; },250); }
 function goTo(page){ setTimeout(()=>{ window.location.href = page; }, 100); }
 function escapeHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
 function showToast(msg, type=''){
 const holder = document.getElementById('toastHolder');
 const t = document.createElement('div');
 t.className = 'toast ' + type;
 t.textContent = msg;
 holder.appendChild(t);
 requestAnimationFrame(()=>t.classList.add('show'));
 setTimeout(()=>{ t.classList.remove('show'); setTimeout(()=>t.remove(),400); }, 1700);
 }
 loadRequests();
 document.addEventListener('gesturestart', e=>e.preventDefault());
 document.addEventListener('gesturechange', e=>e.preventDefault());
 document.addEventListener('gestureend', e=>e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e=>{ const n=Date.now(); if(n-lastTouch<=300) e.preventDefault(); lastTouch=n; }, {passive:false});
 document.addEventListener('wheel', e=>{ if(e.ctrlKey) e.preventDefault(); }, {passive:false});
 document.addEventListener('keydown', e=>{ if((e.ctrlKey||e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault(); });