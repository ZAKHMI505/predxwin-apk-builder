window.ADMIN_APP_MODE = {
 DEMO_MODE: true 
 };
 window.ADMIN_API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 getGiftCodes: "/admin/gifts",
 createGiftCode: "/admin/gifts",
 deleteGiftCode: "/admin/gifts/:code",
 getGiftClaims: "/admin/gifts/:code/claims"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const token = localStorage.getItem('adminToken');
 if (token) h["X-Admin-Token"] = token;
 return h;
 }
 };
 window.ADMIN_API = {
 async call(endpoint, method = "GET", body = null) {
 if (!ADMIN_API_CONFIG.baseURL) return { success: false, error: "Admin server not configured" };
 const url = ADMIN_API_CONFIG.baseURL + endpoint;
 const options = { method, headers: ADMIN_API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) return { success: false, error: data.message || data.error || "Request failed", data };
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); },
 del(ep) { return this.call(ep, "DELETE"); }
 };
(function checkAuth() {
 try {
 const logged = localStorage.getItem('adminLoggedIn');
 const demo = window.ADMIN_APP_MODE.DEMO_MODE;
 if (demo) {
 if (logged !== 'true') {
 localStorage.setItem('adminLoggedIn', 'true');
 localStorage.setItem('adminEmail', 'demo-admin@predxprofit.pk');
 localStorage.setItem('adminName', 'Demo Admin');
 }
 return;
 }
 if (logged !== 'true') window.location.replace('admin-login.html');
 } catch(e) { window.location.replace('admin-login.html'); }
 })();
 const PX_ICON = 'https://premium-host.ct.ws//uploads/1791979416.png';
 const DEMO_CODES = [
 {
 code:'WELCOME100', amount:100, maxMembers:50, claimed:12,
 planFilter:'all', planLabel:'All Plans',
 created:'14 Oct 2026', status:'active',
 claims:[
 { name:'Ahmed Khan', uid:'PX-1001', amount:100 },
 { name:'Sara Malik', uid:'PX-1002', amount:100 },
 { name:'Bilal Raza', uid:'PX-1003', amount:100 }
 ]
 },
 {
 code:'PX-GIFT-500', amount:500, maxMembers:20, claimed:20,
 planFilter:'1200', planLabel:'Rs 1200+',
 created:'10 Oct 2026', status:'expired',
 claims:[
 { name:'Usman Tariq', uid:'PX-1005', amount:500 },
 { name:'Hassan Ali', uid:'PX-1007', amount:500 }
 ]
 },
 {
 code:'VIP2000', amount:2000, maxMembers:10, claimed:3,
 planFilter:'2400', planLabel:'Rs 2400+',
 created:'12 Oct 2026', status:'active',
 claims:[
 { name:'Maryam Iqbal', uid:'PX-1010', amount:2000 }
 ]
 }
 ];
 let GIFT_CODES = [];
 let selectedPlan = 'all';
 let currentDetailIdx = null;
 async function loadCodes() {
 if (window.ADMIN_API_CONFIG.baseURL && !window.ADMIN_APP_MODE.DEMO_MODE) {
 try {
 const res = await window.ADMIN_API.get(ADMIN_API_CONFIG.endpoints.getGiftCodes);
 if (res.success) {
 const list = res.data.codes || res.data.gifts || res.data || [];
 GIFT_CODES = list.map(normalizeCode);
 renderCodes();
 return;
 }
 } catch(e) { console.warn('API failed, using local'); }
 }
 try {
 const saved = localStorage.getItem('adminGiftCodes');
 if (saved) {
 GIFT_CODES = JSON.parse(saved).map(normalizeCode);
 } else {
 GIFT_CODES = DEMO_CODES.map(normalizeCode);
 saveCodesToLocal();
 }
 } catch(e) { GIFT_CODES = []; }
 renderCodes();
 }
 function normalizeCode(g) {
 return {
 code: g.code || '',
 amount: Number(g.amount || 0),
 maxMembers: Number(g.maxMembers || 0),
 claimed: Number(g.claimed || 0),
 planFilter: g.planFilter || 'all',
 planLabel: g.planLabel || 'All Plans',
 created: g.created || '—',
 status: g.status || (g.claimed >= g.maxMembers ? 'expired' : 'active'),
 claims: Array.isArray(g.claims) ? g.claims : []
 };
 }
 function saveCodesToLocal() {
 try { localStorage.setItem('adminGiftCodes', JSON.stringify(GIFT_CODES)); }
 catch(e) {}
 }
 function renderCodes(){
 const list = document.getElementById('codesList');
 const countEl = document.getElementById('codesCount');
 if(!list) return;
 countEl.textContent = GIFT_CODES.length + ' CODE' + (GIFT_CODES.length !== 1 ? 'S' : '');
 if(GIFT_CODES.length === 0){
 list.innerHTML = `
 <div class="empty-state">
 <div class="empty-icon"><svg viewBox="0 0 24 24"><rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13"/><path d="M5 12v9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-9"/></svg></div>
 <div class="empty-title">No Gift Codes</div>
 <div class="empty-desc">Create your first gift code</div>
 </div>`;
 return;
 }
 list.innerHTML = GIFT_CODES.map((g, idx) => {
 const pct = Math.min(100, Math.round((g.claimed / g.maxMembers) * 100));
 const isExpired = g.status === 'expired' || g.claimed >= g.maxMembers;
 return `
 <div class="code-card ${isExpired ? 'expired' : ''}" onclick="openDetail(${idx})">
 <div class="cc-top">
 <div class="cc-code">
 <span class="cc-code-txt">${escapeHtml(g.code)}</span>
 <button class="cc-copy-btn" onclick="event.stopPropagation(); copyCode('${escapeHtml(g.code)}')">
 <svg viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
 </button>
 </div>
 <div class="cc-amount">
 <div class="cc-amount-val">Rs ${g.amount.toLocaleString('en-IN')}</div>
 <div class="cc-amount-lbl">Per Claim</div>
 </div>
 </div>
 <div class="cc-details">
 <div class="cc-detail">
 <div class="cc-detail-lbl">Claimed</div>
 <div class="cc-detail-val">${g.claimed}/${g.maxMembers}</div>
 </div>
 <div class="cc-detail">
 <div class="cc-detail-lbl">Plan</div>
 <div class="cc-detail-val">${escapeHtml(g.planLabel)}</div>
 </div>
 <div class="cc-detail">
 <div class="cc-detail-lbl">Status</div>
 <div class="cc-detail-val" style="color:${isExpired ? '#94a3b8' : '#4ade80'};">${isExpired ? 'Expired' : 'Active'}</div>
 </div>
 </div>
 <div class="cc-progress-wrap">
 <div class="cc-progress-bar">
 <div class="cc-progress-fill" style="width:${pct}%"></div>
 </div>
 <div class="cc-progress-lbl">
 <span>${pct}% Claimed</span>
 <span>${g.maxMembers - g.claimed} Left</span>
 </div>
 </div>
 </div>
 `;
 }).join('');
 }
 function openCreateDialog(){
 document.getElementById('giftCodeInput').value = '';
 document.getElementById('giftAmountInput').value = '';
 document.getElementById('giftMaxInput').value = '';
 document.querySelectorAll('.amt-btn').forEach(b => b.classList.remove('active'));
 selectPlan(document.querySelector('[data-plan="all"]'), 'all');
 document.getElementById('createDialog').classList.add('active');
 setTimeout(()=>{ document.getElementById('giftCodeInput').focus(); }, 250);
 }
 function closeCreateDialog(){ document.getElementById('createDialog').classList.remove('active'); }
 function closeCreateOutside(e){ if(e.target.id==='createDialog') closeCreateDialog(); }
 function generateRandom(){
 const prefixes = ['PX','GIFT','BONUS','VIP','PREDX','WELCOME','FLASH'];
 const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
 const num = Math.floor(1000 + Math.random() * 9000);
 const letters = Array.from({length:3}, () => String.fromCharCode(65 + Math.floor(Math.random()*26))).join('');
 document.getElementById('giftCodeInput').value = `${prefix}-${letters}${num}`;
 showToast('Random code generated!');
 }
 function setQuickCode(prefix){
 const num = Math.floor(100 + Math.random() * 900);
 document.getElementById('giftCodeInput').value = `${prefix}${num}`;
 }
 function setAmount(val, el){
 document.getElementById('giftAmountInput').value = val;
 document.querySelectorAll('.amt-btn').forEach(b => b.classList.remove('active'));
 if(el) el.classList.add('active');
 }
 function setMax(val){ document.getElementById('giftMaxInput').value = val; }
 function selectPlan(el, plan){
 selectedPlan = plan;
 document.querySelectorAll('.plan-opt').forEach(b => b.classList.remove('active'));
 if(el) el.classList.add('active');
 }
 async function createGiftCode(){
 const code = (document.getElementById('giftCodeInput').value || '').trim().toUpperCase();
 const amount = parseInt(document.getElementById('giftAmountInput').value, 10);
 const maxMembers = parseInt(document.getElementById('giftMaxInput').value, 10);
 if(!code){ shakeField('giftCodeInput'); showToast('Enter gift code', 'error'); return; }
 if(code.length < 4){ shakeField('giftCodeInput'); showToast('Code too short (min 4)', 'error'); return; }
 if(GIFT_CODES.some(g => g.code === code)){ shakeField('giftCodeInput'); showToast('Code already exists!', 'error'); return; }
 if(!amount || amount < 1){ shakeField('giftAmountInput'); showToast('Enter valid amount', 'error'); return; }
 if(!maxMembers || maxMembers < 1){ shakeField('giftMaxInput'); showToast('Enter max members', 'error'); return; }
 const planLabelMap = { 'all':'All Plans', '600':'Rs 600+', '1200':'Rs 1200+', '2400':'Rs 2400+' };
 const now = new Date();
 const dateStr = now.toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' });
 const newCode = {
 code, amount, maxMembers,
 claimed: 0,
 planFilter: selectedPlan,
 planLabel: planLabelMap[selectedPlan] || 'All Plans',
 created: dateStr,
 status: 'active',
 claims: []
 };
 if (window.ADMIN_API_CONFIG.baseURL && !window.ADMIN_APP_MODE.DEMO_MODE) {
 try {
 const res = await window.ADMIN_API.post(ADMIN_API_CONFIG.endpoints.createGiftCode, newCode);
 if (res.success && res.data.code) {
 GIFT_CODES.unshift(normalizeCode(res.data.code));
 } else {
 GIFT_CODES.unshift(newCode);
 }
 } catch(e) { GIFT_CODES.unshift(newCode); }
 } else {
 GIFT_CODES.unshift(newCode);
 }
 saveCodesToLocal();
 closeCreateDialog();
 renderCodes();
 document.getElementById('suCode').textContent = code;
 document.getElementById('successOverlay').classList.add('active');
 }
 function closeSuccess(){ document.getElementById('successOverlay').classList.remove('active'); }
 function shakeField(id){
 const el = document.getElementById(id);
 if(!el) return;
 el.style.transition = 'transform .1s ease';
 el.style.transform = 'translateX(-8px)';
 setTimeout(()=>el.style.transform='translateX(8px)', 100);
 setTimeout(()=>el.style.transform='translateX(-6px)', 200);
 setTimeout(()=>el.style.transform='translateX(6px)', 300);
 setTimeout(()=>el.style.transform='translateX(0)', 400);
 el.focus();
 }
 function openDetail(idx){
 const g = GIFT_CODES[idx];
 if(!g) return;
 currentDetailIdx = idx;
 const pct = Math.min(100, Math.round((g.claimed / g.maxMembers) * 100));
 const isExpired = g.status === 'expired' || g.claimed >= g.maxMembers;
 const claimsHTML = g.claims.length > 0
 ? g.claims.map(c => `
 <div class="claim-row">
 <div class="claim-avatar"><img src="${PX_ICON}" alt="PX"></div>
 <div class="claim-info">
 <div class="claim-name">${escapeHtml(c.name)}</div>
 <div class="claim-uid">${escapeHtml(c.uid)}</div>
 </div>
 <div class="claim-amount">+Rs ${c.amount.toLocaleString('en-IN')}</div>
 </div>
 `).join('')
 : `<div class="no-claims">No claims yet</div>`;
 document.getElementById('ddScroll').innerHTML = `
 <div class="dd-hero">
 <div class="dd-code-icon">
 <svg viewBox="0 0 24 24">
 <rect x="3" y="8" width="18" height="4" rx="1"/>
 <path d="M12 8v13"/>
 <path d="M5 12v9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-9"/>
 <path d="M8 8a3 3 0 0 1 0-6c2 0 4 3 4 6"/>
 <path d="M16 8a3 3 0 0 0 0-6c-2 0-4 3-4 6"/>
 </svg>
 </div>
 <div class="dd-code">${escapeHtml(g.code)}</div>
 <div>
 <button class="cc-copy-btn" onclick="copyCode('${escapeHtml(g.code)}')" style="width:auto;padding:8px 14px;border-radius:10px;gap:6px;display:inline-flex;align-items:center;">
 <svg viewBox="0 0 24 24" style="width:14px;height:14px;"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
 <span style="font-family:'Baloo Bhai 2',sans-serif;font-size:12.5px;font-weight:800;color:#fff;">Copy Code</span>
 </button>
 </div>
 </div>
 <div class="dd-amount-box">
 <div class="dd-amount-lbl">Amount Per Claim</div>
 <div class="dd-amount-val">Rs ${g.amount.toLocaleString('en-IN')}</div>
 </div>
 <div class="dd-section-lbl">
 <svg viewBox="0 0 24 24" style="width:11px;height:11px;stroke:#fbbf24;stroke-width:2.8;fill:none;stroke-linecap:round;stroke-linejoin:round;"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
 Code Info
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>Max Members</span>
 <span class="dd-row-val gold">${g.maxMembers} Users</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>Claimed</span>
 <span class="dd-row-val green">${g.claimed} / ${g.maxMembers}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><path d="M12 2l3 7h7l-5.5 4 2 7L12 16l-6.5 4 2-7L2 9h7z"/></svg>Plan Filter</span>
 <span class="dd-row-val text">${escapeHtml(g.planLabel)}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>Created</span>
 <span class="dd-row-val text">${escapeHtml(g.created)}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>Status</span>
 <span class="dd-row-val ${isExpired ? '' : 'green'}" style="${isExpired ? 'color:#94a3b8;' : ''}">${isExpired ? 'Expired' : 'Active'}</span>
 </div>
 <div class="dd-section-lbl">
 <svg viewBox="0 0 24 24" style="width:11px;height:11px;stroke:#fbbf24;stroke-width:2.8;fill:none;stroke-linecap:round;stroke-linejoin:round;"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
 Claimed By (${g.claims.length})
 </div>
 <div class="claims-list">
 ${claimsHTML}
 </div>
 <button class="dd-danger-btn" onclick="deleteCode(${idx})">
 <svg viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
 Delete Gift Code
 </button>
 `;
 document.getElementById('detailOverlay').classList.add('active');
 }
 function closeDetail(){ document.getElementById('detailOverlay').classList.remove('active'); currentDetailIdx = null; }
 function closeDetailOutside(e){ if(e.target.id==='detailOverlay') closeDetail(); }
 async function deleteCode(idx) {
 const g = GIFT_CODES[idx];
 if (!g) return;
 if (!confirm('Delete gift code "' + g.code + '"?\n\nUsers will no longer be able to claim it.')) return;
 if (window.ADMIN_API_CONFIG.baseURL && !window.ADMIN_APP_MODE.DEMO_MODE) {
 try {
 const ep = ADMIN_API_CONFIG.endpoints.deleteGiftCode.replace(':code', g.code);
 await window.ADMIN_API.del(ep);
 } catch(e) {}
 }
 GIFT_CODES.splice(idx, 1);
 saveCodesToLocal();
 closeDetail();
 renderCodes();
 showToast('Gift code deleted', 'error');
 }
 function copyCode(code){
 if(navigator.clipboard && window.isSecureContext){
 navigator.clipboard.writeText(code).then(()=>showToast('Code copied!')).catch(()=>legacyCopy(code));
 } else legacyCopy(code);
 }
 function legacyCopy(text){
 const ta = document.createElement('textarea');
 ta.value = text; ta.style.position='fixed'; ta.style.opacity='0';
 document.body.appendChild(ta); ta.select();
 try { document.execCommand('copy'); showToast('Code copied!'); } catch(e) {}
 document.body.removeChild(ta);
 }
 function openSideMenu(){ document.getElementById('sideMenu').classList.add('active'); document.getElementById('sideMenuOverlay').classList.add('active'); }
 function closeSideMenu(){ document.getElementById('sideMenu').classList.remove('active'); document.getElementById('sideMenuOverlay').classList.remove('active'); }
 function menuGo(page){ closeSideMenu(); setTimeout(()=>{ window.location.href = page; }, 250); }
 function logoutAdmin(){ if(!confirm('Logout?')) return; try{ localStorage.clear(); sessionStorage.clear(); }catch(e){} closeSideMenu(); setTimeout(()=>{ window.location.href='admin-login.html'; },250); }
 function goTo(page){ setTimeout(()=>{ window.location.href = page; }, 100); }
 function escapeHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
 function showToast(msg, type=''){
 const holder = document.getElementById('toastHolder');
 const t = document.createElement('div');
 t.className = 'toast ' + type;
 t.textContent = msg;
 holder.appendChild(t);
 requestAnimationFrame(()=>t.classList.add('show'));
 setTimeout(()=>{ t.classList.remove('show'); setTimeout(()=>t.remove(),400); }, 1700);
 }
 /* INIT */
 loadCodes();
 document.addEventListener('gesturestart', e=>e.preventDefault());
 document.addEventListener('gesturechange', e=>e.preventDefault());
 document.addEventListener('gestureend', e=>e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e=>{ const n=Date.now(); if(n-lastTouch<=300) e.preventDefault(); lastTouch=n; }, {passive:false});
 document.addEventListener('wheel', e=>{ if(e.ctrlKey) e.preventDefault(); }, {passive:false});
 document.addEventListener('keydown', e=>{ if((e.ctrlKey||e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault(); });