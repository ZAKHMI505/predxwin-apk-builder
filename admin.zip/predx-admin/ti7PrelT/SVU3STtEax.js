(function() {
 try {
 const logged = localStorage.getItem('adminLoggedIn');
 if (logged === 'true') {
 window.location.replace('admin-dashboard.html');
 return;
 }
 if (window.ADMIN_APP_MODE && window.ADMIN_APP_MODE.DEMO_MODE) {
 localStorage.setItem('adminLoggedIn', 'true');
 localStorage.setItem('adminEmail', 'demo-admin@predxprofit.pk');
 localStorage.setItem('adminName', 'Demo Admin');
 localStorage.setItem('adminRole', 'super_admin');
 localStorage.setItem('adminLoginTime', new Date().toISOString());
 window.location.replace('admin-dashboard.html');
 }
 } catch(e) {}
 })();
window.ADMIN_APP_MODE = {
 DEMO_MODE: true
 };
 window.ADMIN_API_CONFIG = {
 baseURL: "", 
 apiKey: "",
 endpoints: {
 login: "/auth/admin-login",
 logout: "/auth/admin-logout",
 me: "/auth/admin-me"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const token = localStorage.getItem('adminToken');
 if (token) h["X-Admin-Token"] = token;
 return h;
 }
 };
 window.ADMIN_API = {
 async call(endpoint, method = "GET", body = null) {
 if (!ADMIN_API_CONFIG.baseURL) {
 return { success: false, error: "Admin server not configured" };
 }
 const url = ADMIN_API_CONFIG.baseURL + endpoint;
 const options = { method, headers: ADMIN_API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) {
 return { success: false, error: data.message || data.error || "Request failed", data };
 }
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); }
 };
 document.addEventListener('DOMContentLoaded', function() {
 const badge = document.getElementById('demoBadge');
 if (badge && !window.ADMIN_APP_MODE.DEMO_MODE) {
 badge.classList.add('hidden');
 }
 });
 console.log('🎭 ADMIN MODE:', window.ADMIN_APP_MODE.DEMO_MODE ? 'DEMO (Login Bypass)' : 'LIVE (Server Login)');
 console.log('🔌 Admin API:', window.ADMIN_API_CONFIG.baseURL || '(not set)');
function togglePass(inputId, btn) {
 const input = document.getElementById(inputId);
 if (!input) return;
 if (input.type === 'password') {
 input.type = 'text';
 btn.innerHTML = '<svg viewBox="0 0 24 24"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>';
 } else {
 input.type = 'password';
 btn.innerHTML = '<svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
 }
 }
 async function submitAdminLogin() {
 const emailField = document.getElementById('adminEmail');
 const passField = document.getElementById('adminPass');
 const email = (emailField.value || '').trim().toLowerCase();
 const pass = (passField.value || '').trim();
 if (!email) {
 shakeWrap(emailField);
 showToast('Please enter Gmail', 'error');
 emailField.focus();
 return;
 }
 if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
 shakeWrap(emailField);
 showToast('Invalid email format', 'error');
 emailField.focus();
 return;
 }
 if (!pass) {
 shakeWrap(passField);
 showToast('Please enter password', 'error');
 passField.focus();
 return;
 }
 if (window.ADMIN_APP_MODE.DEMO_MODE) {
 const btn = document.getElementById('loginBtn');
 btn.classList.add('loading');
 try {
 localStorage.setItem('adminLoggedIn', 'true');
 localStorage.setItem('adminToken', 'demo-token-' + Date.now());
 localStorage.setItem('adminEmail', email);
 localStorage.setItem('adminName', 'Demo Admin');
 localStorage.setItem('adminRole', 'super_admin');
 localStorage.setItem('adminLoginTime', new Date().toISOString());
 } catch(e) {}
 showToast('Demo login successful!', 'success');
 setTimeout(() => {
 window.location.href = 'admin-dashboard.html';
 }, 800);
 return;
 }
 if (!window.ADMIN_API_CONFIG.baseURL) {
 showToast('Admin server not connected', 'error');
 return;
 }
 const btn = document.getElementById('loginBtn');
 btn.classList.add('loading');
 try {
 const result = await window.ADMIN_API.post(ADMIN_API_CONFIG.endpoints.login, {
 email: email,
 password: pass
 });
 if (!result.success) {
 btn.classList.remove('loading');
 shakeWrap(emailField);
 shakeWrap(passField);
 showToast(result.error || 'Invalid credentials', 'error');
 return;
 }
 const data = result.data;
 const token = data.token || data.adminToken || '';
 const admin = data.admin || data.user || {};
 try {
 localStorage.setItem('adminLoggedIn', 'true');
 localStorage.setItem('adminToken', token);
 localStorage.setItem('adminEmail', admin.email || email);
 localStorage.setItem('adminName', admin.name || 'Admin');
 localStorage.setItem('adminRole', admin.role || 'admin');
 localStorage.setItem('adminLoginTime', new Date().toISOString());
 } catch(e) {}
 showToast('Login successful!', 'success');
 setTimeout(() => {
 window.location.href = 'admin-dashboard.html';
 }, 800);
 } catch(err) {
 btn.classList.remove('loading');
 console.error('Admin login error:', err);
 showToast(err.message || 'Login failed', 'error');
 }
 }
 function shakeWrap(inputEl) {
 if (!inputEl) return;
 const wrap = inputEl.closest('.input-wrap');
 if (!wrap) return;
 wrap.classList.remove('shake');
 void wrap.offsetWidth;
 wrap.classList.add('shake');
 setTimeout(() => wrap.classList.remove('shake'), 600);
 }
 function showToast(msg, type = '') {
 const holder = document.getElementById('toastHolder');
 const toast = document.createElement('div');
 toast.className = 'toast ' + type;
 toast.textContent = msg;
 holder.appendChild(toast);
 requestAnimationFrame(() => toast.classList.add('show'));
 setTimeout(() => {
 toast.classList.remove('show');
 setTimeout(() => toast.remove(), 400);
 }, 1800);
 }
 document.getElementById('adminEmail').addEventListener('keydown', e => {
 if (e.key === 'Enter') document.getElementById('adminPass').focus();
 });
 document.getElementById('adminPass').addEventListener('keydown', e => {
 if (e.key === 'Enter') submitAdminLogin();
 });
 document.addEventListener('gesturestart', e => e.preventDefault());
 document.addEventListener('gesturechange', e => e.preventDefault());
 document.addEventListener('gestureend', e => e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e => {
 const now = Date.now();
 if (now - lastTouch <= 300) e.preventDefault();
 lastTouch = now;
 }, { passive: false });
 document.addEventListener('wheel', e => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });
 document.addEventListener('keydown', e => {
 if ((e.ctrlKey || e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault();
 });