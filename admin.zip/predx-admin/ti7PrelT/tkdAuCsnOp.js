window.ADMIN_APP_MODE = {
 DEMO_MODE: true 
 };
 window.ADMIN_API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 login: "/auth/admin-login",
 logout: "/auth/admin-logout",
 me: "/auth/admin-me",
 getUsers: "/admin/users",
 getUser: "/admin/users/:uid",
 lockUser: "/admin/users/:uid/lock",
 unlockUser: "/admin/users/:uid/unlock"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const token = localStorage.getItem('adminToken');
 if (token) h["X-Admin-Token"] = token;
 return h;
 }
 };
 window.ADMIN_API = {
 async call(endpoint, method = "GET", body = null) {
 if (!ADMIN_API_CONFIG.baseURL) return { success: false, error: "Admin server not configured" };
 const url = ADMIN_API_CONFIG.baseURL + endpoint;
 const options = { method, headers: ADMIN_API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) return { success: false, error: data.message || data.error || "Request failed", data };
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); },
 put(ep, body) { return this.call(ep, "PUT", body); }
 };
 console.log('🎭 ADMIN MODE:', window.ADMIN_APP_MODE.DEMO_MODE ? 'DEMO' : 'LIVE');
(function checkAuth() {
 try {
 const logged = localStorage.getItem('adminLoggedIn');
 const demo = window.ADMIN_APP_MODE.DEMO_MODE;
 if (demo) {
 if (logged !== 'true') {
 localStorage.setItem('adminLoggedIn', 'true');
 localStorage.setItem('adminEmail', 'demo-admin@predxprofit.pk');
 localStorage.setItem('adminName', 'Demo Admin');
 localStorage.setItem('adminRole', 'super_admin');
 }
 return;
 }
 if (logged !== 'true') window.location.replace('admin-login.html');
 } catch(e) {
 window.location.replace('admin-login.html');
 }
 })();
 const PX_ICON = 'https://premium-host.ct.ws//uploads/1791979416.png';
 let USERS = [];
 const DEMO_USERS = [
 { uid: 'PX-1001', name: 'Ahmed Khan', online: true, locked: false, wallet: 5420, invested: 12000, withdrawable: 8420, dashboard: 12000, teamSize: 12, salary: 2500, totalEarned: 15400, activePlans: 3, joinDate: '02 Oct 2026', email: 'ahmedkhan@gmail.com' },
 { uid: 'PX-1002', name: 'Sara Malik', online: true, locked: false, wallet: 3850, invested: 6000, withdrawable: 4850, dashboard: 6000, teamSize: 8, salary: 0, totalEarned: 6400, activePlans: 2, joinDate: '05 Oct 2026', email: 'saramalik@gmail.com' },
 { uid: 'PX-1003', name: 'Bilal Raza', online: false, locked: false, wallet: 12300, invested: 24000, withdrawable: 17300, dashboard: 24000, teamSize: 22, salary: 5000, totalEarned: 32000, activePlans: 5, joinDate: '28 Sep 2026', email: 'bilalraza@gmail.com' },
 { uid: 'PX-1004', name: 'Fatima Noor', online: true, locked: false, wallet: 2100, invested: 3600, withdrawable: 2600, dashboard: 3600, teamSize: 4, salary: 0, totalEarned: 2800, activePlans: 1, joinDate: '10 Oct 2026', email: 'fatimanoor@gmail.com' },
 { uid: 'PX-1005', name: 'Usman Tariq', online: true, locked: false, wallet: 8900, invested: 18000, withdrawable: 12900, dashboard: 18000, teamSize: 15, salary: 2500, totalEarned: 21000, activePlans: 4, joinDate: '30 Sep 2026', email: 'usmantariq@gmail.com' },
 { uid: 'PX-1006', name: 'Ayesha Khan', online: false, locked: true, wallet: 450, invested: 1200, withdrawable: 650, dashboard: 1200, teamSize: 2, salary: 0, totalEarned: 800, activePlans: 1, joinDate: '12 Oct 2026', email: 'ayeshakhan@gmail.com' },
 { uid: 'PX-1007', name: 'Hassan Ali', online: true, locked: false, wallet: 6700, invested: 14000, withdrawable: 9700, dashboard: 14000, teamSize: 18, salary: 2500, totalEarned: 18500, activePlans: 3, joinDate: '01 Oct 2026', email: 'hassanali@gmail.com' },
 { uid: 'PX-1008', name: 'Zainab Shah', online: true, locked: false, wallet: 4320, invested: 8400, withdrawable: 6320, dashboard: 8400, teamSize: 11, salary: 0, totalEarned: 9100, activePlans: 2, joinDate: '06 Oct 2026', email: 'zainabshah@gmail.com' },
 { uid: 'PX-1009', name: 'Imran Yousaf', online: false, locked: false, wallet: 1890, invested: 2400, withdrawable: 2290, dashboard: 2400, teamSize: 3, salary: 0, totalEarned: 3100, activePlans: 1, joinDate: '11 Oct 2026', email: 'imranyousaf@gmail.com' },
 { uid: 'PX-1010', name: 'Maryam Iqbal', online: true, locked: false, wallet: 7200, invested: 15000, withdrawable: 10200, dashboard: 15000, teamSize: 14, salary: 2500, totalEarned: 19200, activePlans: 3, joinDate: '03 Oct 2026', email: 'maryamiqbal@gmail.com' }
 ];
 async function loadUsers() {
 if (window.ADMIN_API_CONFIG.baseURL) {
 try {
 const result = await window.ADMIN_API.get(ADMIN_API_CONFIG.endpoints.getUsers);
 if (result.success) {
 const list = result.data.users || result.data || [];
 USERS = list.map(normalizeUser);
 renderUsers();
 return;
 }
 } catch(e) {
 console.warn('API failed, using demo data');
 }
 }
 USERS = DEMO_USERS.map(normalizeUser);
 renderUsers();
 }
 function normalizeUser(u) {
 return {
 uid: u.uid || u.id || 'PX-0000',
 name: u.name || 'Unknown User',
 email: u.email || '',
 online: u.online !== false && u.status !== 'offline',
 locked: u.locked === true || u.status === 'locked' || u.banned === true,
 wallet: Number(u.wallet || 0),
 invested: Number(u.invested || u.totalInvested || 0),
 withdrawable: Number(u.withdrawable || u.withdrawableWallet || 0),
 dashboard: Number(u.dashboard || u.totalDashboard || 0),
 teamSize: Number(u.teamSize || (Array.isArray(u.teamList) ? u.teamList.length : 0)),
 salary: Number(u.salary || u.weeklySalary || 0),
 totalEarned: Number(u.totalEarned || u.todayEarning || 0),
 activePlans: Number(u.activePlans || (Array.isArray(u.activePlanList) ? u.activePlanList.length : 0)),
 joinDate: u.joinDate || u.createdAt || 'recently'
 };
 }
 function renderUsers() {
 const list = document.getElementById('userList');
 const count = document.getElementById('userCount');
 if (!list) return;
 count.textContent = USERS.length;
 if (USERS.length === 0) {
 list.innerHTML = `
 <div style="text-align:center;padding:40px 20px;color:#4a6b5a;font-family:'Rajdhani',sans-serif;font-size:13px;font-weight:800;letter-spacing:1.5px;text-transform:uppercase;">
 No users yet
 </div>
 `;
 return;
 }
 list.innerHTML = USERS.map((u, idx) => `
 <div class="user-item ${u.locked ? 'locked' : ''}" onclick="openUser(${idx})">
 <div class="user-avatar ${u.locked ? 'locked' : (u.online ? '' : 'offline')}">
 <img src="${PX_ICON}" alt="PX">
 </div>
 <div class="user-info">
 <div class="user-name">${escapeHtml(u.name)}</div>
 <div class="user-uid">
 <svg viewBox="0 0 24 24"><path d="M4 7V4h16v3"/><path d="M9 20h6"/><path d="M12 4v16"/></svg>
 <span>UID: <strong>${escapeHtml(u.uid)}</strong></span>
 </div>
 </div>
 ${u.locked ? `
 <div class="user-lock-icon">
 <svg viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
 </div>
 ` : ''}
 <div class="user-arrow">
 <svg viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg>
 </div>
 </div>
 `).join('');
 }
 function openUser(idx) {
 const u = USERS[idx];
 if (!u) return;
 const scroll = document.getElementById('ddScroll');
 scroll.innerHTML = `
 <div class="dd-user-hero">
 <div class="dd-avatar ${u.locked ? 'locked' : (u.online ? '' : 'offline')}">
 <img src="${PX_ICON}" alt="PX">
 </div>
 <div class="dd-name">${escapeHtml(u.name)}</div>
 <div class="dd-uid-pill">
 <svg viewBox="0 0 24 24"><path d="M4 7V4h16v3"/><path d="M9 20h6"/><path d="M12 4v16"/></svg>
 <span>${escapeHtml(u.uid)}</span>
 </div>
 <div>
 ${u.locked
 ? `<span class="dd-status-pill locked"><span class="dot"></span>Locked Account</span>`
 : `<span class="dd-status-pill active"><span class="dot"></span>Active Account</span>`
 }
 </div>
 </div>
 <div class="dd-section-title">
 <svg viewBox="0 0 24 24" style="width:11px;height:11px;stroke:#4ade80;stroke-width:2.8;fill:none;stroke-linecap:round;stroke-linejoin:round;"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
 Money Overview
 </div>
 <div class="dd-money-grid">
 <div class="dd-money-card green" onclick="openAmount(${idx}, 'wallet')">
 <div class="dd-money-lbl">
 <svg viewBox="0 0 24 24"><rect x="2" y="6" width="20" height="12" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
 Wallet
 </div>
 <div class="dd-money-val">Rs ${u.wallet.toLocaleString('en-IN')}</div>
 </div>
 <div class="dd-money-card blue" onclick="openAmount(${idx}, 'invested')">
 <div class="dd-money-lbl">
 <svg viewBox="0 0 24 24"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>
 Invested
 </div>
 <div class="dd-money-val">Rs ${u.invested.toLocaleString('en-IN')}</div>
 </div>
 <div class="dd-money-card gold" onclick="openAmount(${idx}, 'withdrawable')">
 <div class="dd-money-lbl">
 <svg viewBox="0 0 24 24"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>
 Withdraw
 </div>
 <div class="dd-money-val">Rs ${u.withdrawable.toLocaleString('en-IN')}</div>
 </div>
 </div>
 <div class="dd-section-title">
 <svg viewBox="0 0 24 24" style="width:11px;height:11px;stroke:#4ade80;stroke-width:2.8;fill:none;stroke-linecap:round;stroke-linejoin:round;"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
 Details
 </div>
 <div class="dd-info-row">
 <span class="dd-info-lbl">
 <svg viewBox="0 0 24 24"><rect x="2" y="4" width="20" height="16" rx="2"/><polyline points="2,6 12,13 22,6"/></svg>
 Email
 </span>
 <span class="dd-info-val text">${escapeHtml(u.email) || '—'}</span>
 </div>
 <div class="dd-info-row">
 <span class="dd-info-lbl">
 <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
 Team Size
 </span>
 <span class="dd-info-val green">${u.teamSize} Members</span>
 </div>
 <div class="dd-info-row">
 <span class="dd-info-lbl">
 <svg viewBox="0 0 24 24"><path d="M12 2l3 7h7l-5.5 4 2 7L12 16l-6.5 4 2-7L2 9h7z"/></svg>
 Active Plans
 </span>
 <span class="dd-info-val green">${u.activePlans} Plans</span>
 </div>
 <div class="dd-info-row">
 <span class="dd-info-lbl">
 <svg viewBox="0 0 24 24"><rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13"/><path d="M5 12v9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-9"/></svg>
 Weekly Salary
 </span>
 <span class="dd-info-val gold">Rs ${u.salary.toLocaleString('en-IN')}</span>
 </div>
 <div class="dd-info-row">
 <span class="dd-info-lbl">
 <svg viewBox="0 0 24 24"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>
 Total Earned
 </span>
 <span class="dd-info-val green">Rs ${u.totalEarned.toLocaleString('en-IN')}</span>
 </div>
 <div class="dd-info-row">
 <span class="dd-info-lbl">
 <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
 Join Date
 </span>
 <span class="dd-info-val blue">${escapeHtml(u.joinDate)}</span>
 </div>
 <div class="dd-buttons">
 ${u.locked
 ? `<button class="dd-btn unlock" onclick="toggleLock(${idx})">
 <svg viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/></svg>
 <span>Unlock</span>
 </button>`
 : `<button class="dd-btn lock" onclick="toggleLock(${idx})">
 <svg viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
 <span>Lock</span>
 </button>`
 }
 <button class="dd-btn close" onclick="closeDetail()">
 <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
 <span>Close</span>
 </button>
 </div>
 `;
 document.getElementById('detailOverlay').classList.add('active');
 }
 function closeDetail() { document.getElementById('detailOverlay').classList.remove('active'); }
 function closeDetailOutside(e) { if (e.target.id === 'detailOverlay') closeDetail(); }
 function openAmount(idx, focus) {
 const u = USERS[idx];
 if (!u) return;
 const total = u.dashboard || u.wallet;
 const scroll = document.getElementById('amScroll');
 scroll.innerHTML = `
 <div class="am-header">
 <div class="am-icon">
 <svg viewBox="0 0 24 24">
 <line x1="12" y1="1" x2="12" y2="23"/>
 <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
 </svg>
 </div>
 <div class="am-title">${escapeHtml(u.name)}</div>
 <div class="am-sub">Full Amount Breakdown</div>
 </div>
 <div class="am-hero">
 <div class="am-hero-lbl">Total Balance</div>
 <div class="am-hero-val">Rs ${total.toLocaleString('en-IN')}</div>
 </div>
 <div class="am-row green">
 <div class="am-row-left">
 <div class="am-row-icon">
 <svg viewBox="0 0 24 24"><rect x="2" y="6" width="20" height="12" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
 </div>
 <div class="am-row-text">
 <div class="am-row-lbl">Wallet Amount</div>
 <div class="am-row-sub">Available Balance</div>
 </div>
 </div>
 <div class="am-row-val">Rs ${u.wallet.toLocaleString('en-IN')}</div>
 </div>
 <div class="am-row blue">
 <div class="am-row-left">
 <div class="am-row-icon">
 <svg viewBox="0 0 24 24"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>
 </div>
 <div class="am-row-text">
 <div class="am-row-lbl">Total Investment</div>
 <div class="am-row-sub">${u.activePlans} Active Plans</div>
 </div>
 </div>
 <div class="am-row-val">Rs ${u.invested.toLocaleString('en-IN')}</div>
 </div>
 <div class="am-row gold">
 <div class="am-row-left">
 <div class="am-row-icon">
 <svg viewBox="0 0 24 24"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>
 </div>
 <div class="am-row-text">
 <div class="am-row-lbl">Withdrawable</div>
 <div class="am-row-sub">Ready to Cash Out</div>
 </div>
 </div>
 <div class="am-row-val">Rs ${u.withdrawable.toLocaleString('en-IN')}</div>
 </div>
 <div class="am-row purple">
 <div class="am-row-left">
 <div class="am-row-icon">
 <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
 </div>
 <div class="am-row-text">
 <div class="am-row-lbl">Dashboard Amount</div>
 <div class="am-row-sub">Total Active Value</div>
 </div>
 </div>
 <div class="am-row-val">Rs ${u.dashboard.toLocaleString('en-IN')}</div>
 </div>
 <div class="am-total">
 <div class="am-total-lbl">
 <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
 Total Earnings
 </div>
 <div class="am-total-val">Rs ${u.totalEarned.toLocaleString('en-IN')}</div>
 </div>
 <button class="am-close-btn" onclick="closeAmount()">
 <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
 <span>Close</span>
 </button>
 `;
 document.getElementById('amountOverlay').classList.add('active');
 }
 function closeAmount() { document.getElementById('amountOverlay').classList.remove('active'); }
 function closeAmountOutside(e) { if (e.target.id === 'amountOverlay') closeAmount(); }
 async function toggleLock(idx) {
 const u = USERS[idx];
 if (!u) return;
 const action = u.locked ? 'unlock' : 'lock';
 const confirmMsg = u.locked
 ? 'Unlock account: ' + u.name + '?\nUser will be able to login again.'
 : 'Lock account: ' + u.name + '?\nUser will NOT be able to login.';
 if (!confirm(confirmMsg)) return;
 if (window.ADMIN_API_CONFIG.baseURL) {
 try {
 const ep = u.locked
 ? ADMIN_API_CONFIG.endpoints.unlockUser.replace(':uid', u.uid)
 : ADMIN_API_CONFIG.endpoints.lockUser.replace(':uid', u.uid);
 await window.ADMIN_API.put(ep, {});
 } catch(e) { console.warn('API lock failed'); }
 }
 u.locked = !u.locked;
 renderUsers();
 openUser(idx);
 showToast(u.locked ? ('User locked: ' + u.uid) : ('User unlocked: ' + u.uid), u.locked ? 'error' : '');
 }
 function switchTab(tab) {
 document.querySelectorAll('.nav-item').forEach(btn => {
 btn.classList.toggle('active', btn.dataset.tab === tab);
 });
 const titleMap = { home:'Admin Panel', deposit:'Deposits', withdraw:'Withdrawals', profile:'Profile', settings:'Settings' };
 const subMap = { home:'Dashboard', deposit:'Manage Requests', withdraw:'Manage Payouts', profile:'Your Account', settings:'App Options' };
 const titleEl = document.querySelector('.header-title');
 const subEl = document.querySelector('.header-sub span:last-child');
 if (titleEl) titleEl.textContent = titleMap[tab] || 'Admin Panel';
 if (subEl) subEl.textContent = subMap[tab] || 'Dashboard';
 }
 function openSideMenu() {
 document.getElementById('sideMenu').classList.add('active');
 document.getElementById('sideMenuOverlay').classList.add('active');
 }
 function closeSideMenu() {
 document.getElementById('sideMenu').classList.remove('active');
 document.getElementById('sideMenuOverlay').classList.remove('active');
 }
 function menuGo(page) {
 closeSideMenu();
 setTimeout(() => { window.location.href = page; }, 250);
 }
 function logoutAdmin() {
 if (!confirm('Are you sure you want to logout?')) return;
 try {
 localStorage.removeItem('adminLoggedIn');
 localStorage.removeItem('adminToken');
 localStorage.removeItem('adminEmail');
 localStorage.removeItem('adminName');
 localStorage.removeItem('adminRole');
 localStorage.removeItem('adminLoginTime');
 sessionStorage.clear();
 } catch(e) {}
 closeSideMenu();
 setTimeout(() => { window.location.href = 'admin-login.html'; }, 250);
 }
 function goTo(page) { setTimeout(() => { window.location.href = page; }, 100); }
 function escapeHtml(str) {
 return String(str)
 .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
 .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
 }
 function showToast(msg, type = '') {
 const holder = document.getElementById('toastHolder');
 const toast = document.createElement('div');
 toast.className = 'toast ' + type;
 toast.textContent = msg;
 holder.appendChild(toast);
 requestAnimationFrame(() => toast.classList.add('show'));
 setTimeout(() => {
 toast.classList.remove('show');
 setTimeout(() => toast.remove(), 400);
 }, 1700);
 }
 /* INIT */
 loadUsers();
 /* ZOOM BLOCK */
 document.addEventListener('gesturestart', e => e.preventDefault());
 document.addEventListener('gesturechange', e => e.preventDefault());
 document.addEventListener('gestureend', e => e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e => {
 const now = Date.now();
 if (now - lastTouch <= 300) e.preventDefault();
 lastTouch = now;
 }, { passive: false });
 document.addEventListener('wheel', e => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });
 document.addEventListener('keydown', e => {
 if ((e.ctrlKey || e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault();
 });