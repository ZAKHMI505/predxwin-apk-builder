window.ADMIN_APP_MODE = {
 DEMO_MODE: true 
 };
 window.ADMIN_API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 getWithdraws: "/admin/withdraws",
 getPendingWithdraws: "/admin/withdraws/pending"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const token = localStorage.getItem('adminToken');
 if (token) h["X-Admin-Token"] = token;
 return h;
 }
 };
 window.ADMIN_API = {
 async call(endpoint, method = "GET", body = null) {
 if (!ADMIN_API_CONFIG.baseURL) return { success: false, error: "Admin server not configured" };
 const url = ADMIN_API_CONFIG.baseURL + endpoint;
 const options = { method, headers: ADMIN_API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) return { success: false, error: data.message || data.error || "Request failed", data };
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); },
 put(ep, body) { return this.call(ep, "PUT", body); }
 };
(function checkAuth() {
 try {
 const logged = localStorage.getItem('adminLoggedIn');
 const demo = window.ADMIN_APP_MODE.DEMO_MODE;
 if (demo) {
 if (logged !== 'true') {
 localStorage.setItem('adminLoggedIn', 'true');
 localStorage.setItem('adminEmail', 'demo-admin@predxprofit.pk');
 localStorage.setItem('adminName', 'Demo Admin');
 }
 return;
 }
 if (logged !== 'true') window.location.replace('admin-login.html');
 } catch(e) { window.location.replace('admin-login.html'); }
 })();
 const PX_ICON = 'https://premium-host.ct.ws//uploads/1791979416.png';
 const DEMO_WITHDRAWS = [
 { id:'WD1001', uid:'PX-1001', name:'Ahmed Khan', amount:900, method:'Easypaisa', tid:'1009025', date:'2026-10-14', time:'08:07 AM', status:'success',
 dashboard:12000, invested:12000, dailyProfit:240, remaining:11100, activePlans:3, totalEarned:15400, totalWithdrawn:4200,
 accountName:'Ahmed Khan', accountNumber:'03001234567', rejectReason:'' },
 { id:'WD1002', uid:'PX-1002', name:'Sara Malik', amount:1360, method:'Easypaisa', tid:'1008850', date:'2026-10-14', time:'06:45 PM', status:'pending',
 dashboard:6000, invested:6000, dailyProfit:120, remaining:4640, activePlans:2, totalEarned:6400, totalWithdrawn:2400,
 accountName:'Sara Malik', accountNumber:'03011234567', rejectReason:'' },
 { id:'WD1003', uid:'PX-1003', name:'Bilal Raza', amount:2500, method:'JazzCash', tid:'1007000', date:'2026-10-14', time:'11:22 AM', status:'success',
 dashboard:24000, invested:24000, dailyProfit:480, remaining:21500, activePlans:5, totalEarned:32000, totalWithdrawn:8900,
 accountName:'Bilal Raza', accountNumber:'03021234567', rejectReason:'' },
 { id:'WD1004', uid:'PX-1004', name:'Fatima Noor', amount:1800, method:'Easypaisa', tid:'1005000', date:'2026-10-14', time:'10:11 AM', status:'rejected',
 dashboard:3600, invested:3600, dailyProfit:72, remaining:1800, activePlans:1, totalEarned:2800, totalWithdrawn:900,
 accountName:'Fatima Noor', accountNumber:'03031234567',
 rejectReason:'Aap ke account number aur naam mein mismatch hai. Bara-e-karam sahi details ke saath dobara request karein.' },
 { id:'WD1005', uid:'PX-1005', name:'Usman Tariq', amount:1360, method:'Easypaisa', tid:'1004998', date:'2026-10-13', time:'02:51 PM', status:'success',
 dashboard:18000, invested:18000, dailyProfit:360, remaining:16640, activePlans:4, totalEarned:21000, totalWithdrawn:6800,
 accountName:'Usman Tariq', accountNumber:'03041234567', rejectReason:'' },
 { id:'WD1006', uid:'PX-1006', name:'Ayesha Khan', amount:900, method:'JazzCash', tid:'1004098', date:'2026-10-13', time:'11:22 AM', status:'success',
 dashboard:1200, invested:1200, dailyProfit:24, remaining:300, activePlans:1, totalEarned:800, totalWithdrawn:600,
 accountName:'Ayesha Khan', accountNumber:'03051234567', rejectReason:'' },
 { id:'WD1007', uid:'PX-1007', name:'Hassan Ali', amount:2200, method:'Easypaisa', tid:'1003210', date:'2026-10-12', time:'05:14 PM', status:'rejected',
 dashboard:14000, invested:14000, dailyProfit:280, remaining:11700, activePlans:3, totalEarned:18500, totalWithdrawn:5400,
 accountName:'Hassan Ali', accountNumber:'03061234567',
 rejectReason:'Kam se kam withdrawal amount Rs 2,500 hona chahiye.' },
 { id:'WD1008', uid:'PX-1008', name:'Zainab Shah', amount:1500, method:'Easypaisa', tid:'1002310', date:'2026-10-12', time:'09:40 AM', status:'success',
 dashboard:8400, invested:8400, dailyProfit:168, remaining:6900, activePlans:2, totalEarned:9100, totalWithdrawn:2400,
 accountName:'Zainab Shah', accountNumber:'03071234567', rejectReason:'' },
 { id:'WD1009', uid:'PX-1009', name:'Imran Yousaf', amount:800, method:'JazzCash', tid:'1001410', date:'2026-10-11', time:'03:20 PM', status:'success',
 dashboard:2400, invested:2400, dailyProfit:48, remaining:1600, activePlans:1, totalEarned:3100, totalWithdrawn:600,
 accountName:'Imran Yousaf', accountNumber:'03081234567', rejectReason:'' },
 { id:'WD1010', uid:'PX-1010', name:'Maryam Iqbal', amount:1200, method:'Easypaisa', tid:'1000510', date:'2026-10-11', time:'01:15 PM', status:'pending',
 dashboard:15000, invested:15000, dailyProfit:300, remaining:13800, activePlans:3, totalEarned:19200, totalWithdrawn:5600,
 accountName:'Maryam Iqbal', accountNumber:'03091234567', rejectReason:'' },
 { id:'WD1011', uid:'PX-1001', name:'Ahmed Khan', amount:600, method:'Easypaisa', tid:'TXN8428190', date:'2026-10-10', time:'02:10 PM', status:'success',
 dashboard:12000, invested:12000, dailyProfit:240, remaining:11400, activePlans:3, totalEarned:15400, totalWithdrawn:3600,
 accountName:'Ahmed Khan', accountNumber:'03001234567', rejectReason:'' }
 ];
 let WITHDRAWS = [];
 async function loadWithdraws() {
 if (window.ADMIN_API_CONFIG.baseURL && !window.ADMIN_APP_MODE.DEMO_MODE) {
 try {
 const result = await window.ADMIN_API.get(ADMIN_API_CONFIG.endpoints.getWithdraws);
 if (result.success) {
 const list = result.data.withdraws || result.data || [];
 WITHDRAWS = list.map(normalizeWithdraw);
 render();
 return;
 }
 } catch(e) { console.warn('API failed, using demo'); }
 }
 WITHDRAWS = DEMO_WITHDRAWS.map(normalizeWithdraw);
 render();
 }
 function normalizeWithdraw(w) {
 let dateStr = w.date || '';
 let timeStr = w.time || '';
 if ((!dateStr || !timeStr) && (w.submittedAt || w.createdAt || w.dateIso)) {
 const dt = new Date(w.submittedAt || w.createdAt || w.dateIso);
 dateStr = dt.toISOString().split('T')[0];
 let h = dt.getHours(); const m = String(dt.getMinutes()).padStart(2,'0');
 const ampm = h >= 12 ? 'PM' : 'AM'; h = h % 12; if (h === 0) h = 12;
 timeStr = `${String(h).padStart(2,'0')}:${m} ${ampm}`;
 }
 let status = (w.status || 'pending').toLowerCase();
 if (status === 'approved' || status === 'completed' || status === 'paid') status = 'success';
 if (status === 'failed' || status === 'cancelled') status = 'rejected';
 return {
 id: w.id || ('WD' + Date.now() + Math.random()),
 uid: w.uid || 'PX-0000',
 name: w.name || 'User',
 amount: Number(w.amount || w.withdrawAmount || 0),
 method: w.method || w.paymentMethod || 'Easypaisa',
 tid: w.tid || w.transactionId || '—',
 date: dateStr || '—',
 time: timeStr || '—',
 status: status,
 dashboard: Number(w.dashboard || w.totalDashboard || 0),
 invested: Number(w.invested || w.totalInvested || 0),
 dailyProfit: Number(w.dailyProfit || w.daily || 0),
 remaining: Number(w.remaining || w.remainingBalance || 0),
 activePlans: Number(w.activePlans || 0),
 totalEarned: Number(w.totalEarned || 0),
 totalWithdrawn: Number(w.totalWithdrawn || 0),
 accountName: w.accountName || w.name || 'User',
 accountNumber: w.accountNumber || w.number || '—',
 rejectReason: w.rejectReason || w.reason || ''
 };
 }
 let currentStatus = 'all';
 let currentSearch = '';
 let dateFrom = null;
 let dateTo = null;
 let quickPreset = 'today';
 function todayStr(){ return new Date().toISOString().split('T')[0]; }
 function yesterdayStr(){ const d=new Date(); d.setDate(d.getDate()-1); return d.toISOString().split('T')[0]; }
 function setQuickDate(preset){
 quickPreset = preset;
 const today = todayStr();
 if(preset==='today'){ dateFrom = today; dateTo = today; }
 else if(preset==='yesterday'){ dateFrom = yesterdayStr(); dateTo = yesterdayStr(); }
 else if(preset==='week'){ const d=new Date(); d.setDate(d.getDate()-6); dateFrom = d.toISOString().split('T')[0]; dateTo = today; }
 else if(preset==='month'){ const d=new Date(); d.setDate(d.getDate()-29); dateFrom = d.toISOString().split('T')[0]; dateTo = today; }
 }
 function fmtDate(dateStr){
 if(!dateStr || dateStr === '—') return '—';
 const d = new Date(dateStr);
 return d.toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' });
 }
 function fmtDayHeader(dateStr){
 const today = todayStr();
 const yd = yesterdayStr();
 if(dateStr===today) return 'Today • ' + fmtDate(dateStr);
 if(dateStr===yd) return 'Yesterday • ' + fmtDate(dateStr);
 return fmtDate(dateStr);
 }
 function getFiltered(){
 return WITHDRAWS.filter(d => {
 if(currentStatus !== 'all' && d.status !== currentStatus) return false;
 if(currentSearch){
 const s = currentSearch.toLowerCase();
 if(!(d.name.toLowerCase().includes(s) || d.uid.toLowerCase().includes(s) || d.tid.toLowerCase().includes(s))) return false;
 }
 if(dateFrom && d.date < dateFrom) return false;
 if(dateTo && d.date > dateTo) return false;
 return true;
 });
 }
 function render(){
 const filtered = getFiltered();
 const area = document.getElementById('contentArea');
 document.getElementById('cntAll').textContent = WITHDRAWS.length;
 document.getElementById('cntSuccess').textContent = WITHDRAWS.filter(d=>d.status==='success').length;
 document.getElementById('cntPending').textContent = WITHDRAWS.filter(d=>d.status==='pending').length;
 document.getElementById('cntRejected').textContent = WITHDRAWS.filter(d=>d.status==='rejected').length;
 document.getElementById('headerDate').textContent = quickPreset==='today' ? 'Today' : (quickPreset==='yesterday' ? 'Yesterday' : (quickPreset==='week' ? 'This Week' : (quickPreset==='month' ? 'This Month' : 'Custom')));
 const badge = document.getElementById('dateBadge');
 const dateBtn = document.getElementById('dateBtn');
 if(quickPreset){ badge.classList.add('show'); dateBtn.classList.add('active'); }
 else { badge.classList.remove('show'); dateBtn.classList.remove('active'); }
 if(filtered.length === 0){
 area.innerHTML = `
 <div class="empty-state">
 <div class="empty-icon"><svg viewBox="0 0 24 24"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg></div>
 <div class="empty-title">No Withdrawals Found</div>
 <div class="empty-desc">Try adjusting filters</div>
 </div>`;
 return;
 }
 const groups = {};
 filtered.forEach(d => { if(!groups[d.date]) groups[d.date] = []; groups[d.date].push(d); });
 const sortedDates = Object.keys(groups).sort().reverse();
 area.innerHTML = sortedDates.map(date => {
 const items = groups[date];
 const totalAmt = items.reduce((s,i)=>s+i.amount,0);
 return `
 <div class="day-section">
 <div class="day-head">
 <span class="dot"></span>
 <span class="title">${fmtDayHeader(date)}</span>
 <span class="total-amt">Rs ${totalAmt.toLocaleString('en-IN')}</span>
 <span class="count">${items.length} WD</span>
 </div>
 <div class="wd-list">${items.map((d)=>renderCard(d)).join('')}</div>
 </div>
 `;
 }).join('');
 }
 function renderCard(d){
 const idx = WITHDRAWS.indexOf(d);
 const statusLabel = d.status==='success' ? 'Accepted' : (d.status==='pending' ? 'Pending' : 'Rejected');
 return `
 <div class="wd-item ${d.status}" onclick="openDetail(${idx})">
 <div class="wd-avatar"><img src="${PX_ICON}" alt="PX"></div>
 <div class="wd-info">
 <div class="wd-name">${escapeHtml(d.name)}</div>
 <div class="wd-uid">
 <svg viewBox="0 0 24 24"><path d="M4 7V4h16v3"/><path d="M9 20h6"/><path d="M12 4v16"/></svg>
 <span>${d.uid} • ${d.method}</span>
 </div>
 </div>
 <div class="wd-right">
 <div class="wd-amt">Rs ${d.amount.toLocaleString('en-IN')}</div>
 <span class="wd-status ${d.status}"><span class="sdot"></span>${statusLabel}</span>
 </div>
 </div>
 `;
 }
 function openDetail(idx){
 const d = WITHDRAWS[idx];
 if(!d) return;
 const statusLabel = d.status==='success' ? 'Accepted' : (d.status==='pending' ? 'Pending' : 'Rejected');
 document.getElementById('ddScroll').innerHTML = `
 <div class="dd-hero">
 <div class="dd-avatar"><img src="${PX_ICON}" alt="PX"></div>
 <div class="dd-name">${escapeHtml(d.name)}</div>
 <div class="dd-uid">
 <svg viewBox="0 0 24 24"><path d="M4 7V4h16v3"/><path d="M9 20h6"/><path d="M12 4v16"/></svg>
 ${d.uid}
 </div>
 </div>
 <div class="dd-amount-box">
 <div class="dd-amount-lbl">Withdraw Amount</div>
 <div class="dd-amount-val">Rs ${d.amount.toLocaleString('en-IN')}</div>
 </div>
 <div class="dd-status-line">
 <span class="dd-status-badge ${d.status}"><span class="sdot"></span>${statusLabel}</span>
 </div>
 <div class="dd-section-lbl">Account Overview</div>
 <div class="dd-money-grid">
 <div class="dd-money-card green">
 <div class="dd-money-lbl">
 <svg viewBox="0 0 24 24"><rect x="2" y="6" width="20" height="12" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
 Dashboard
 </div>
 <div class="dd-money-val">Rs ${d.dashboard.toLocaleString('en-IN')}</div>
 </div>
 <div class="dd-money-card blue">
 <div class="dd-money-lbl">
 <svg viewBox="0 0 24 24"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>
 Invested
 </div>
 <div class="dd-money-val">Rs ${d.invested.toLocaleString('en-IN')}</div>
 </div>
 <div class="dd-money-card gold">
 <div class="dd-money-lbl">
 <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
 Daily
 </div>
 <div class="dd-money-val">Rs ${d.dailyProfit.toLocaleString('en-IN')}</div>
 </div>
 </div>
 <div class="dd-section-lbl">Balance Details</div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><rect x="2" y="6" width="20" height="12" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>Remaining</span>
 <span class="dd-row-val green">Rs ${d.remaining.toLocaleString('en-IN')}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>Total Earned</span>
 <span class="dd-row-val green">Rs ${d.totalEarned.toLocaleString('en-IN')}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>Total Withdrawn</span>
 <span class="dd-row-val gold">Rs ${d.totalWithdrawn.toLocaleString('en-IN')}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><path d="M12 2l3 7h7l-5.5 4 2 7L12 16l-6.5 4 2-7L2 9h7z"/></svg>Active Plans</span>
 <span class="dd-row-val blue">${d.activePlans} Plans</span>
 </div>
 <div class="dd-section-lbl">Transaction Info</div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><line x1="4" y1="9" x2="20" y2="9"/><line x1="4" y1="15" x2="20" y2="15"/><line x1="10" y1="3" x2="8" y2="21"/><line x1="16" y1="3" x2="14" y2="21"/></svg>TID</span>
 <span class="dd-row-val mono">${escapeHtml(d.tid)}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>Date</span>
 <span class="dd-row-val blue">${fmtDate(d.date)} • ${d.time}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13"/><path d="M5 12v9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-9"/></svg>Method</span>
 <span class="dd-row-val green">${escapeHtml(d.method)}</span>
 </div>
 <div class="dd-section-lbl">Payout To</div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>Name</span>
 <span class="dd-row-val text">${escapeHtml(d.accountName)}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>Number</span>
 <span class="dd-row-val mono">${escapeHtml(d.accountNumber)}</span>
 </div>
 ${d.status==='rejected' && d.rejectReason ? `
 <div class="dd-section-lbl">Rejection Reason</div>
 <div class="dd-row" style="background:rgba(220,38,38,0.10);border-color:rgba(220,38,38,0.35);">
 <span class="dd-row-lbl" style="color:#fca5a5;"><svg viewBox="0 0 24 24" style="stroke:#fca5a5;"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>Reason</span>
 <span class="dd-row-val red text" style="font-family:'Rajdhani',sans-serif;font-size:12.5px;line-height:1.4;text-align:right;max-width:60%;white-space:normal;">${escapeHtml(d.rejectReason)}</span>
 </div>
 ` : ''}
 <div class="dd-actions">
 <button class="dd-btn close" onclick="closeDetail()">
 <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>Close
 </button>
 </div>
 `;
 document.getElementById('detailOverlay').classList.add('active');
 }
 function closeDetail(){ document.getElementById('detailOverlay').classList.remove('active'); }
 function closeDetailOutside(e){ if(e.target.id==='detailOverlay') closeDetail(); }
 function setStatus(s, el){
 currentStatus = s;
 document.querySelectorAll('#statusChips .chip').forEach(c=>c.classList.remove('active'));
 el.classList.add('active');
 render();
 }
 document.getElementById('searchInput').addEventListener('input', function(){
 currentSearch = this.value.trim();
 render();
 });
 function applyFilters(){ render(); }
 function openDateModal(){
 document.getElementById('dateFrom').value = dateFrom || '';
 document.getElementById('dateTo').value = dateTo || '';
 document.getElementById('dateModal').classList.add('active');
 }
 function closeDateModal(){ document.getElementById('dateModal').classList.remove('active'); }
 function closeDateOutside(e){ if(e.target.id==='dateModal') closeDateModal(); }
 function quickDate(preset, el){
 document.querySelectorAll('.dm-quick-btn').forEach(b=>b.classList.remove('active'));
 el.classList.add('active');
 setQuickDate(preset);
 document.getElementById('dateFrom').value = dateFrom || '';
 document.getElementById('dateTo').value = dateTo || '';
 }
 function applyDateFilter(){
 const from = document.getElementById('dateFrom').value;
 const to = document.getElementById('dateTo').value;
 dateFrom = from || null;
 dateTo = to || null;
 if(from === todayStr() && to === todayStr()) quickPreset = 'today';
 else if(from === yesterdayStr() && to === yesterdayStr()) quickPreset = 'yesterday';
 else quickPreset = 'custom';
 closeDateModal();
 render();
 }
 function openSideMenu(){ document.getElementById('sideMenu').classList.add('active'); document.getElementById('sideMenuOverlay').classList.add('active'); }
 function closeSideMenu(){ document.getElementById('sideMenu').classList.remove('active'); document.getElementById('sideMenuOverlay').classList.remove('active'); }
 function menuGo(page){ closeSideMenu(); setTimeout(()=>{ window.location.href = page; }, 250); }
 function logoutAdmin(){ if(!confirm('Logout?')) return; try{ localStorage.clear(); sessionStorage.clear(); }catch(e){} closeSideMenu(); setTimeout(()=>{ window.location.href='admin-login.html'; },250); }
 function goTo(page){ setTimeout(()=>{ window.location.href = page; }, 100); }
 function escapeHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
 function showToast(msg, type=''){
 const holder = document.getElementById('toastHolder');
 const t = document.createElement('div');
 t.className = 'toast ' + type;
 t.textContent = msg;
 holder.appendChild(t);
 requestAnimationFrame(()=>t.classList.add('show'));
 setTimeout(()=>{ t.classList.remove('show'); setTimeout(()=>t.remove(),400); }, 1700);
 }
 /* MIDNIGHT RESET */
 function scheduleMidnightReset(){
 const now = new Date();
 const midnight = new Date();
 midnight.setHours(24,0,0,0);
 const ms = midnight - now;
 setTimeout(()=>{
 setQuickDate('today');
 quickPreset = 'today';
 document.querySelectorAll('.dm-quick-btn').forEach(b=>{ b.classList.toggle('active', b.dataset.quick==='today'); });
 render();
 showToast('New day — showing today\'s withdrawals');
 scheduleMidnightReset();
 }, ms);
 }
 /* INIT */
 setQuickDate('today');
 loadWithdraws();
 scheduleMidnightReset();
 /* ZOOM BLOCK */
 document.addEventListener('gesturestart', e=>e.preventDefault());
 document.addEventListener('gesturechange', e=>e.preventDefault());
 document.addEventListener('gestureend', e=>e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e=>{ const n=Date.now(); if(n-lastTouch<=300) e.preventDefault(); lastTouch=n; }, {passive:false});
 document.addEventListener('wheel', e=>{ if(e.ctrlKey) e.preventDefault(); }, {passive:false});
 document.addEventListener('keydown', e=>{ if((e.ctrlKey||e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault(); });