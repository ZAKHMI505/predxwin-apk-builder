window.ADMIN_APP_MODE = {
 DEMO_MODE: true 
 };
 window.ADMIN_API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 getUpdates: "/admin/updates",
 postUpdate: "/admin/updates",
 deleteUpdate: "/admin/updates/:id",
 saveSetting: "/admin/settings"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const token = localStorage.getItem('adminToken');
 if (token) h["X-Admin-Token"] = token;
 return h;
 }
 };
 window.ADMIN_API = {
 async call(endpoint, method = "GET", body = null) {
 if (!ADMIN_API_CONFIG.baseURL) return { success: false, error: "Admin server not configured" };
 const url = ADMIN_API_CONFIG.baseURL + endpoint;
 const options = { method, headers: ADMIN_API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) return { success: false, error: data.message || data.error || "Request failed", data };
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); },
 put(ep, body) { return this.call(ep, "PUT", body); },
 del(ep) { return this.call(ep, "DELETE"); }
 };
(function checkAuth() {
 try {
 const logged = localStorage.getItem('adminLoggedIn');
 const demo = window.ADMIN_APP_MODE.DEMO_MODE;
 if (demo) {
 if (logged !== 'true') {
 localStorage.setItem('adminLoggedIn', 'true');
 localStorage.setItem('adminEmail', 'demo-admin@predxprofit.pk');
 localStorage.setItem('adminName', 'Demo Admin');
 }
 return;
 }
 if (logged !== 'true') window.location.replace('admin-login.html');
 } catch(e) { window.location.replace('admin-login.html'); }
 })();
 let UPDATES = [];
 async function loadUpdates() {
 if (window.ADMIN_API_CONFIG.baseURL && !window.ADMIN_APP_MODE.DEMO_MODE) {
 try {
 const res = await window.ADMIN_API.get(ADMIN_API_CONFIG.endpoints.getUpdates);
 if (res.success) {
 UPDATES = (res.data.updates || res.data || []).map(normalizeUpdate);
 renderUpdates();
 return;
 }
 } catch(e) { console.warn('API updates failed, using local'); }
 }
 try {
 const saved = localStorage.getItem('appUpdates');
 if (saved) {
 UPDATES = JSON.parse(saved).map(normalizeUpdate);
 } else {
 UPDATES = [
 {
 id: 'seed1',
 version: 'v1.0.0',
 title: 'Welcome to Predx Profit!',
 body: 'We are excited to launch our new investment platform with premium features.\n\n• Fast deposits\n• Daily ad rewards\n• Team salary system\n• 24/7 support',
 date: '14 Oct 2026',
 timestamp: Date.now() - 86400000
 }
 ];
 saveUpdatesToLocal();
 }
 } catch(e) { UPDATES = []; }
 renderUpdates();
 }
 function normalizeUpdate(u) {
 return {
 id: u.id || ('UPD' + Date.now() + Math.random()),
 version: u.version || 'v1.0.0',
 title: u.title || 'Update',
 body: u.body || u.description || '',
 date: u.date || new Date().toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' }),
 timestamp: u.timestamp || u.createdAt || Date.now()
 };
 }
 function saveUpdatesToLocal() {
 try {
 localStorage.setItem('appUpdates', JSON.stringify(UPDATES));
 } catch(e) {}
 }
 function renderUpdates(){
 const list = document.getElementById('updatesList');
 const count = document.getElementById('updatesCount');
 if(!list) return;
 count.textContent = UPDATES.length + ' POST' + (UPDATES.length !== 1 ? 'S' : '');
 if(UPDATES.length === 0){
 list.innerHTML = `<div style="text-align:center;padding:40px 20px;color:#7c9a89;font-family:'Rajdhani',sans-serif;font-size:12px;font-weight:800;letter-spacing:1px;text-transform:uppercase;">No updates posted yet</div>`;
 return;
 }
 list.innerHTML = UPDATES.map((u, i) => `
 <div class="update-card">
 <div class="update-delete" onclick="deleteUpdate(${i})">
 <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
 </div>
 <div class="update-head">
 <span class="update-version">${escapeHtml(u.version)}</span>
 <span class="update-date">${escapeHtml(u.date)}</span>
 </div>
 <div class="update-title">${escapeHtml(u.title)}</div>
 <div class="update-body">${escapeHtml(u.body)}</div>
 </div>
 `).join('');
 }
 async function deleteUpdate(idx) {
 const u = UPDATES[idx];
 if (!u) return;
 if (!confirm('Delete this update?\n\n' + u.title)) return;
 if (window.ADMIN_API_CONFIG.baseURL && !window.ADMIN_APP_MODE.DEMO_MODE) {
 try {
 const ep = ADMIN_API_CONFIG.endpoints.deleteUpdate.replace(':id', u.id);
 await window.ADMIN_API.del(ep);
 } catch(e) {}
 }
 UPDATES.splice(idx, 1);
 saveUpdatesToLocal();
 renderUpdates();
 showToast('Update deleted');
 }
 function openPostUpdateDialog(){
 document.getElementById('updateVersion').value = '';
 document.getElementById('updateTitle').value = '';
 document.getElementById('updateBody').value = '';
 document.getElementById('postDialog').classList.add('active');
 setTimeout(()=>{ document.getElementById('updateVersion').focus(); }, 250);
 }
 function closePostDialog(){
 document.getElementById('postDialog').classList.remove('active');
 }
 function closePostOutside(e){
 if(e.target.id === 'postDialog') closePostDialog();
 }
 async function submitUpdate(){
 const version = (document.getElementById('updateVersion').value || '').trim();
 const title = (document.getElementById('updateTitle').value || '').trim();
 const body = (document.getElementById('updateBody').value || '').trim();
 if(!version){ shakeField('updateVersion'); showToast('Enter version'); return; }
 if(!title){ shakeField('updateTitle'); showToast('Enter title'); return; }
 if(!body){ shakeField('updateBody'); showToast('Enter description'); return; }
 const now = new Date();
 const dateStr = now.toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' });
 const newUpdate = {
 id: 'UPD' + Date.now(),
 version, title, body,
 date: dateStr,
 timestamp: now.getTime()
 };
 if (window.ADMIN_API_CONFIG.baseURL && !window.ADMIN_APP_MODE.DEMO_MODE) {
 try {
 const res = await window.ADMIN_API.post(ADMIN_API_CONFIG.endpoints.postUpdate, newUpdate);
 if (res.success && res.data.update) {
 UPDATES.unshift(normalizeUpdate(res.data.update));
 } else {
 UPDATES.unshift(newUpdate);
 }
 } catch(e) {
 UPDATES.unshift(newUpdate);
 }
 } else {
 UPDATES.unshift(newUpdate);
 }
 saveUpdatesToLocal();
 showToast('✅ Update posted successfully!');
 closePostDialog();
 renderUpdates();
 setTimeout(() => {
 document.getElementById('updatesList').scrollIntoView({ behavior:'smooth', block:'start' });
 }, 200);
 }
 function shakeField(id){
 const el = document.getElementById(id);
 if(!el) return;
 el.style.transition = 'transform .1s ease';
 el.style.transform = 'translateX(-8px)';
 setTimeout(()=>el.style.transform='translateX(8px)', 100);
 setTimeout(()=>el.style.transform='translateX(-6px)', 200);
 setTimeout(()=>el.style.transform='translateX(6px)', 300);
 setTimeout(()=>el.style.transform='translateX(0)', 400);
 el.focus();
 }
 function saveSetting(key, value) {
 try {
 const settings = JSON.parse(localStorage.getItem('adminSettings') || '{}');
 settings[key] = value;
 localStorage.setItem('adminSettings', JSON.stringify(settings));
 } catch(e) {}
 showToast(key + ' = ' + value);
 if (window.ADMIN_API_CONFIG.baseURL && !window.ADMIN_APP_MODE.DEMO_MODE) {
 window.ADMIN_API.post(ADMIN_API_CONFIG.endpoints.saveSetting, { [key]: value }).catch(()=>{});
 }
 }
 function loadSettings() {
 try {
 const settings = JSON.parse(localStorage.getItem('adminSettings') || '{}');
 if (settings.maintenance !== undefined) document.getElementById('setMaintenance').checked = settings.maintenance;
 if (settings.pushNotif !== undefined) document.getElementById('setPush').checked = settings.pushNotif;
 if (settings.emailAlerts !== undefined) document.getElementById('setEmail').checked = settings.emailAlerts;
 if (settings['2fa'] !== undefined) document.getElementById('set2FA').checked = settings['2fa'];
 } catch(e) {}
 }
 loadUpdates();
 loadSettings();
 function openSideMenu(){ document.getElementById('sideMenu').classList.add('active'); document.getElementById('sideMenuOverlay').classList.add('active'); }
 function closeSideMenu(){ document.getElementById('sideMenu').classList.remove('active'); document.getElementById('sideMenuOverlay').classList.remove('active'); }
 function menuGo(page){ closeSideMenu(); setTimeout(()=>{ window.location.href = page; }, 250); }
 function logoutAdmin(){ if(!confirm('Logout?')) return; try{ localStorage.clear(); sessionStorage.clear(); }catch(e){} closeSideMenu(); setTimeout(()=>{ window.location.href='admin-login.html'; },250); }
 function goTo(page){ setTimeout(()=>{ window.location.href = page; }, 100); }
 function escapeHtml(s){
 return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
 }
 function showToast(msg){
 const holder = document.getElementById('toastHolder');
 const t = document.createElement('div');
 t.className = 'toast';
 t.textContent = msg;
 holder.appendChild(t);
 requestAnimationFrame(()=>t.classList.add('show'));
 setTimeout(()=>{ t.classList.remove('show'); setTimeout(()=>t.remove(),400); }, 1700);
 }
 /* ZOOM BLOCK */
 document.addEventListener('gesturestart', e=>e.preventDefault());
 document.addEventListener('gesturechange', e=>e.preventDefault());
 document.addEventListener('gestureend', e=>e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e=>{ const n=Date.now(); if(n-lastTouch<=300) e.preventDefault(); lastTouch=n; }, {passive:false});
 document.addEventListener('wheel', e=>{ if(e.ctrlKey) e.preventDefault(); }, {passive:false});
 document.addEventListener('keydown', e=>{ if((e.ctrlKey||e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault(); });