const SUPABASE_URL = 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
let supabaseClient = null;
if (SUPABASE_URL !== 'YOUR_SUPABASE_URL' && SUPABASE_ANON_KEY !== 'YOUR_SUPABASE_ANON_KEY') {
 supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
 console.log('✅ Supabase connected (Admin)');
} else {
 console.warn('⚠️ Supabase config missing — DEMO MODE');
}
(function(){ 
 try{ 
 if(localStorage.getItem('adminLoggedIn') !== 'true') {
 window.location.replace('admin-login.html');
 }
 }catch(e){
 window.location.replace('admin-login.html');
 } 
})();
const PX_ICON = 'https://premium-host.ct.ws//uploads/1791979416.png';
const STORAGE_KEY = 'admin_support_chats_v3';
const DEFAULT_CHATS = [
 { uid:'PX-1001', name:'Ahmed Khan', online:true, messages:[
 { from:'user', text:'Hi, I need help with my deposit', time:'10:20 AM' },
 { from:'admin', text:'Hello! Sure, I\'m here to help.', time:'10:21 AM' }
 ], time:'10:21 AM', unread:0 }
];
let CHATS = [];
let currentChatIdx = null;
let realtimeChannel = null;
async function loadChats() {
 if (supabaseClient) {
 try {
 const { data: chats, error } = await supabaseClient
 .from('chats')
 .select('*')
 .order('created_at', { ascending: false });
 if (!error && chats) {
 CHATS = await Promise.all(chats.map(async (c) => {
 const { data: msgs } = await supabaseClient
 .from('messages')
 .select('*')
 .eq('chat_id', c.id)
 .order('created_at', { ascending: true });
 return {
 id: c.id,
 uid: c.uid,
 name: c.name,
 online: c.online !== false,
 messages: (msgs || []).map(m => ({
 from: m.from_role,
 text: m.text,
 image: m.image_url,
 file: m.file_name,
 fileSize: m.file_size,
 time: m.time
 })),
 time: c.last_time || '—',
 unread: c.unread || 0
 };
 }));
 renderChats();
 setupRealtime();
 updateConnStatus(true);
 return;
 }
 } catch(e) {
 console.warn('Supabase load failed:', e);
 updateConnStatus(false);
 }
 }
 try {
 const saved = localStorage.getItem(STORAGE_KEY);
 if (saved) CHATS = JSON.parse(saved);
 else CHATS = JSON.parse(JSON.stringify(DEFAULT_CHATS));
 } catch(e) { CHATS = JSON.parse(JSON.stringify(DEFAULT_CHATS)); }
 renderChats();
 updateConnStatus(false);
}
function saveChats() {
 try { localStorage.setItem(STORAGE_KEY, JSON.stringify(CHATS)); } catch(e) {}
}
function updateConnStatus(connected) {
 const el = document.getElementById('connStatus');
 if (el) el.textContent = connected ? 'Live • Connected' : 'Demo Mode';
}
function setupRealtime() {
 if (!supabaseClient) return;
 if (realtimeChannel) supabaseClient.removeChannel(realtimeChannel);
 realtimeChannel = supabaseClient
 .channel('admin-support-realtime')
 .on('postgres_changes',
 { event: 'INSERT', schema: 'public', table: 'messages' },
 (payload) => {
 const m = payload.new;
 if (m.from_role === 'admin') return;
 handleIncomingMessage(m);
 }
 )
 .on('postgres_changes',
 { event: 'INSERT', schema: 'public', table: 'chats' },
 () => { loadChats(); }
 )
 .subscribe((status) => {
 if (status === 'SUBSCRIBED') updateConnStatus(true);
 });
}
async function handleIncomingMessage(m) {
 let chat = CHATS.find(c => c.id === m.chat_id);
 if (!chat) {
 await loadChats();
 chat = CHATS.find(c => c.id === m.chat_id);
 if (!chat) return;
 }
 chat.messages.push({
 from: m.from_role,
 text: m.text,
 image: m.image_url,
 file: m.file_name,
 time: m.time
 });
 const currentChat = CHATS[currentChatIdx];
 if (currentChat && currentChat.id === m.chat_id) {
 renderMessages();
 scrollChatBottom();
 if (supabaseClient) {
 supabaseClient.from('chats').update({ unread: 0 }).eq('id', chat.id);
 }
 } else {
 chat.unread = (chat.unread || 0) + 1;
 chat.time = m.time || '—';
 renderChats();
 showToast('Naya message: ' + chat.name);
 }
}
function renderChats() {
 const list = document.getElementById('chatList');
 const countEl = document.getElementById('chatCount');
 if (!list) return;
 countEl.textContent = CHATS.length + ' CHAT' + (CHATS.length !== 1 ? 'S' : '');
 if (CHATS.length === 0) {
 list.innerHTML = '<div style="text-align:center;padding:60px 20px;color:#7c9a89;font-family:\'Rajdhani\',sans-serif;font-size:12px;font-weight:800;letter-spacing:1px;text-transform:uppercase;">No Conversations Yet</div>';
 return;
 }
 list.innerHTML = CHATS.map((c, idx) => {
 const last = c.messages[c.messages.length - 1];
 const lastText = last ? (last.text || (last.image ? '📷 Image' : (last.file ? '📄 ' + last.file : 'Message'))) : 'No messages yet';
 const unread = c.unread > 0;
 return `
 <div class="chat-item" onclick="openChat(${idx})">
 <div class="chat-avatar ${c.online ? '' : 'offline'}">
 <img src="${PX_ICON}" alt="PX">
 </div>
 <div class="chat-info">
 <div class="chat-name">${escapeHtml(c.name)}</div>
 <div class="chat-last-msg ${unread ? 'unread' : ''}">${escapeHtml(lastText)}</div>
 </div>
 <div class="chat-meta">
 <div class="chat-time">${escapeHtml(c.time)}</div>
 ${unread ? `<div class="chat-unread">${c.unread}</div>` : ''}
 </div>
 </div>
 `;
 }).join('');
}
function openChat(idx) {
 const c = CHATS[idx];
 if (!c) return;
 currentChatIdx = idx;
 c.unread = 0;
 if (supabaseClient && c.id) {
 supabaseClient.from('chats').update({ unread: 0 }).eq('id', c.id);
 }
 saveChats();
 document.getElementById('chatUserName').textContent = c.name;
 document.getElementById('chatUserUid').innerHTML = `UID: <strong>${escapeHtml(c.uid)}</strong>`;
 document.getElementById('chatAvatar').className = 'agent-avatar-sm' + (c.online ? '' : ' offline');
 renderMessages();
 document.getElementById('listScreen').classList.add('hidden');
 document.getElementById('chatScreen').classList.add('active');
 setTimeout(scrollChatBottom, 100);
}
function closeChat() {
 document.getElementById('listScreen').classList.remove('hidden');
 document.getElementById('chatScreen').classList.remove('active');
 currentChatIdx = null;
 renderChats();
}
function renderMessages() {
 const c = CHATS[currentChatIdx];
 if (!c) return;
 const area = document.getElementById('chatMessages');
 if (!area) return;
 let html = `<div class="date-divider"><span>Today</span></div>`;
 c.messages.forEach(m => { html += renderBubble(m); });
 area.innerHTML = html;
}
function renderBubble(m) {
 const isAdmin = m.from === 'admin';
 const cls = isAdmin ? 'admin' : 'user';
 const tick = isAdmin
 ? `<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/><polyline points="22 12 13 21 11 19"/></svg>`
 : '';
 const imageHtml = m.image ? `<img class="msg-image" src="${m.image}" alt="Image">` : '';
 const fileHtml = m.file ? `<div style="display:flex;align-items:center;gap:8px;padding:6px 8px;background:rgba(0,0,0,0.15);border-radius:8px;margin-bottom:4px;"><svg viewBox="0 0 24 24" style="width:18px;height:18px;stroke:#86efac;stroke-width:2.4;fill:none;flex-shrink:0;"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><polyline points="13 2 13 9 20 9"/></svg><span style="font-size:12px;font-weight:600;">${escapeHtml(m.file)}</span></div>` : '';
 const textHtml = m.text ? `<span class="msg-text">${escapeHtml(m.text).replace(/\n/g, '<br>')}</span>` : '';
 return `
 <div class="msg-row ${cls}">
 <div class="msg-avatar"><img src="${PX_ICON}" alt="PX"></div>
 <div class="msg-bubble">
 ${imageHtml}
 ${fileHtml}
 ${textHtml}
 <span class="msg-time">${escapeHtml(m.time || '')}${tick}</span>
 </div>
 </div>
 `;
}
async function sendMessage() {
 if (currentChatIdx === null) return;
 const c = CHATS[currentChatIdx];
 const input = document.getElementById('msgInput');
 const text = (input.value || '').trim();
 if (!text) return;
 const now = nowTime();
 c.messages.push({ from:'admin', text, time: now });
 c.time = now;
 input.value = '';
 autoResize(input);
 renderMessages();
 scrollChatBottom();
 if (supabaseClient && c.id) {
 try {
 const { error } = await supabaseClient.from('messages').insert({
 chat_id: c.id,
 from_role: 'admin',
 text: text,
 time: now
 });
 if (error) throw error;
 await supabaseClient.from('chats').update({
 last_message: text.slice(0, 50),
 last_time: now
 }).eq('id', c.id);
 } catch(e) {
 console.error('Send failed:', e);
 showToast('Message failed: ' + e.message);
 }
 }
 saveChats();
}
async function handleImage(input) {
 const file = input.files && input.files[0];
 if (!file) return;
 if (file.size > 5 * 1024 * 1024) { showToast('Image too large (max 5MB)'); input.value = ''; return; }
 if (currentChatIdx === null) return;
 const c = CHATS[currentChatIdx];
 const reader = new FileReader();
 reader.onload = async e => {
 const dataUrl = e.target.result;
 const now = nowTime();
 c.messages.push({ from:'admin', text:'', image: dataUrl, time: now });
 renderMessages();
 scrollChatBottom();
 if (supabaseClient && c.id) {
 try {
 const res = await fetch(dataUrl);
 const blob = await res.blob();
 const fileName = `${c.id}/${Date.now()}.jpg`;
 const { error: upErr } = await supabaseClient.storage
 .from('chat-images')
 .upload(fileName, blob, { contentType: file.type });
 if (upErr) throw upErr;
 const { data: urlData } = supabaseClient.storage
 .from('chat-images')
 .getPublicUrl(fileName);
 await supabaseClient.from('messages').insert({
 chat_id: c.id,
 from_role: 'admin',
 image_url: urlData.publicUrl,
 time: now
 });
 await supabaseClient.from('chats').update({
 last_message: '📷 Image',
 last_time: now
 }).eq('id', c.id);
 } catch(e) {
 console.warn('Image upload failed:', e);
 showToast('Image upload failed');
 }
 }
 showToast('Image sent!');
 };
 reader.readAsDataURL(file);
 input.value = '';
}
function nowTime() {
 const d = new Date();
 let h = d.getHours(); const m = String(d.getMinutes()).padStart(2, '0');
 const ampm = h >= 12 ? 'PM' : 'AM';
 h = h % 12; if (h === 0) h = 12;
 return `${h}:${m} ${ampm}`;
}
function scrollChatBottom() { const a = document.getElementById('chatMessages'); if (a) a.scrollTop = a.scrollHeight; }
function autoResize(el) { el.style.height = 'auto'; el.style.height = Math.min(el.scrollHeight, 110) + 'px'; }
function escapeHtml(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
/* SIDE MENU */
function openSideMenu() { document.getElementById('sideMenu').classList.add('active'); document.getElementById('sideMenuOverlay').classList.add('active'); }
function closeSideMenu() { document.getElementById('sideMenu').classList.remove('active'); document.getElementById('sideMenuOverlay').classList.remove('active'); }
function menuGo(page) { closeSideMenu(); setTimeout(() => { window.location.href = page; }, 250); }
function logoutAdmin() { 
 if(!confirm('Logout?')) return; 
 try { 
 localStorage.removeItem('adminLoggedIn');
 localStorage.removeItem('adminToken');
 localStorage.removeItem('adminEmail');
 localStorage.removeItem('adminName');
 localStorage.removeItem('adminRole');
 sessionStorage.clear(); 
 } catch(e){} 
 closeSideMenu(); 
 setTimeout(()=>{ window.location.href='admin-login.html'; },250); 
}
function goTo(page) { setTimeout(()=>{ window.location.href = page; }, 100); }
function showToast(msg) {
 const holder = document.getElementById('toastHolder');
 const t = document.createElement('div');
 t.className = 'toast'; t.textContent = msg;
 holder.appendChild(t);
 requestAnimationFrame(() => t.classList.add('show'));
 setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 400); }, 1700);
}
/* INPUT */
const msgInput = document.getElementById('msgInput');
msgInput.addEventListener('input', () => autoResize(msgInput));
msgInput.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } });
/* INIT */
loadChats();
/* ZOOM BLOCK */
document.addEventListener('gesturestart', e => e.preventDefault());
document.addEventListener('gesturechange', e => e.preventDefault());
document.addEventListener('gestureend', e => e.preventDefault());
let lastTouch = 0;
document.addEventListener('touchend', e => { const n = Date.now(); if (n - lastTouch <= 300) e.preventDefault(); lastTouch = n; }, { passive:false });
document.addEventListener('wheel', e => { if (e.ctrlKey) e.preventDefault(); }, { passive:false });
document.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault(); });