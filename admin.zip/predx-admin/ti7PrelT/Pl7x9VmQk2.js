(function () {
  var root = document.getElementById('planList');
  if (!root || !localStorage.getItem('predx_admin_token')) return;
  function field(label, key, value, type) {
    var wrapper = document.createElement('label'); wrapper.className = 'dm-row';
    var title = document.createElement('span'); title.className = 'dm-lbl'; title.textContent = label;
    var input = document.createElement('input'); input.className = 'dm-input'; input.name = key;
    input.type = type || 'text'; input.value = value; input.required = true;
    if (type === 'number') { input.min = '0'; input.step = 'any'; }
    wrapper.append(title, input); return wrapper;
  }
  window.__predxAdminCall('POST', 'admin/plans', {}).then(function (plans) {
    root.replaceChildren();
    plans.forEach(function (plan) {
      var form = document.createElement('form'); form.className = 'detail-dialog';
      var heading = document.createElement('h2'); heading.className = 'dm-title'; heading.textContent = plan.name;
      form.append(heading, field('Name', 'name', plan.name), field('Price (Rs)', 'price', plan.price, 'number'),
        field('Daily return (Rs)', 'daily_return', plan.daily_return, 'number'),
        field('Duration (days)', 'duration_days', plan.duration_days, 'number'),
        field('Daily withdrawal limit (Rs)', 'max_daily_withdraw', plan.max_daily_withdraw, 'number'));
      var activeLabel = document.createElement('label'); activeLabel.className = 'dm-row';
      var active = document.createElement('input'); active.type = 'checkbox'; active.checked = plan.active;
      activeLabel.append(active, document.createTextNode(' Active')); form.append(activeLabel);
      var save = document.createElement('button'); save.type = 'submit'; save.className = 'dm-btn apply'; save.textContent = 'Save';
      var status = document.createElement('p'); status.setAttribute('role', 'status');
      form.append(save, status);
      form.addEventListener('submit', function (event) {
        event.preventDefault(); save.disabled = true;
        var values = new FormData(form);
        window.__predxAdminCall('POST', 'admin/plan/save', {
          id: plan.id, name: values.get('name'), price: Number(values.get('price')),
          daily_return: Number(values.get('daily_return')), duration_days: Number(values.get('duration_days')),
          max_daily_withdraw: Number(values.get('max_daily_withdraw')), active: active.checked, sort_order: plan.sort_order,
        }).then(function () { status.textContent = 'Saved'; }).catch(function (error) {
          status.textContent = error.message;
        }).finally(function () { save.disabled = false; });
      });
      root.append(form);
    });
  }).catch(function (error) { root.textContent = error.message; });
})();
