window.ADMIN_APP_MODE = {
 DEMO_MODE: true 
 };
 window.ADMIN_API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 getPendingDeposits: "/admin/deposits/pending",
 approveDeposit: "/admin/deposits/:id/approve",
 rejectDeposit: "/admin/deposits/:id/reject",
 getUser: "/admin/users/:uid"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const token = localStorage.getItem('adminToken');
 if (token) h["X-Admin-Token"] = token;
 return h;
 }
 };
 window.ADMIN_API = {
 async call(endpoint, method = "GET", body = null) {
 if (!ADMIN_API_CONFIG.baseURL) return { success: false, error: "Admin server not configured" };
 const url = ADMIN_API_CONFIG.baseURL + endpoint;
 const options = { method, headers: ADMIN_API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) return { success: false, error: data.message || data.error || "Request failed", data };
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); },
 put(ep, body) { return this.call(ep, "PUT", body); }
 };
(function checkAuth() {
 try {
 const logged = localStorage.getItem('adminLoggedIn');
 const demo = window.ADMIN_APP_MODE.DEMO_MODE;
 if (demo) {
 if (logged !== 'true') {
 localStorage.setItem('adminLoggedIn', 'true');
 localStorage.setItem('adminEmail', 'demo-admin@predxprofit.pk');
 localStorage.setItem('adminName', 'Demo Admin');
 }
 return;
 }
 if (logged !== 'true') window.location.replace('admin-login.html');
 } catch(e) { window.location.replace('admin-login.html'); }
 })();
 const PX_ICON = 'https://premium-host.ct.ws//uploads/1791979416.png';
 const DEMO_REQUESTS = [
 { id:'DEP1001', uid:'PX-1003', name:'Bilal Raza', amount:2400, plan:'Rs 2,400 Plan', tid:'TXN8437102', date:'14 Oct 2026', time:'08:42 AM', accountName:'Bilal Raza', accountNumber:'03021234567', method:'Easypaisa', screenshot:'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=500&q=80' },
 { id:'DEP1002', uid:'PX-1009', name:'Imran Yousaf', amount:600, plan:'Rs 600 Plan', tid:'TXN8431460', date:'14 Oct 2026', time:'09:40 AM', accountName:'Imran Yousaf', accountNumber:'03081234567', method:'Easypaisa', screenshot:'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=500&q=80' },
 { id:'DEP1003', uid:'PX-1006', name:'Ayesha Khan', amount:1200, plan:'Rs 1,200 Plan', tid:'TXN8434700', date:'14 Oct 2026', time:'10:15 AM', accountName:'Ayesha Khan', accountNumber:'03051234567', method:'JazzCash', screenshot:'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=500&q=80' }
 ];
 let REQUESTS = [];
 let pendingRejectIdx = null;
 let currentDetailIdx = null;
 async function loadRequests() {
 if (window.ADMIN_API_CONFIG.baseURL && !window.ADMIN_APP_MODE.DEMO_MODE) {
 try {
 const res = await window.ADMIN_API.get(ADMIN_API_CONFIG.endpoints.getPendingDeposits);
 if (res.success) {
 const list = res.data.deposits || res.data.requests || res.data || [];
 REQUESTS = list.map(normalizeRequest);
 render();
 return;
 }
 } catch(e) { console.warn('API pending failed, using local'); }
 }
 try {
 const saved = localStorage.getItem('pendingDeposits');
 if (saved) {
 REQUESTS = JSON.parse(saved).map(normalizeRequest);
 } else {
 REQUESTS = DEMO_REQUESTS.map(normalizeRequest);
 saveRequestsToLocal();
 }
 } catch(e) { REQUESTS = []; }
 render();
 }
 function normalizeRequest(r) {
 return {
 id: r.id || ('DEP' + Date.now() + Math.random()),
 uid: r.uid || 'PX-0000',
 name: r.name || 'User',
 amount: Number(r.amount || r.planAmount || 0),
 plan: r.plan || ('Rs ' + Number(r.amount || r.planAmount || 0).toLocaleString('en-IN') + ' Plan'),
 tid: r.tid || r.transactionId || '—',
 date: r.date || '—',
 time: r.time || '—',
 accountName: r.accountName || r.name || 'User',
 accountNumber: r.accountNumber || r.number || '—',
 method: r.method || 'Easypaisa',
 screenshot: r.screenshot || r.screenshotUrl || ''
 };
 }
 function saveRequestsToLocal() {
 try {
 localStorage.setItem('pendingDeposits', JSON.stringify(REQUESTS));
 } catch(e) {}
 }
 function render(){
 const list = document.getElementById('depList');
 const countEl = document.getElementById('pendingCount');
 if(!list) return;
 countEl.textContent = REQUESTS.length + ' REQ';
 document.getElementById('statPending').textContent = REQUESTS.length;
 const totalAmt = REQUESTS.reduce((s,r)=>s+r.amount, 0);
 document.getElementById('statAmount').textContent = 'Rs ' + totalAmt.toLocaleString('en-IN');
 if(REQUESTS.length === 0){
 list.innerHTML = `
 <div class="empty-state">
 <div class="empty-icon"><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg></div>
 <div class="empty-title">All Caught Up!</div>
 <div class="empty-desc">No pending deposit requests</div>
 </div>`;
 return;
 }
 list.innerHTML = REQUESTS.map((r, idx) => `
 <div class="dep-item" onclick="openDetail(${idx})">
 <div class="dep-avatar"><img src="${PX_ICON}" alt="PX"></div>
 <div class="dep-info">
 <div class="dep-name">${escapeHtml(r.name)}</div>
 <div class="dep-uid">
 <svg viewBox="0 0 24 24"><path d="M4 7V4h16v3"/><path d="M9 20h6"/><path d="M12 4v16"/></svg>
 <span>${r.uid} • ${r.method}</span>
 </div>
 </div>
 <div class="dep-right">
 <div class="dep-amt">Rs ${r.amount.toLocaleString('en-IN')}</div>
 <span class="dep-status"><span class="sdot"></span>Pending</span>
 </div>
 </div>
 `).join('');
 }
 function openDetail(idx){
 const r = REQUESTS[idx];
 if(!r) return;
 currentDetailIdx = idx;
 document.getElementById('ddScroll').innerHTML = `
 <div class="dd-hero">
 <div class="dd-avatar"><img src="${PX_ICON}" alt="PX"></div>
 <div class="dd-name">${escapeHtml(r.name)}</div>
 <div class="dd-uid">
 <svg viewBox="0 0 24 24"><path d="M4 7V4h16v3"/><path d="M9 20h6"/><path d="M12 4v16"/></svg>
 ${r.uid}
 </div>
 <div>
 <span class="dd-status-pill"><span class="sdot"></span>Pending Request</span>
 </div>
 </div>
 <div class="dd-amount-box">
 <div class="dd-amount-lbl">Deposit Amount</div>
 <div class="dd-amount-val">Rs ${r.amount.toLocaleString('en-IN')}</div>
 </div>
 <div class="dd-section-lbl">
 <svg viewBox="0 0 24 24" style="width:11px;height:11px;stroke:#fbbf24;stroke-width:2.8;fill:none;stroke-linecap:round;stroke-linejoin:round;"><path d="M12 2l3 7h7l-5.5 4 2 7L12 16l-6.5 4 2-7L2 9h7z"/></svg>
 Plan & Transaction
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><path d="M12 2l3 7h7l-5.5 4 2 7L12 16l-6.5 4 2-7L2 9h7z"/></svg>Plan</span>
 <span class="dd-row-val gold">${escapeHtml(r.plan)}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><line x1="4" y1="9" x2="20" y2="9"/><line x1="4" y1="15" x2="20" y2="15"/><line x1="10" y1="3" x2="8" y2="21"/><line x1="16" y1="3" x2="14" y2="21"/></svg>TID</span>
 <span class="dd-row-val mono">${escapeHtml(r.tid)}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>Date</span>
 <span class="dd-row-val blue">${escapeHtml(r.date)} • ${escapeHtml(r.time)}</span>
 </div>
 <div class="dd-section-lbl">
 <svg viewBox="0 0 24 24" style="width:11px;height:11px;stroke:#fbbf24;stroke-width:2.8;fill:none;stroke-linecap:round;stroke-linejoin:round;"><path d="M3 21h18M5 21V7l7-4 7 4v14M9 21v-6h6v6"/></svg>
 Payment Sent From
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>Name</span>
 <span class="dd-row-val text">${escapeHtml(r.accountName)}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>Number</span>
 <span class="dd-row-val mono">${escapeHtml(r.accountNumber)}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13"/><path d="M5 12v9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-9"/></svg>Method</span>
 <span class="dd-row-val green">${escapeHtml(r.method)}</span>
 </div>
 ${r.screenshot ? `
 <div class="dd-ss-lbl">
 <svg viewBox="0 0 24 24" style="width:11px;height:11px;stroke:#fbbf24;stroke-width:2.8;fill:none;stroke-linecap:round;stroke-linejoin:round;"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
 Payment Screenshot
 </div>
 <div class="dd-ss-wrap">
 <img class="dd-ss-img" src="${r.screenshot}" alt="Screenshot" onclick="viewSSFromDetail()" onerror="this.style.display='none'">
 <div class="dd-ss-tap">
 <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="11" y1="8" x2="11" y2="14"/><line x1="8" y1="11" x2="14" y2="11"/></svg>
 Tap image to zoom
 </div>
 </div>
 ` : ''}
 <div class="dd-actions">
 <button class="dd-btn reject" onclick="openRejectFromDetail()">
 <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>Reject
 </button>
 <button class="dd-btn accept" onclick="approveFromDetail()">
 <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>Accept
 </button>
 </div>
 `;
 document.getElementById('detailOverlay').classList.add('active');
 }
 function closeDetail(){ document.getElementById('detailOverlay').classList.remove('active'); currentDetailIdx = null; }
 function closeDetailOutside(e){ if(e.target.id==='detailOverlay') closeDetail(); }
 function viewSSFromDetail(){
 if(currentDetailIdx === null) return;
 const r = REQUESTS[currentDetailIdx];
 if(!r || !r.screenshot) return;
 document.getElementById('ssViewerImg').src = r.screenshot;
 document.getElementById('ssViewer').classList.add('active');
 }
 function closeSSViewer(){ document.getElementById('ssViewer').classList.remove('active'); }
 function approveFromDetail(){
 if(currentDetailIdx === null) return;
 approve(currentDetailIdx);
 }
 function openRejectFromDetail(){
 if(currentDetailIdx === null) return;
 openReject(currentDetailIdx);
 }
 async function approve(idx){
 const r = REQUESTS[idx];
 if(!r) return;
 if(!confirm('Accept this deposit of Rs ' + r.amount.toLocaleString('en-IN') + ' from ' + r.name + '?\n\n' +
 '✅ User wallet +Rs ' + r.amount.toLocaleString('en-IN') + '\n' +
 '✅ Plan activate hoga\n' +
 '✅ Referrer ko bonus milega (agar hai)')) return;
 if (window.ADMIN_API_CONFIG.baseURL && !window.ADMIN_APP_MODE.DEMO_MODE) {
 try {
 const ep = ADMIN_API_CONFIG.endpoints.approveDeposit.replace(':id', r.id);
 const res = await window.ADMIN_API.put(ep, {});
 if (!res.success) {
 showToast(res.error || 'Failed to approve', 'error');
 return;
 }
 } catch(e) {
 showToast('Network error', 'error');
 return;
 }
 }
 updateUserWalletOnApprove(r);
 updateAdminStatsOnApprove(r);
 addToDepositHistory(r);
 showSuccessDialog(r, 'accept');
 REQUESTS.splice(idx, 1);
 saveRequestsToLocal();
 closeDetail();
 render();
 }
 function updateUserWalletOnApprove(r){
 try {
 const allUsers = JSON.parse(localStorage.getItem('allUsers') || '[]');
 const target = allUsers.find(u => u.uid === r.uid);
 if (target) {
 target.wallet = (target.wallet || 0) + r.amount;
 target.activePlans = (target.activePlans || 0) + 1;
 target.activePlanList = target.activePlanList || [];
 target.activePlanList.push({
 plan: r.amount,
 daily: Math.round((r.amount / 600) * 120),
 days: 35,
 activatedAt: new Date().toISOString(),
 depositId: r.id
 });
 target.transactions = target.transactions || [];
 target.transactions.unshift({
 id: 'DEP' + Date.now(),
 type: 'deposit',
 amount: r.amount,
 tid: r.tid,
 status: 'success',
 approvedAt: new Date().toISOString()
 });
 if (target.referredBy) {
 const referrer = allUsers.find(u => u.referralCode === target.referredBy);
 if (referrer) {
 const bonus = Math.floor(r.amount / 1200) * 200;
 referrer.referralBalance = (referrer.referralBalance || 0) + bonus;
 referrer.wallet = (referrer.wallet || 0) + bonus;
 referrer.teamList = referrer.teamList || [];
 const member = referrer.teamList.find(m => m.uid === r.uid);
 if (member) {
 member.plan = r.amount;
 member.bonus = bonus;
 }
 }
 }
 localStorage.setItem('allUsers', JSON.stringify(allUsers));
 }
 const loggedUser = JSON.parse(localStorage.getItem('loggedUser') || '{}');
 if (loggedUser && loggedUser.uid === r.uid) {
 loggedUser.wallet = (loggedUser.wallet || 0) + r.amount;
 loggedUser.activePlans = (loggedUser.activePlans || 0) + 1;
 loggedUser.activePlanList = loggedUser.activePlanList || [];
 loggedUser.activePlanList.push({
 plan: r.amount,
 daily: Math.round((r.amount / 600) * 120),
 days: 35,
 activatedAt: new Date().toISOString(),
 depositId: r.id
 });
 loggedUser.transactions = loggedUser.transactions || [];
 loggedUser.transactions.unshift({
 id: 'DEP' + Date.now(),
 type: 'deposit',
 amount: r.amount,
 tid: r.tid,
 status: 'success',
 approvedAt: new Date().toISOString()
 });
 localStorage.setItem('loggedUser', JSON.stringify(loggedUser));
 }
 const notifs = JSON.parse(localStorage.getItem('userNotifications') || '[]');
 notifs.unshift({
 uid: r.uid,
 title: 'Deposit Approved ✅',
 message: 'Rs ' + r.amount.toLocaleString('en-IN') + ' added to your wallet. Plan activated!',
 read: false,
 createdAt: new Date().toISOString()
 });
 localStorage.setItem('userNotifications', JSON.stringify(notifs));
 } catch(e) { console.warn('Local user update failed:', e); }
 }
 function updateAdminStatsOnApprove(r){
 try {
 const stats = JSON.parse(localStorage.getItem('adminStats') || '{}');
 stats.totalDeposits = (stats.totalDeposits || 0) + r.amount;
 stats.todayDeposit = (stats.todayDeposit || 0) + r.amount;
 stats.todayDepositCount = (stats.todayDepositCount || 0) + 1;
 localStorage.setItem('adminStats', JSON.stringify(stats));
 } catch(e) {}
 }
 function addToDepositHistory(r){
 try {
 const history = JSON.parse(localStorage.getItem('depositHistory') || '[]');
 history.unshift({
 ...r,
 status: 'success',
 approvedAt: new Date().toISOString()
 });
 localStorage.setItem('depositHistory', JSON.stringify(history));
 } catch(e) {}
 }
 function openReject(idx){
 pendingRejectIdx = idx;
 document.getElementById('rejectReason').value = '';
 document.getElementById('rejectOverlay').classList.add('active');
 setTimeout(()=>{ document.getElementById('rejectReason').focus(); }, 250);
 }
 function closeReject(){ document.getElementById('rejectOverlay').classList.remove('active'); pendingRejectIdx = null; }
 function closeRejectOutside(e){ if(e.target.id==='rejectOverlay') closeReject(); }
 async function confirmReject(){
 const reason = (document.getElementById('rejectReason').value || '').trim();
 if(!reason){
 const el = document.getElementById('rejectReason');
 el.style.borderColor = '#dc2626';
 setTimeout(()=>{ el.style.borderColor=''; }, 1000);
 showToast('Please enter rejection reason', 'error');
 return;
 }
 if(pendingRejectIdx === null) return;
 const r = REQUESTS[pendingRejectIdx];
 if (window.ADMIN_API_CONFIG.baseURL && !window.ADMIN_APP_MODE.DEMO_MODE) {
 try {
 const ep = ADMIN_API_CONFIG.endpoints.rejectDeposit.replace(':id', r.id);
 const res = await window.ADMIN_API.put(ep, { reason: reason });
 if (!res.success) {
 showToast(res.error || 'Failed to reject', 'error');
 return;
 }
 } catch(e) {
 showToast('Network error', 'error');
 return;
 }
 }
 try {
 const notifs = JSON.parse(localStorage.getItem('userNotifications') || '[]');
 notifs.unshift({
 uid: r.uid,
 title: 'Deposit Rejected ❌',
 message: 'Your deposit of Rs ' + r.amount.toLocaleString('en-IN') + ' was rejected. Reason: ' + reason,
 read: false,
 createdAt: new Date().toISOString()
 });
 localStorage.setItem('userNotifications', JSON.stringify(notifs));
 } catch(e) {}
 try {
 const history = JSON.parse(localStorage.getItem('depositHistory') || '[]');
 history.unshift({
 ...r,
 status: 'rejected',
 rejectedAt: new Date().toISOString(),
 rejectReason: reason
 });
 localStorage.setItem('depositHistory', JSON.stringify(history));
 } catch(e) {}
 showSuccessDialog(r, 'reject', reason);
 REQUESTS.splice(pendingRejectIdx, 1);
 saveRequestsToLocal();
 closeReject();
 closeDetail();
 render();
 }
 function showSuccessDialog(r, type, reason){
 const icon = document.getElementById('suIcon');
 const title = document.getElementById('suTitle');
 const sub = document.getElementById('suSub');
 const info = document.getElementById('suInfo');
 if (type === 'accept') {
 icon.classList.remove('reject');
 title.classList.remove('reject');
 sub.classList.remove('reject');
 info.classList.remove('reject');
 title.textContent = 'Deposit Approved!';
 sub.textContent = 'User balance updated';
 document.querySelectorAll('.su-info-row').forEach(el => el.classList.remove('reject'));
 document.querySelectorAll('.su-info-lbl').forEach(el => el.classList.remove('reject'));
 } else {
 icon.classList.add('reject');
 title.classList.add('reject');
 sub.classList.add('reject');
 info.classList.add('reject');
 title.textContent = 'Request Rejected';
 sub.textContent = 'User notified';
 document.querySelectorAll('.su-info-row').forEach(el => el.classList.add('reject'));
 document.querySelectorAll('.su-info-lbl').forEach(el => el.classList.add('reject'));
 }
 document.getElementById('suUser').textContent = r.name;
 document.getElementById('suAmount').textContent = 'Rs ' + r.amount.toLocaleString('en-IN');
 document.getElementById('successOverlay').classList.add('active');
 }
 function closeSuccess(){ document.getElementById('successOverlay').classList.remove('active'); }
 function openSideMenu(){ document.getElementById('sideMenu').classList.add('active'); document.getElementById('sideMenuOverlay').classList.add('active'); }
 function closeSideMenu(){ document.getElementById('sideMenu').classList.remove('active'); document.getElementById('sideMenuOverlay').classList.remove('active'); }
 function menuGo(page){ closeSideMenu(); setTimeout(()=>{ window.location.href = page; }, 250); }
 function logoutAdmin(){ if(!confirm('Logout?')) return; try{ localStorage.removeItem('adminLoggedIn'); localStorage.removeItem('adminToken'); }catch(e){} closeSideMenu(); setTimeout(()=>{ window.location.href='admin-login.html'; },250); }
 function goTo(page){ setTimeout(()=>{ window.location.href = page; }, 100); }
 function escapeHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
 function showToast(msg, type=''){
 const holder = document.getElementById('toastHolder');
 const t = document.createElement('div');
 t.className = 'toast ' + type;
 t.textContent = msg;
 holder.appendChild(t);
 requestAnimationFrame(()=>t.classList.add('show'));
 setTimeout(()=>{ t.classList.remove('show'); setTimeout(()=>t.remove(),400); }, 1700);
 }
 loadRequests();
 document.addEventListener('gesturestart', e=>e.preventDefault());
 document.addEventListener('gesturechange', e=>e.preventDefault());
 document.addEventListener('gestureend', e=>e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e=>{ const n=Date.now(); if(n-lastTouch<=300) e.preventDefault(); lastTouch=n; }, {passive:false});
 document.addEventListener('wheel', e=>{ if(e.ctrlKey) e.preventDefault(); }, {passive:false});
 document.addEventListener('keydown', e=>{ if((e.ctrlKey||e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault(); });