window.ADMIN_APP_MODE = {
 DEMO_MODE: true 
 };
 window.ADMIN_API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 login: "/auth/admin-login",
 logout: "/auth/admin-logout",
 getDeposits: "/admin/deposits",
 getPendingDeposits: "/admin/deposits/pending",
 approveDeposit: "/admin/deposits/:id/approve",
 rejectDeposit: "/admin/deposits/:id/reject"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const token = localStorage.getItem('adminToken');
 if (token) h["X-Admin-Token"] = token;
 return h;
 }
 };
 window.ADMIN_API = {
 async call(endpoint, method = "GET", body = null) {
 if (!ADMIN_API_CONFIG.baseURL) return { success: false, error: "Admin server not configured" };
 const url = ADMIN_API_CONFIG.baseURL + endpoint;
 const options = { method, headers: ADMIN_API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) return { success: false, error: data.message || data.error || "Request failed", data };
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); },
 put(ep, body) { return this.call(ep, "PUT", body); }
 };
(function checkAuth() {
 try {
 const logged = localStorage.getItem('adminLoggedIn');
 const demo = window.ADMIN_APP_MODE.DEMO_MODE;
 if (demo) {
 if (logged !== 'true') {
 localStorage.setItem('adminLoggedIn', 'true');
 localStorage.setItem('adminEmail', 'demo-admin@predxprofit.pk');
 localStorage.setItem('adminName', 'Demo Admin');
 }
 return;
 }
 if (logged !== 'true') window.location.replace('admin-login.html');
 } catch(e) { window.location.replace('admin-login.html'); }
 })();
 const PX_ICON = 'https://premium-host.ct.ws//uploads/1791979416.png';
 const DEMO_DEPOSITS = [
 { id:'DEP1001', uid:'PX-1001', name:'Ahmed Khan', amount:1200, plan:'Rs 1,200 Plan', tid:'TXN8439217', date:'2026-10-14', time:'10:24 AM', status:'success', screenshot:'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=500&q=80', accountName:'Ahmed Khan', accountNumber:'03001234567', method:'Easypaisa' },
 { id:'DEP1002', uid:'PX-1002', name:'Sara Malik', amount:600, plan:'Rs 600 Plan', tid:'TXN8438105', date:'2026-10-14', time:'09:11 AM', status:'success', screenshot:'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=500&q=80', accountName:'Sara Malik', accountNumber:'03011234567', method:'Easypaisa' },
 { id:'DEP1003', uid:'PX-1003', name:'Bilal Raza', amount:2400, plan:'Rs 2,400 Plan', tid:'TXN8437102', date:'2026-10-14', time:'08:42 AM', status:'pending', screenshot:'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=500&q=80', accountName:'Bilal Raza', accountNumber:'03021234567', method:'JazzCash' },
 { id:'DEP1004', uid:'PX-1004', name:'Fatima Noor', amount:600, plan:'Rs 600 Plan', tid:'TXN8436901', date:'2026-10-14', time:'07:55 AM', status:'success', screenshot:'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=500&q=80', accountName:'Fatima Noor', accountNumber:'03031234567', method:'Easypaisa' },
 { id:'DEP1005', uid:'PX-1005', name:'Usman Tariq', amount:3600, plan:'Rs 3,600 Plan', tid:'TXN8435820', date:'2026-10-13', time:'06:30 PM', status:'success', screenshot:'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=500&q=80', accountName:'Usman Tariq', accountNumber:'03041234567', method:'JazzCash' },
 { id:'DEP1006', uid:'PX-1006', name:'Ayesha Khan', amount:1200, plan:'Rs 1,200 Plan', tid:'TXN8434730', date:'2026-10-13', time:'04:20 PM', status:'rejected', screenshot:'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=500&q=80', accountName:'Ayesha Khan', accountNumber:'03051234567', method:'Easypaisa' },
 { id:'DEP1007', uid:'PX-1007', name:'Hassan Ali', amount:2400, plan:'Rs 2,400 Plan', tid:'TXN8433640', date:'2026-10-13', time:'02:15 PM', status:'success', screenshot:'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=500&q=80', accountName:'Hassan Ali', accountNumber:'03061234567', method:'Easypaisa' },
 { id:'DEP1008', uid:'PX-1008', name:'Zainab Shah', amount:6000, plan:'Rs 6,000 Plan', tid:'TXN8432550', date:'2026-10-12', time:'11:05 AM', status:'success', screenshot:'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=500&q=80', accountName:'Zainab Shah', accountNumber:'03071234567', method:'JazzCash' },
 { id:'DEP1009', uid:'PX-1009', name:'Imran Yousaf', amount:600, plan:'Rs 600 Plan', tid:'TXN8431460', date:'2026-10-12', time:'09:40 AM', status:'pending', screenshot:'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=500&q=80', accountName:'Imran Yousaf', accountNumber:'03081234567', method:'Easypaisa' },
 { id:'DEP1010', uid:'PX-1010', name:'Maryam Iqbal', amount:1200, plan:'Rs 1,200 Plan', tid:'TXN8430370', date:'2026-10-11', time:'08:20 PM', status:'success', screenshot:'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=500&q=80', accountName:'Maryam Iqbal', accountNumber:'03091234567', method:'Easypaisa' },
 { id:'DEP1011', uid:'PX-1001', name:'Ahmed Khan', amount:3600, plan:'Rs 3,600 Plan', tid:'TXN8429280', date:'2026-10-11', time:'06:10 PM', status:'success', screenshot:'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=500&q=80', accountName:'Ahmed Khan', accountNumber:'03001234567', method:'Easypaisa' },
 { id:'DEP1012', uid:'PX-1002', name:'Sara Malik', amount:600, plan:'Rs 600 Plan', tid:'TXN8428190', date:'2026-10-10', time:'03:15 PM', status:'success', screenshot:'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=500&q=80', accountName:'Sara Malik', accountNumber:'03011234567', method:'Easypaisa' }
 ];
 let DEPOSITS = [];
 async function loadDeposits(){
 if (window.ADMIN_API_CONFIG.baseURL && !window.ADMIN_APP_MODE.DEMO_MODE) {
 try {
 const result = await window.ADMIN_API.get(ADMIN_API_CONFIG.endpoints.getDeposits);
 if (result.success) {
 const list = result.data.deposits || result.data || [];
 DEPOSITS = list.map(normalizeDeposit);
 render();
 return;
 }
 } catch(e) { console.warn('API failed, using demo'); }
 }
 DEPOSITS = DEMO_DEPOSITS.map(normalizeDeposit);
 render();
 }
 function normalizeDeposit(d){
 let dateStr = d.date || '';
 let timeStr = d.time || '';
 if ((!dateStr || !timeStr) && (d.submittedAt || d.createdAt || d.dateIso)) {
 const dt = new Date(d.submittedAt || d.createdAt || d.dateIso);
 dateStr = dt.toISOString().split('T')[0];
 let h = dt.getHours(); const m = String(dt.getMinutes()).padStart(2,'0');
 const ampm = h >= 12 ? 'PM' : 'AM'; h = h % 12; if (h === 0) h = 12;
 timeStr = `${String(h).padStart(2,'0')}:${m} ${ampm}`;
 }
 let status = (d.status || 'pending').toLowerCase();
 if (status === 'approved' || status === 'completed') status = 'success';
 if (status === 'failed' || status === 'cancelled') status = 'rejected';
 const amount = Number(d.amount || d.planAmount || 0);
 return {
 id: d.id || ('DEP' + Date.now() + Math.random()),
 uid: d.uid || 'PX-0000',
 name: d.name || 'User',
 amount: amount,
 plan: d.plan || ('Rs ' + amount.toLocaleString('en-IN') + ' Plan'),
 tid: d.tid || d.transactionId || '—',
 date: dateStr || '—',
 time: timeStr || '—',
 status: status,
 screenshot: d.screenshot || d.screenshotUrl || '',
 accountName: d.accountName || d.name || 'User',
 accountNumber: d.accountNumber || d.number || '—',
 method: d.method || 'Easypaisa'
 };
 }
 let currentStatus = 'all';
 let currentSearch = '';
 let dateFrom = null;
 let dateTo = null;
 let quickPreset = 'today';
 function todayStr(){ return new Date().toISOString().split('T')[0]; }
 function yesterdayStr(){ const d=new Date(); d.setDate(d.getDate()-1); return d.toISOString().split('T')[0]; }
 function setQuickDate(preset){
 quickPreset = preset;
 const today = todayStr();
 if(preset==='today'){ dateFrom = today; dateTo = today; }
 else if(preset==='yesterday'){ dateFrom = yesterdayStr(); dateTo = yesterdayStr(); }
 else if(preset==='week'){ const d=new Date(); d.setDate(d.getDate()-6); dateFrom = d.toISOString().split('T')[0]; dateTo = today; }
 else if(preset==='month'){ const d=new Date(); d.setDate(d.getDate()-29); dateFrom = d.toISOString().split('T')[0]; dateTo = today; }
 }
 function fmtDate(dateStr){
 if(!dateStr || dateStr==='—') return '—';
 const d = new Date(dateStr);
 return d.toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' });
 }
 function fmtDayHeader(dateStr){
 const today = todayStr();
 const yd = yesterdayStr();
 if(dateStr===today) return 'Today • ' + fmtDate(dateStr);
 if(dateStr===yd) return 'Yesterday • ' + fmtDate(dateStr);
 return fmtDate(dateStr);
 }
 function getFiltered(){
 return DEPOSITS.filter(d => {
 if(currentStatus !== 'all' && d.status !== currentStatus) return false;
 if(currentSearch){
 const s = currentSearch.toLowerCase();
 const matchName = (d.name||'').toLowerCase().includes(s);
 const matchUid = (d.uid||'').toLowerCase().includes(s);
 const matchTid = (d.tid||'').toLowerCase().includes(s);
 if(!matchName && !matchUid && !matchTid) return false;
 }
 if(dateFrom && d.date < dateFrom) return false;
 if(dateTo && d.date > dateTo) return false;
 return true;
 });
 }
 function render(){
 const filtered = getFiltered();
 const area = document.getElementById('contentArea');
 document.getElementById('cntAll').textContent = DEPOSITS.length;
 document.getElementById('cntSuccess').textContent = DEPOSITS.filter(d=>d.status==='success').length;
 document.getElementById('cntPending').textContent = DEPOSITS.filter(d=>d.status==='pending').length;
 document.getElementById('cntRejected').textContent = DEPOSITS.filter(d=>d.status==='rejected').length;
 document.getElementById('headerDate').textContent = quickPreset==='today' ? 'Today' : (quickPreset==='yesterday' ? 'Yesterday' : (quickPreset==='week' ? 'This Week' : (quickPreset==='month' ? 'This Month' : 'Custom')));
 const badge = document.getElementById('dateBadge');
 const dateBtn = document.getElementById('dateBtn');
 if(quickPreset){ badge.classList.add('show'); dateBtn.classList.add('active'); }
 else { badge.classList.remove('show'); dateBtn.classList.remove('active'); }
 if(filtered.length === 0){
 area.innerHTML = `
 <div class="empty-state">
 <div class="empty-icon"><svg viewBox="0 0 24 24"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="5 12 12 19 19 12"/></svg></div>
 <div class="empty-title">No Deposits Found</div>
 <div class="empty-desc">Try adjusting filters</div>
 </div>`;
 return;
 }
 const groups = {};
 filtered.forEach(d => { if(!groups[d.date]) groups[d.date] = []; groups[d.date].push(d); });
 const sortedDates = Object.keys(groups).sort().reverse();
 area.innerHTML = sortedDates.map(date => {
 const items = groups[date];
 const totalAmt = items.reduce((s,i)=>s+i.amount,0);
 return `
 <div class="day-section">
 <div class="day-head">
 <span class="dot"></span>
 <span class="title">${fmtDayHeader(date)}</span>
 <span class="total-amt">Rs ${totalAmt.toLocaleString('en-IN')}</span>
 <span class="count">${items.length} DEP</span>
 </div>
 <div class="dep-list">
 ${items.map((d)=>renderCard(d)).join('')}
 </div>
 </div>
 `;
 }).join('');
 }
 function renderCard(d){
 const idx = DEPOSITS.indexOf(d);
 const statusLabel = d.status==='success' ? 'Success' : (d.status==='pending' ? 'Pending' : 'Rejected');
 return `
 <div class="dep-item ${d.status}" onclick="openDetail(${idx})">
 <div class="dep-avatar"><img src="${PX_ICON}" alt="PX"></div>
 <div class="dep-info">
 <div class="dep-name">${escapeHtml(d.name)}</div>
 <div class="dep-uid">
 <svg viewBox="0 0 24 24"><path d="M4 7V4h16v3"/><path d="M9 20h6"/><path d="M12 4v16"/></svg>
 <span>${d.uid} • ${d.time}</span>
 </div>
 </div>
 <div class="dep-right">
 <div class="dep-amt">+Rs ${d.amount.toLocaleString('en-IN')}</div>
 <span class="dep-status ${d.status}"><span class="sdot"></span>${statusLabel}</span>
 </div>
 </div>
 `;
 }
 function openDetail(idx){
 const d = DEPOSITS[idx];
 if(!d) return;
 const statusLabel = d.status==='success' ? 'Success' : (d.status==='pending' ? 'Pending' : 'Rejected');
 document.getElementById('ddScroll').innerHTML = `
 <div class="dd-hero">
 <div class="dd-avatar"><img src="${PX_ICON}" alt="PX"></div>
 <div class="dd-name">${escapeHtml(d.name)}</div>
 <div class="dd-uid">
 <svg viewBox="0 0 24 24"><path d="M4 7V4h16v3"/><path d="M9 20h6"/><path d="M12 4v16"/></svg>
 ${d.uid}
 </div>
 </div>
 <div class="dd-amount-box">
 <div class="dd-amount-lbl">Deposit Amount</div>
 <div class="dd-amount-val">Rs ${d.amount.toLocaleString('en-IN')}</div>
 </div>
 <div class="dd-status-line">
 <span class="dd-status-badge ${d.status}"><span class="sdot"></span>${statusLabel}</span>
 </div>
 <div class="dd-section-lbl">Plan & Transaction</div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><path d="M12 2l3 7h7l-5.5 4 2 7L12 16l-6.5 4 2-7L2 9h7z"/></svg>Plan</span>
 <span class="dd-row-val green">${escapeHtml(d.plan)}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><line x1="4" y1="9" x2="20" y2="9"/><line x1="4" y1="15" x2="20" y2="15"/><line x1="10" y1="3" x2="8" y2="21"/><line x1="16" y1="3" x2="14" y2="21"/></svg>TID</span>
 <span class="dd-row-val mono">${escapeHtml(d.tid)}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>Date</span>
 <span class="dd-row-val blue">${fmtDate(d.date)} • ${d.time}</span>
 </div>
 <div class="dd-section-lbl">Payment From</div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>Name</span>
 <span class="dd-row-val text">${escapeHtml(d.accountName)}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>Number</span>
 <span class="dd-row-val mono">${escapeHtml(d.accountNumber)}</span>
 </div>
 <div class="dd-row">
 <span class="dd-row-lbl"><svg viewBox="0 0 24 24"><rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13"/><path d="M5 12v9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-9"/></svg>Method</span>
 <span class="dd-row-val green">${escapeHtml(d.method)}</span>
 </div>
 ${d.screenshot ? `
 <div class="dd-section-lbl">Payment Screenshot</div>
 <div class="dd-screenshot">
 <div class="dd-ss-lbl"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>Uploaded by User</div>
 <img class="dd-ss-img" src="${d.screenshot}" alt="Screenshot" onerror="this.style.display='none'">
 </div>
 ` : ''}
 <div class="dd-actions">
 ${d.status==='pending' ? `
 <button class="dd-btn approve" onclick="approveDeposit(${idx})">
 <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>Approve
 </button>
 <button class="dd-btn reject" onclick="rejectDeposit(${idx})">
 <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>Reject
 </button>
 ` : `
 <button class="dd-btn close" onclick="closeDetail()">
 <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>Close
 </button>
 `}
 </div>
 `;
 document.getElementById('detailOverlay').classList.add('active');
 }
 function closeDetail(){ document.getElementById('detailOverlay').classList.remove('active'); }
 function closeDetailOutside(e){ if(e.target.id==='detailOverlay') closeDetail(); }
 async function approveDeposit(idx){
 const d = DEPOSITS[idx];
 if(!d) return;
 if(!confirm(`Approve deposit?\n\nUser: ${d.name}\nUID: ${d.uid}\nAmount: Rs ${d.amount.toLocaleString('en-IN')}\nPlan: ${d.plan}\n\n` + 
 `Is approve karne pe:\n• User ke wallet me Rs ${d.amount} add honge\n• Plan activate ho jayega\n• Referrer ko bonus milega (agar referral tha)`))
 return;
 if (window.ADMIN_API_CONFIG.baseURL && !window.ADMIN_APP_MODE.DEMO_MODE) {
 try {
 const ep = ADMIN_API_CONFIG.endpoints.approveDeposit.replace(':id', d.id);
 const res = await window.ADMIN_API.put(ep, {});
 if (!res.success) {
 showToast(res.error || 'Failed to approve', 'error');
 return;
 }
 } catch(e) {
 showToast('Network error', 'error');
 return;
 }
 }
 d.status = 'success';
 d.approvedAt = new Date().toISOString();
 try {
 const loggedUser = JSON.parse(localStorage.getItem('loggedUser') || '{}');
 if (loggedUser && loggedUser.uid === d.uid) {
 loggedUser.wallet = (loggedUser.wallet || 0) + d.amount;
 loggedUser.activePlans = (loggedUser.activePlans || 0) + 1;
 loggedUser.activePlanList = loggedUser.activePlanList || [];
 loggedUser.activePlanList.push({
 plan: d.amount,
 daily: Math.round((d.amount / 600) * 120),
 days: 35,
 activatedAt: new Date().toISOString(),
 depositId: d.id
 });
 loggedUser.transactions = loggedUser.transactions || [];
 loggedUser.transactions.unshift({
 id: 'DEP' + Date.now(),
 type: 'deposit',
 amount: d.amount,
 tid: d.tid,
 status: 'success',
 approvedAt: new Date().toISOString()
 });
 localStorage.setItem('loggedUser', JSON.stringify(loggedUser));
 }
 const allUsers = JSON.parse(localStorage.getItem('allUsers') || '[]');
 const target = allUsers.find(u => u.uid === d.uid);
 if (target) {
 target.wallet = (target.wallet || 0) + d.amount;
 target.activePlans = (target.activePlans || 0) + 1;
 target.activePlanList = target.activePlanList || [];
 target.activePlanList.push({
 plan: d.amount,
 daily: Math.round((d.amount / 600) * 120),
 days: 35,
 activatedAt: new Date().toISOString(),
 depositId: d.id
 });
 target.transactions = target.transactions || [];
 target.transactions.unshift({
 id: 'DEP' + Date.now(),
 type: 'deposit',
 amount: d.amount,
 tid: d.tid,
 status: 'success',
 approvedAt: new Date().toISOString()
 });
 if (target.referredBy) {
 const referrer = allUsers.find(u => u.referralCode === target.referredBy);
 if (referrer) {
 const bonus = Math.floor(d.amount / 1200) * 200;
 referrer.referralBalance = (referrer.referralBalance || 0) + bonus;
 referrer.wallet = (referrer.wallet || 0) + bonus;
 referrer.teamList = referrer.teamList || [];
 const member = referrer.teamList.find(m => m.uid === d.uid);
 if (member) {
 member.plan = d.amount;
 member.bonus = bonus;
 }
 }
 }
 localStorage.setItem('allUsers', JSON.stringify(allUsers));
 }
 } catch(e) { console.warn('Local update failed:', e); }
 showToast('✅ Deposit approved: ' + d.tid + ' • Rs ' + d.amount.toLocaleString('en-IN'));
 closeDetail();
 render();
 }
 async function rejectDeposit(idx){
 const d = DEPOSITS[idx];
 if(!d) return;
 const reason = prompt('Reason for rejection:', 'Screenshot clear nahi tha ya TID verify nahi ho saki.');
 if(reason === null) return;
 if(!reason.trim()){
 showToast('Rejection reason zaroori hai', 'error');
 return;
 }
 if (window.ADMIN_API_CONFIG.baseURL && !window.ADMIN_APP_MODE.DEMO_MODE) {
 try {
 const ep = ADMIN_API_CONFIG.endpoints.rejectDeposit.replace(':id', d.id);
 const res = await window.ADMIN_API.put(ep, { reason: reason.trim() });
 if (!res.success) {
 showToast(res.error || 'Failed to reject', 'error');
 return;
 }
 } catch(e) {
 showToast('Network error', 'error');
 return;
 }
 }
 d.status = 'rejected';
 d.rejectReason = reason.trim();
 d.rejectedAt = new Date().toISOString();
 try {
 const allUsers = JSON.parse(localStorage.getItem('allUsers') || '[]');
 const target = allUsers.find(u => u.uid === d.uid);
 if (target) {
 target.transactions = target.transactions || [];
 target.transactions.unshift({
 id: 'DEP' + Date.now(),
 type: 'deposit',
 amount: d.amount,
 tid: d.tid,
 status: 'rejected',
 rejectReason: reason.trim(),
 rejectedAt: new Date().toISOString()
 });
 localStorage.setItem('allUsers', JSON.stringify(allUsers));
 }
 const loggedUser = JSON.parse(localStorage.getItem('loggedUser') || '{}');
 if (loggedUser && loggedUser.uid === d.uid) {
 loggedUser.transactions = loggedUser.transactions || [];
 loggedUser.transactions.unshift({
 id: 'DEP' + Date.now(),
 type: 'deposit',
 amount: d.amount,
 tid: d.tid,
 status: 'rejected',
 rejectReason: reason.trim(),
 rejectedAt: new Date().toISOString()
 });
 localStorage.setItem('loggedUser', JSON.stringify(loggedUser));
 }
 } catch(e) {}
 showToast('❌ Deposit rejected: ' + d.tid, 'error');
 closeDetail();
 render();
 }
 function setStatus(s, el){
 currentStatus = s;
 document.querySelectorAll('#statusChips .chip').forEach(c=>c.classList.remove('active'));
 el.classList.add('active');
 render();
 }
 document.getElementById('searchInput').addEventListener('input', function(){
 currentSearch = this.value.trim();
 render();
 });
 function applyFilters(){ render(); }
 function openDateModal(){
 document.getElementById('dateFrom').value = dateFrom || '';
 document.getElementById('dateTo').value = dateTo || '';
 document.getElementById('dateModal').classList.add('active');
 }
 function closeDateModal(){ document.getElementById('dateModal').classList.remove('active'); }
 function closeDateOutside(e){ if(e.target.id==='dateModal') closeDateModal(); }
 function quickDate(preset, el){
 document.querySelectorAll('.dm-quick-btn').forEach(b=>b.classList.remove('active'));
 el.classList.add('active');
 setQuickDate(preset);
 document.getElementById('dateFrom').value = dateFrom || '';
 document.getElementById('dateTo').value = dateTo || '';
 }
 function applyDateFilter(){
 const from = document.getElementById('dateFrom').value;
 const to = document.getElementById('dateTo').value;
 dateFrom = from || null;
 dateTo = to || null;
 if(from === todayStr() && to === todayStr()) quickPreset = 'today';
 else if(from === yesterdayStr() && to === yesterdayStr()) quickPreset = 'yesterday';
 else quickPreset = 'custom';
 closeDateModal();
 render();
 }
 function scheduleMidnightReset(){
 const now = new Date();
 const midnight = new Date();
 midnight.setHours(24,0,0,0);
 const ms = midnight - now;
 setTimeout(()=>{
 setQuickDate('today');
 quickPreset = 'today';
 document.querySelectorAll('.dm-quick-btn').forEach(b=>{ b.classList.toggle('active', b.dataset.quick==='today'); });
 render();
 showToast('New day — showing today\'s deposits');
 scheduleMidnightReset();
 }, ms);
 }
 function openSideMenu(){ document.getElementById('sideMenu').classList.add('active'); document.getElementById('sideMenuOverlay').classList.add('active'); }
 function closeSideMenu(){ document.getElementById('sideMenu').classList.remove('active'); document.getElementById('sideMenuOverlay').classList.remove('active'); }
 function menuGo(page){ closeSideMenu(); setTimeout(()=>{ window.location.href = page; }, 250); }
 function logoutAdmin(){ if(!confirm('Logout?')) return; try{ localStorage.removeItem('adminLoggedIn'); localStorage.removeItem('adminToken'); }catch(e){} closeSideMenu(); setTimeout(()=>{ window.location.href='admin-login.html'; },250); }
 function goTo(page){ setTimeout(()=>{ window.location.href = page; }, 100); }
 function escapeHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
 function showToast(msg, type=''){
 const holder = document.getElementById('toastHolder');
 const t = document.createElement('div');
 t.className = 'toast ' + type;
 t.textContent = msg;
 holder.appendChild(t);
 requestAnimationFrame(()=>t.classList.add('show'));
 setTimeout(()=>{ t.classList.remove('show'); setTimeout(()=>t.remove(),400); }, 2200);
 }
 /* ============ INIT ============ */
 setQuickDate('today');
 loadDeposits();
 scheduleMidnightReset();
 /* ZOOM BLOCK */
 document.addEventListener('gesturestart', e=>e.preventDefault());
 document.addEventListener('gesturechange', e=>e.preventDefault());
 document.addEventListener('gestureend', e=>e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e=>{ const n=Date.now(); if(n-lastTouch<=300) e.preventDefault(); lastTouch=n; }, {passive:false});
 document.addEventListener('wheel', e=>{ if(e.ctrlKey) e.preventDefault(); }, {passive:false});
 document.addEventListener('keydown', e=>{ if((e.ctrlKey||e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault(); });