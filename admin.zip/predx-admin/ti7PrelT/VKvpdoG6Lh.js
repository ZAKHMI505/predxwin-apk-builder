window.ADMIN_APP_MODE = {
 DEMO_MODE: true 
 };
 window.ADMIN_API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 getProfile: "/admin/profile",
 getStats: "/admin/stats",
 getAgents: "/admin/agents",
 getUser: "/admin/users/:uid"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const token = localStorage.getItem('adminToken');
 if (token) h["X-Admin-Token"] = token;
 return h;
 }
 };
 window.ADMIN_API = {
 async call(endpoint, method = "GET", body = null) {
 if (!ADMIN_API_CONFIG.baseURL) return { success: false, error: "Admin server not configured" };
 const url = ADMIN_API_CONFIG.baseURL + endpoint;
 const options = { method, headers: ADMIN_API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) return { success: false, error: data.message || data.error || "Request failed", data };
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); }
 };
(function checkAuth() {
 try {
 const logged = localStorage.getItem('adminLoggedIn');
 const demo = window.ADMIN_APP_MODE.DEMO_MODE;
 if (demo) {
 if (logged !== 'true') {
 localStorage.setItem('adminLoggedIn', 'true');
 localStorage.setItem('adminEmail', 'demo-admin@predxprofit.pk');
 localStorage.setItem('adminName', 'Demo Admin');
 }
 return;
 }
 if (logged !== 'true') window.location.replace('admin-login.html');
 } catch(e) { window.location.replace('admin-login.html'); }
 })();
 const PX_ICON = 'https://premium-host.ct.ws//uploads/1791979416.png';
 const DEMO_STATS = {
 todayDeposit: 4200,
 todayDepositCount: 4,
 todayWithdraw: 5560,
 todayWithdrawCount: 4,
 todayJoin: 7,
 totalOnline: 24,
 activePlansTotal: 142,
 totalInvested: 8400000,
 totalDeposits: 2458900,
 totalWithdrawals: 1284450
 };
 const DEMO_AGENTS = [];
 const DEMO_PROFILE = {
 name: 'Demo Admin',
 email: 'demo-admin@predxprofit.pk',
 role: 'Super Admin'
 };
 async function loadProfile() {
 let profile = null;
 if (window.ADMIN_API_CONFIG.baseURL && !window.ADMIN_APP_MODE.DEMO_MODE) {
 try {
 const res = await window.ADMIN_API.get(ADMIN_API_CONFIG.endpoints.getProfile);
 if (res.success) profile = res.data.profile || res.data.admin || res.data;
 } catch(e) { console.warn('API profile failed, using local'); }
 }
 if (!profile) {
 const localName = localStorage.getItem('adminName') || 'Admin';
 const localEmail = localStorage.getItem('adminEmail') || 'admin@predxprofit.pk';
 const localRole = localStorage.getItem('adminRole') || 'Super Admin';
 profile = { name: localName, email: localEmail, role: localRole };
 }
 document.getElementById('adminName').textContent = profile.name || 'Admin';
 document.getElementById('adminEmail').textContent = profile.email || 'admin@predxprofit.pk';
 document.getElementById('adminRole').textContent = profile.role || 'Super Admin';
 }
 async function loadStats() {
 let stats = null;
 if (window.ADMIN_API_CONFIG.baseURL && !window.ADMIN_APP_MODE.DEMO_MODE) {
 try {
 const res = await window.ADMIN_API.get(ADMIN_API_CONFIG.endpoints.getStats);
 if (res.success) stats = res.data;
 } catch(e) { console.warn('API stats failed, using demo'); }
 }
 if (!stats) stats = DEMO_STATS;
 document.getElementById('todayDeposit').textContent = 'Rs ' + Number(stats.todayDeposit || 0).toLocaleString('en-IN');
 document.getElementById('todayDepositCount').textContent = (stats.todayDepositCount || 0) + ' Requests';
 document.getElementById('todayWithdraw').textContent = 'Rs ' + Number(stats.todayWithdraw || 0).toLocaleString('en-IN');
 document.getElementById('todayWithdrawCount').textContent = (stats.todayWithdrawCount || 0) + ' Requests';
 document.getElementById('todayJoin').textContent = (stats.todayJoin || 0) + ' Users';
 document.getElementById('totalOnline').textContent = (stats.totalOnline || 0) + ' Users';
 document.getElementById('activePlansTotal').textContent = (stats.activePlansTotal || 0);
 document.getElementById('totalInvested').textContent = formatMoneyShort(stats.totalInvested || 0);
 document.getElementById('totalDeposits').textContent = 'Rs ' + Number(stats.totalDeposits || 0).toLocaleString('en-IN');
 document.getElementById('totalWithdrawals').textContent = 'Rs ' + Number(stats.totalWithdrawals || 0).toLocaleString('en-IN');
 }
 function formatMoneyShort(n) {
 if (n >= 1000000) return 'Rs ' + (n / 1000000).toFixed(1) + 'M';
 if (n >= 1000) return 'Rs ' + (n / 1000).toFixed(1) + 'K';
 return 'Rs ' + Number(n).toLocaleString('en-IN');
 }
 async function loadAgents() {
 let agents = null;
 if (window.ADMIN_API_CONFIG.baseURL && !window.ADMIN_APP_MODE.DEMO_MODE) {
 try {
 const res = await window.ADMIN_API.get(ADMIN_API_CONFIG.endpoints.getAgents);
 if (res.success) {
 agents = res.data.agents || res.data || [];
 agents = agents.map(normalizeAgent);
 }
 } catch(e) { console.warn('API agents failed, using demo'); }
 }
 if (!agents) agents = DEMO_AGENTS.map(normalizeAgent);
 agents.sort((a, b) => b.members - a.members);
 document.getElementById('agentCount').textContent = agents.length;
 const list = document.getElementById('agentList');
 if (agents.length === 0) {
 list.innerHTML = `<div class="empty-agents">No agents with 10+ team yet</div>`;
 return;
 }
 list.innerHTML = agents.map((a, i) => `
 <div class="agent-item" onclick="openAgent(${i})">
 <div class="agent-avatar"><img src="${PX_ICON}" alt="PX"></div>
 <div class="agent-info">
 <div class="agent-name">${escapeHtml(a.name)}</div>
 <div class="agent-uid">${escapeHtml(a.uid)}</div>
 </div>
 <div class="agent-members">
 <div class="agent-mcount">${a.members}</div>
 <div class="agent-mlbl">Members</div>
 </div>
 </div>
 `).join('');
 window.__agents = agents;
 }
 function normalizeAgent(a) {
 return {
 uid: a.uid || 'PX-0000',
 name: a.name || 'Agent',
 members: Number(a.members || a.teamSize || (Array.isArray(a.teamList) ? a.teamList.length : 0))
 };
 }
 function openAgent(idx) {
 const agents = window.__agents || [];
 const a = agents[idx];
 if (!a) return;
 showToast('Agent: ' + a.name + ' • ' + a.members + ' members');
 }
 function escapeHtml(s) {
 return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
 }
 function scrollToTop() {
 document.getElementById('contentArea').scrollTo({top:0, behavior:'smooth'});
 }
 /* ============ SIDE MENU ============ */
 function openSideMenu(){ document.getElementById('sideMenu').classList.add('active'); document.getElementById('sideMenuOverlay').classList.add('active'); }
 function closeSideMenu(){ document.getElementById('sideMenu').classList.remove('active'); document.getElementById('sideMenuOverlay').classList.remove('active'); }
 function menuGo(page){ closeSideMenu(); setTimeout(()=>{ window.location.href = page; }, 250); }
 function logoutAdmin(){ if(!confirm('Logout?')) return; try{ localStorage.clear(); sessionStorage.clear(); }catch(e){} closeSideMenu(); setTimeout(()=>{ window.location.href='admin-login.html'; },250); }
 function goTo(page){ setTimeout(()=>{ window.location.href = page; }, 100); }
 function showToast(msg){
 const holder = document.getElementById('toastHolder');
 const t = document.createElement('div');
 t.className = 'toast';
 t.textContent = msg;
 holder.appendChild(t);
 requestAnimationFrame(()=>t.classList.add('show'));
 setTimeout(()=>{ t.classList.remove('show'); setTimeout(()=>t.remove(),400); }, 1700);
 }
 /* ============ INIT ============ */
 loadProfile();
 loadStats();
 loadAgents();
 /* ZOOM BLOCK */
 document.addEventListener('gesturestart', e=>e.preventDefault());
 document.addEventListener('gesturechange', e=>e.preventDefault());
 document.addEventListener('gestureend', e=>e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e=>{ const n=Date.now(); if(n-lastTouch<=300) e.preventDefault(); lastTouch=n; }, {passive:false});
 document.addEventListener('wheel', e=>{ if(e.ctrlKey) e.preventDefault(); }, {passive:false});
 document.addEventListener('keydown', e=>{ if((e.ctrlKey||e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault(); });