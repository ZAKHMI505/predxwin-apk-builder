window.APP_MODE = {
 DEMO_MODE: true,
 DEMO_USER: {
 uid: 'DEMO001',
 name: 'Demo User',
 email: 'demo@predxprofit.pk',
 whatsapp: '03001234567',
 wallet: 0,
 withdrawableWallet: 0,
 activePlans: 0,
 referralCode: 'PREDX001',
 todayEarning: 0,
 teamSize: 0,
 teamList: [],
 referralBalance: 0,
 weeklySalary: 0,
 adsWatched: 0,
 joinDate: new Date('2026-01-15').toISOString(),
 transactions: [],
 giftClaims: [],
 chatHistory: []
 }
 };
 window.API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 register: "/auth/register",
 login: "/auth/login",
 logout: "/auth/logout",
 getUser: "/user/me",
 updateUser: "/user/update",
 changePassword: "/user/change-password",
 getNextUID: "/meta/next-uid",
 getPlans: "/plans",
 createDeposit: "/deposits",
 getDeposits: "/deposits/me",
 createWithdraw: "/withdraws",
 getWithdraws: "/withdraws/me",
 watchAd: "/ads/watch",
 getAdsHistory: "/ads/history",
 getTeam: "/team/me",
 getTransactions: "/transactions/me",
 redeemGift: "/gifts/redeem",
 getChats: "/chats/me",
 sendMessage: "/chats/send",
 getMessages: "/chats/:id/messages",
 getLatestUpdate: "/updates/latest",
 getPaymentSettings: "/settings/payment",
 submitDepositProof: "/deposits/submit"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const loggedUser = localStorage.getItem('loggedUser');
 if (loggedUser) {
 try {
 const u = JSON.parse(loggedUser);
 if (u.uid) h["X-User-UID"] = u.uid;
 } catch(e) {}
 }
 return h;
 }
 };
 window.API = {
 async call(endpoint, method = "GET", body = null) {
 if (!API_CONFIG.baseURL) return { success: false, error: "API baseURL not configured" };
 const url = API_CONFIG.baseURL + endpoint;
 const options = { method, headers: API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) return { success: false, error: data.message || data.error || "Request failed", data };
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); },
 put(ep, body) { return this.call(ep, "PUT", body); },
 del(ep) { return this.call(ep, "DELETE"); }
 };
function showToast(msg, type = 'success', title = null) {
 const holder = document.getElementById('notifHolder');
 if (!holder) return;
 if (type === 'success') {
 const errKeywords = ['error','invalid','failed','not found','wrong','incorrect','already','required','enter ','please','too short','too long','try again','doesn\'t','cannot','can not','not registered','not match'];
 const lower = String(msg).toLowerCase();
 if (errKeywords.some(k => lower.includes(k))) type = 'error';
 }
 const icons = {
 success: '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
 error: '<svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
 info: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
 };
 const titles = { success: title || 'Success', error: title || 'Error', info: title || 'Info' };
 const notif = document.createElement('div');
 notif.className = 'premium-notif ' + type;
 notif.innerHTML = `
 <div class="premium-notif-icon">${icons[type]}</div>
 <div class="premium-notif-text">
 <div class="premium-notif-title">${titles[type]}</div>
 <div class="premium-notif-msg">${msg}</div>
 </div>
 <button class="premium-notif-close" onclick="this.parentElement.classList.remove('show');setTimeout(()=>this.parentElement.remove(),500);">
 <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
 </button>
 `;
 holder.appendChild(notif);
 requestAnimationFrame(() => notif.classList.add('show'));
 setTimeout(() => {
 if (notif.parentElement) {
 notif.classList.remove('show');
 setTimeout(() => notif.remove(), 500);
 }
 }, 3500);
 }
 let user = null;
 let userName = '';
 let userUID = '';
 let chatStarted = false;
 let chatMessages = [];
 const chatArea = document.getElementById('chatArea');
 const msgInput = document.getElementById('msgInput');
 function loadUserData() {
 const loggedUser = localStorage.getItem('loggedUser');
 if (window.APP_MODE.DEMO_MODE) {
 if (loggedUser) {
 try { user = JSON.parse(loggedUser); } catch(e){}
 }
 if (!user || !user.uid) {
 user = JSON.parse(JSON.stringify(window.APP_MODE.DEMO_USER));
 localStorage.setItem('loggedUser', JSON.stringify(user));
 }
 } else {
 if (!loggedUser) {
 window.location.replace('index.html');
 return;
 }
 try { user = JSON.parse(loggedUser); } catch(e){}
 if (!user || !user.uid) {
 window.location.replace('index.html');
 return;
 }
 }
 userName = user.name || 'User';
 userUID = user.uid || 'PX-0000';
 document.getElementById('pillName').textContent = userName;
 document.getElementById('pillUID').textContent = userUID;
 initChat();
 }
 function initChat() {
 chatArea.innerHTML = '';
 chatMessages = Array.isArray(user.chatHistory) ? user.chatHistory.slice() : [];
 const divider = document.createElement('div');
 divider.className = 'date-divider';
 divider.innerHTML = '<span>Today</span>';
 chatArea.appendChild(divider);
 if (chatMessages.length > 0) {
 chatMessages.forEach(m => {
 appendMessage(m.type, m.html, { image: m.image, file: m.file, fileSize: m.fileSize, time: m.time, noSave: true });
 });
 chatStarted = true;
 } else {
 setTimeout(() => {
 const welcomeHtml = `Hi <strong>${escapeHtml(userName)}</strong> 👋<br>Welcome to Predx Profit Support.<br>Your UID: <strong>${escapeHtml(userUID)}</strong><br><br>How can we help you today?`;
 appendMessage('bot', welcomeHtml, { save: true });
 chatStarted = true;
 }, 400);
 }
 }
 function appendMessage(type, html, opts = {}) {
 const row = document.createElement('div');
 row.className = 'msg-row ' + type;
 let bubbleContent = '';
 if (opts.image) {
 bubbleContent += `<img class="msg-image" src="${opts.image}" alt="attachment">`;
 }
 if (opts.file) {
 bubbleContent += `
 <div class="file-chip">
 <div class="file-chip-icon">
 <svg viewBox="0 0 24 24"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
 </div>
 <div class="file-chip-body">
 <div class="file-chip-name">${escapeHtml(opts.file)}</div>
 <div class="file-chip-size">${opts.fileSize || 'Document'}</div>
 </div>
 </div>
 `;
 }
 if (html) bubbleContent += `<span class="msg-text">${html}</span>`;
 const timeStr = opts.time || nowTime();
 const timeHtml = `
 <span class="msg-time">
 ${timeStr}
 ${type === 'user' ? '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/><polyline points="22 12 13 21 11 19"/></svg>' : ''}
 </span>
 `;
 bubbleContent += timeHtml;
 row.innerHTML = `<div class="msg-bubble">${bubbleContent}</div>`;
 chatArea.appendChild(row);
 scrollBottom();
 if (!opts.noSave) {
 chatMessages.push({
 type: type,
 html: html || '',
 image: opts.image || '',
 file: opts.file || '',
 fileSize: opts.fileSize || '',
 time: timeStr
 });
 persistChat();
 }
 }
 function persistChat() {
 if (!user) return;
 user.chatHistory = chatMessages.slice(-100); 
 localStorage.setItem('loggedUser', JSON.stringify(user));
 if (window.API_CONFIG.baseURL && chatMessages.length > 0) {
 const last = chatMessages[chatMessages.length - 1];
 window.API.post(API_CONFIG.endpoints.sendMessage, {
 uid: user.uid,
 name: user.name,
 type: last.type,
 message: last.html || '',
 hasImage: !!last.image,
 hasFile: !!last.file,
 time: last.time
 }).catch(() => {});
 }
 }
 function appendTyping() {
 const row = document.createElement('div');
 row.className = 'msg-row bot';
 row.id = 'typingRow';
 row.innerHTML = `
 <div class="typing-bubble">
 <span class="t-dot"></span>
 <span class="t-dot"></span>
 <span class="t-dot"></span>
 </div>
 `;
 chatArea.appendChild(row);
 scrollBottom();
 }
 function removeTyping() {
 const t = document.getElementById('typingRow');
 if (t) t.remove();
 }
 function sendMessage() {
 if (!chatStarted) return;
 const val = (msgInput.value || '').trim();
 if (!val) return;
 appendMessage('user', escapeHtml(val), { save: true });
 msgInput.value = '';
 autoResize(msgInput);
 setTimeout(() => {
 appendTyping();
 setTimeout(() => {
 removeTyping();
 appendMessage('bot', randomBotReply(), { save: true });
 }, 1000);
 }, 300);
 }
 function randomBotReply() {
 const replies = [
 'Got it! Our team is looking into this. 📩',
 'Thanks for the details. Let me check and get back to you.',
 'Received! If you have any screenshot, please attach it.',
 'Understood. Please allow us a few minutes.',
 'Thank you for your patience. 🙏',
 'Noted! Our support team will respond shortly.'
 ];
 return replies[Math.floor(Math.random() * replies.length)];
 }
 function openAttachSheet() {
 if (!chatStarted) return;
 document.getElementById('sheetOverlay').classList.add('active');
 }
 function closeSheet() {
 document.getElementById('sheetOverlay').classList.remove('active');
 }
 function closeSheetOutside(e) {
 if (e.target.id === 'sheetOverlay') closeSheet();
 }
 function pickImage() {
 closeSheet();
 setTimeout(() => document.getElementById('imageInput').click(), 200);
 }
 function pickFile() {
 closeSheet();
 setTimeout(() => document.getElementById('fileInput').click(), 200);
 }
 function handleImage(input) {
 const file = input.files && input.files[0];
 if (!file) return;
 if (file.size > 5 * 1024 * 1024) {
 showToast('Image too large (max 5MB)', 'error', 'Too Large');
 input.value = '';
 return;
 }
 const reader = new FileReader();
 reader.onload = e => {
 appendMessage('user', '', { image: e.target.result, save: true });
 botAck('image');
 showToast('Image attached!', 'success', 'Uploaded');
 };
 reader.readAsDataURL(file);
 input.value = '';
 }
 function handleFile(input) {
 const file = input.files && input.files[0];
 if (!file) return;
 if (file.size > 10 * 1024 * 1024) {
 showToast('File too large (max 10MB)', 'error', 'Too Large');
 input.value = '';
 return;
 }
 const size = formatFileSize(file.size);
 appendMessage('user', '', { file: file.name, fileSize: size, save: true });
 botAck('file');
 showToast('File attached!', 'success', 'Uploaded');
 input.value = '';
 }
 function formatFileSize(bytes) {
 if (bytes < 1024) return bytes + ' B';
 if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
 return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
 }
 function botAck(type) {
 setTimeout(() => {
 appendTyping();
 setTimeout(() => {
 removeTyping();
 const msg = type === 'image'
 ? 'Screenshot received 📸 Our team will review it.'
 : 'Document received 📄 Our team will review it.';
 appendMessage('bot', msg, { save: true });
 }, 900);
 }, 300);
 }
 function nowTime() {
 const d = new Date();
 let h = d.getHours();
 const m = String(d.getMinutes()).padStart(2, '0');
 const ampm = h >= 12 ? 'PM' : 'AM';
 h = h % 12; if (h === 0) h = 12;
 return `${h}:${m} ${ampm}`;
 }
 function scrollBottom() {
 requestAnimationFrame(() => {
 chatArea.scrollTop = chatArea.scrollHeight;
 });
 }
 function escapeHtml(str) {
 return String(str)
 .replace(/&/g, '&amp;')
 .replace(/</g, '&lt;')
 .replace(/>/g, '&gt;')
 .replace(/"/g, '&quot;')
 .replace(/'/g, '&#39;');
 }
 function autoResize(el) {
 el.style.height = 'auto';
 el.style.height = Math.min(el.scrollHeight, 110) + 'px';
 }
 /* ==========================================================
 NAV
 ========================================================== */
 function goTo(page) { setTimeout(() => { window.location.href = page; }, 100); }
 function goToWithNotif(page, title, message){
 showToast(message || ('Opening ' + title + '...'), 'info', title);
 setTimeout(() => {
 window.location.href = page;
 }, 650);
 }
 /* ==========================================================
 INPUT EVENTS
 ========================================================== */
 msgInput.addEventListener('input', () => autoResize(msgInput));
 msgInput.addEventListener('keydown', e => {
 if (e.key === 'Enter' && !e.shiftKey) {
 e.preventDefault();
 sendMessage();
 }
 });
 /* ==========================================================
 INIT
 ========================================================== */
 loadUserData();
 /* ZOOM BLOCK */
 document.addEventListener('gesturestart', e => e.preventDefault());
 document.addEventListener('gesturechange', e => e.preventDefault());
 document.addEventListener('gestureend', e => e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e => {
 const now = Date.now();
 if (now - lastTouch <= 300) e.preventDefault();
 lastTouch = now;
 }, { passive: false });
 document.addEventListener('wheel', e => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });
 document.addEventListener('keydown', e => {
 if ((e.ctrlKey || e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault();
 });