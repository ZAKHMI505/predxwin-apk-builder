window.APP_MODE = {
 DEMO_MODE: true,
 DEMO_USER: {
 uid: 'DEMO001',
 name: 'Demo User',
 email: 'demo@predxprofit.pk',
 whatsapp: '03001234567',
 wallet: 0,
 activePlans: 0,
 referralCode: 'PREDX001',
 todayEarning: 0,
 teamSize: 0,
 adsWatched: 0,
 joinDate: new Date('2026-01-15').toISOString()
 }
 };
 window.API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 register: "/auth/register",
 login: "/auth/login",
 logout: "/auth/logout",
 getUser: "/user/me",
 updateUser: "/user/update",
 getNextUID: "/meta/next-uid",
 getPlans: "/plans",
 createDeposit: "/deposits",
 getDeposits: "/deposits/me",
 createWithdraw: "/withdraws",
 getWithdraws: "/withdraws/me",
 watchAd: "/ads/watch",
 getAdsHistory: "/ads/history",
 getTeam: "/team/me",
 getTransactions: "/transactions/me",
 redeemGift: "/gifts/redeem",
 getChats: "/chats/me",
 sendMessage: "/chats/send",
 getMessages: "/chats/:id/messages",
 getLatestUpdate: "/updates/latest"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const loggedUser = localStorage.getItem('loggedUser');
 if (loggedUser) {
 try {
 const u = JSON.parse(loggedUser);
 if (u.uid) h["X-User-UID"] = u.uid;
 } catch(e) {}
 }
 return h;
 }
 };
 window.API = {
 async call(endpoint, method = "GET", body = null) {
 if (!API_CONFIG.baseURL) {
 return { success: false, error: "API baseURL not configured" };
 }
 const url = API_CONFIG.baseURL + endpoint;
 const options = { method, headers: API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) {
 return { success: false, error: data.message || data.error || "Request failed", data };
 }
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); },
 put(ep, body) { return this.call(ep, "PUT", body); },
 del(ep) { return this.call(ep, "DELETE"); }
 };
function showToast(msg, type = 'success', title = null) {
 const holder = document.getElementById('notifHolder');
 if (!holder) return;
 if (type === 'success') {
 const errKeywords = ['error','invalid','failed','not found','wrong','incorrect','already','required','enter ','please','too short','too long','try again','doesn\'t','cannot','can not','not registered','not match'];
 const lower = String(msg).toLowerCase();
 if (errKeywords.some(k => lower.includes(k))) type = 'error';
 }
 const icons = {
 success: '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
 error: '<svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
 info: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
 };
 const titles = {
 success: title || 'Success',
 error: title || 'Error',
 info: title || 'Info'
 };
 const notif = document.createElement('div');
 notif.className = 'premium-notif ' + type;
 notif.innerHTML = `
 <div class="premium-notif-icon">${icons[type]}</div>
 <div class="premium-notif-text">
 <div class="premium-notif-title">${titles[type]}</div>
 <div class="premium-notif-msg">${msg}</div>
 </div>
 <button class="premium-notif-close" onclick="this.parentElement.classList.remove('show');setTimeout(()=>this.parentElement.remove(),500);">
 <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
 </button>
 `;
 holder.appendChild(notif);
 requestAnimationFrame(() => notif.classList.add('show'));
 setTimeout(() => {
 if (notif.parentElement) {
 notif.classList.remove('show');
 setTimeout(() => notif.remove(), 500);
 }
 }, 3500);
 }
 let ACTIVE_PLANS = [];
 const AD_DURATION_SEC = 15;
 const THEMES = ['theme-green', 'theme-silver', 'theme-gold', 'theme-purple'];
 const adTimers = {};
 function loadUserData(){
 const loggedUser = localStorage.getItem('loggedUser');
 let user = null;
 if (window.APP_MODE.DEMO_MODE) {
 if (loggedUser) {
 try { user = JSON.parse(loggedUser); } catch(e){}
 }
 if (!user || !user.uid) {
 user = window.APP_MODE.DEMO_USER;
 localStorage.setItem('loggedUser', JSON.stringify(user));
 }
 } else {
 if (!loggedUser) {
 window.location.replace('index.html');
 return;
 }
 try { user = JSON.parse(loggedUser); } catch(e){}
 if (!user || !user.uid) {
 window.location.replace('index.html');
 return;
 }
 }
 const todayKey = 'adsWatched_' + user.uid + '_' + new Date().toISOString().slice(0,10);
 let planList = Array.isArray(user.activePlanList) ? user.activePlanList : [];
 let watchedMap = {};
 try { watchedMap = JSON.parse(localStorage.getItem(todayKey) || '{}'); } catch(e){}
 ACTIVE_PLANS = planList.map((p, i) => ({
 amount: p.amount || 0,
 daily: p.daily || Math.round(((p.amount || 0) / 600) * 120),
 watchedToday: !!watchedMap['plan_' + i]
 }));
 if (window.APP_MODE.DEMO_MODE && ACTIVE_PLANS.length === 0) {
 }
 render();
 }
 function saveWatchedMap(userUid, idx){
 const todayKey = 'adsWatched_' + userUid + '_' + new Date().toISOString().slice(0,10);
 let watchedMap = {};
 try { watchedMap = JSON.parse(localStorage.getItem(todayKey) || '{}'); } catch(e){}
 watchedMap['plan_' + idx] = true;
 localStorage.setItem(todayKey, JSON.stringify(watchedMap));
 }
 function render() {
 const list = document.getElementById('adsList');
 if (!list) return;
 document.getElementById('planCountBadge').textContent = ACTIVE_PLANS.length + ' PLAN' + (ACTIVE_PLANS.length !== 1 ? 'S' : '');
 if (ACTIVE_PLANS.length === 0) {
 list.innerHTML = `
 <div style="padding:40px 20px;text-align:center;font-family:'Rajdhani',sans-serif;font-size:13px;font-weight:800;letter-spacing:1px;text-transform:uppercase;color:#94a3b8;">
 No active plans
 </div>
 `;
 setTimeout(() => {
 document.getElementById('noPlanOverlay').classList.add('active');
 }, 400);
 return;
 }
 list.innerHTML = ACTIVE_PLANS.map((p, idx) => {
 const theme = THEMES[idx % THEMES.length];
 const watched = p.watchedToday;
 const planId = 'plan_' + idx;
 return `
 <div class="plan-ad-card ${theme}" id="${planId}">
 <div class="shine"></div>
 <div class="pac-inner">
 <div class="pac-top">
 <div class="pac-icon">
 <svg viewBox="0 0 24 24"><path d="M12 2l3 7h7l-5.5 4 2 7L12 16l-6.5 4 2-7L2 9h7z"/></svg>
 </div>
 <div class="pac-text">
 <div class="pac-name">Rs ${p.amount.toLocaleString('en-IN')} Plan</div>
 <div class="pac-badge">
 <span class="dot"></span>
 <span>${watched ? 'COMPLETED' : 'READY'}</span>
 </div>
 </div>
 </div>
 <div class="pac-stats">
 <div class="pac-stat">
 <div class="pac-stat-lbl">
 <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
 Duration
 </div>
 <div class="pac-stat-val blue">${AD_DURATION_SEC}s</div>
 </div>
 <div class="pac-stat">
 <div class="pac-stat-lbl">
 <svg viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
 Daily Reward
 </div>
 <div class="pac-stat-val gold">Rs ${p.daily.toLocaleString('en-IN')}</div>
 </div>
 </div>
 ${watched ? `
 <div class="pac-done-badge show" id="done_${idx}">
 <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
 <span>Today's Ad Completed</span>
 </div>
 ` : `
 <button class="pac-watch-btn" id="btn_${idx}" onclick="startAd(${idx})">
 <svg viewBox="0 0 24 24" id="icon_${idx}">
 <polygon points="5 3 19 12 5 21 5 3"/>
 </svg>
 <span id="txt_${idx}">Watch Ad</span>
 </button>
 <div class="pac-progress-wrap" id="prog_${idx}">
 <div class="pac-progress-bar">
 <div class="pac-progress-fill" id="fill_${idx}"></div>
 </div>
 <div class="pac-progress-text">
 <span class="spinner-mini"></span>
 <span id="ptxt_${idx}">Watching... 0s</span>
 </div>
 </div>
 `}
 </div>
 </div>
 `;
 }).join('');
 }
 /* ==========================================================
 START AD
 ========================================================== */
 function startAd(idx) {
 const plan = ACTIVE_PLANS[idx];
 if (!plan) return;
 if (plan.watchedToday) {
 showToast('Aaj ka ad already dekh liya', 'info', 'Already Done');
 return;
 }
 if (adTimers[idx]) return;
 const btn = document.getElementById('btn_' + idx);
 const txt = document.getElementById('txt_' + idx);
 const icon = document.getElementById('icon_' + idx);
 const progWrap = document.getElementById('prog_' + idx);
 const fill = document.getElementById('fill_' + idx);
 const ptxt = document.getElementById('ptxt_' + idx);
 if (btn) btn.disabled = true;
 if (txt) txt.textContent = 'Watching...';
 if (icon) icon.outerHTML = '<svg viewBox="0 0 24 24" id="icon_' + idx + '"><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>';
 if (progWrap) progWrap.classList.add('show');
 showToast('Ad started. Please wait...', 'info', 'Watching Ad');
 let elapsed = 0;
 const total = AD_DURATION_SEC;
 adTimers[idx] = setInterval(() => {
 elapsed++;
 const pct = (elapsed / total) * 100;
 if (fill) fill.style.width = pct + '%';
 if (ptxt) ptxt.textContent = 'Watching... ' + (total - elapsed) + 's';
 if (elapsed >= total) {
 clearInterval(adTimers[idx]);
 delete adTimers[idx];
 finishAd(idx);
 }
 }, 1000);
 }
 /* ==========================================================
 FINISH AD → wallet update + save
 ========================================================== */
 function finishAd(idx) {
 const plan = ACTIVE_PLANS[idx];
 if (!plan) return;
 // Mark watched
 plan.watchedToday = true;
 saveWatchedMap(getCurrentUid(), idx);
 // ✅ Update user wallet + todayEarning + adsWatched
 const loggedUser = localStorage.getItem('loggedUser');
 if (loggedUser) {
 try {
 const u = JSON.parse(loggedUser);
 u.wallet = (u.wallet || 0) + plan.daily;
 u.todayEarning = (u.todayEarning || 0) + plan.daily;
 u.adsWatched = (u.adsWatched || 0) + 1;
 localStorage.setItem('loggedUser', JSON.stringify(u));
 } catch(e) {}
 }
 // Show reward dialog
 document.getElementById('rdReward').textContent = 'Rs ' + plan.daily.toLocaleString('en-IN');
 document.getElementById('rdSub').textContent = 'Rs ' + plan.amount.toLocaleString('en-IN') + ' Plan Reward';
 document.getElementById('rewardOverlay').classList.add('active');
 // Re-render list
 render();
 // Success notification bhi
 showToast('+Rs ' + plan.daily.toLocaleString('en-IN') + ' added to wallet!', 'success', 'Reward Earned');
 }
 function closeReward() {
 document.getElementById('rewardOverlay').classList.remove('active');
 }
 function getCurrentUid(){
 try {
 const u = JSON.parse(localStorage.getItem('loggedUser') || '{}');
 return u.uid || 'DEMO001';
 } catch(e) { return 'DEMO001'; }
 }
 /* ==========================================================
 NAV with notification
 ========================================================== */
 function goTo(page) {
 setTimeout(() => { window.location.href = page; }, 100);
 }
 function goToWithNotif(page, title, message){
 showToast(message || ('Opening ' + title + '...'), 'info', title);
 setTimeout(() => {
 window.location.href = page;
 }, 650);
 }
 function openCustomerService(){
 showToast('Connecting to support team...', 'info', 'Customer Service');
 setTimeout(() => {
 window.location.href = 'customer.html';
 }, 650);
 }
 /* ==========================================================
 INIT
 ========================================================== */
 loadUserData();
 /* ZOOM BLOCK */
 document.addEventListener('gesturestart', e => e.preventDefault());
 document.addEventListener('gesturechange', e => e.preventDefault());
 document.addEventListener('gestureend', e => e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e => {
 const now = Date.now();
 if (now - lastTouch <= 300) e.preventDefault();
 lastTouch = now;
 }, { passive: false });
 document.addEventListener('wheel', e => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });
 document.addEventListener('keydown', e => {
 if ((e.ctrlKey || e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault();
 });