window.APP_MODE = {
 DEMO_MODE: true,
 DEMO_USER: {
 uid: 'DEMO001',
 name: 'Demo User',
 email: 'demo@predxprofit.pk',
 whatsapp: '03001234567',
 password: 'demo123',
 wallet: 0,
 withdrawableWallet: 0,
 activePlans: 0,
 referralCode: 'PREDX001',
 todayEarning: 0,
 teamSize: 0,
 teamList: [],
 referralBalance: 0,
 weeklySalary: 0,
 adsWatched: 0,
 joinDate: new Date('2026-01-15').toISOString(),
 transactions: [],
 giftClaims: [],
 settings: {
 notifications: true,
 darkMode: false,
 sound: true,
 autoAds: false,
 biometric: false
 }
 }
 };
 window.API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 register: "/auth/register",
 login: "/auth/login",
 logout: "/auth/logout",
 getUser: "/user/me",
 updateUser: "/user/update",
 changePassword: "/user/change-password",
 getNextUID: "/meta/next-uid",
 getPlans: "/plans",
 createDeposit: "/deposits",
 getDeposits: "/deposits/me",
 createWithdraw: "/withdraws",
 getWithdraws: "/withdraws/me",
 watchAd: "/ads/watch",
 getAdsHistory: "/ads/history",
 getTeam: "/team/me",
 getTransactions: "/transactions/me",
 redeemGift: "/gifts/redeem",
 getChats: "/chats/me",
 sendMessage: "/chats/send",
 getMessages: "/chats/:id/messages",
 getLatestUpdate: "/updates/latest"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const loggedUser = localStorage.getItem('loggedUser');
 if (loggedUser) {
 try {
 const u = JSON.parse(loggedUser);
 if (u.uid) h["X-User-UID"] = u.uid;
 } catch(e) {}
 }
 return h;
 }
 };
 window.API = {
 async call(endpoint, method = "GET", body = null) {
 if (!API_CONFIG.baseURL) return { success: false, error: "API baseURL not configured" };
 const url = API_CONFIG.baseURL + endpoint;
 const options = { method, headers: API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) return { success: false, error: data.message || data.error || "Request failed", data };
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); },
 put(ep, body) { return this.call(ep, "PUT", body); },
 del(ep) { return this.call(ep, "DELETE"); }
 };
function showToast(msg, type = 'success', title = null) {
 const holder = document.getElementById('notifHolder');
 if (!holder) return;
 if (type === 'success') {
 const errKeywords = ['error','invalid','failed','not found','wrong','incorrect','already','required','enter ','please','too short','too long','try again','doesn\'t','cannot','can not','not registered','not match'];
 const lower = String(msg).toLowerCase();
 if (errKeywords.some(k => lower.includes(k))) type = 'error';
 }
 const icons = {
 success: '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
 error: '<svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
 info: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
 };
 const titles = { success: title || 'Success', error: title || 'Error', info: title || 'Info' };
 const notif = document.createElement('div');
 notif.className = 'premium-notif ' + type;
 notif.innerHTML = `
 <div class="premium-notif-icon">${icons[type]}</div>
 <div class="premium-notif-text">
 <div class="premium-notif-title">${titles[type]}</div>
 <div class="premium-notif-msg">${msg}</div>
 </div>
 <button class="premium-notif-close" onclick="this.parentElement.classList.remove('show');setTimeout(()=>this.parentElement.remove(),500);">
 <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
 </button>
 `;
 holder.appendChild(notif);
 requestAnimationFrame(() => notif.classList.add('show'));
 setTimeout(() => {
 if (notif.parentElement) {
 notif.classList.remove('show');
 setTimeout(() => notif.remove(), 500);
 }
 }, 3500);
 }
 let user = null;
 function loadUserData(){
 const loggedUser = localStorage.getItem('loggedUser');
 if (window.APP_MODE.DEMO_MODE) {
 if (loggedUser) {
 try { user = JSON.parse(loggedUser); } catch(e){}
 }
 if (!user || !user.uid) {
 user = JSON.parse(JSON.stringify(window.APP_MODE.DEMO_USER));
 localStorage.setItem('loggedUser', JSON.stringify(user));
 }
 } else {
 if (!loggedUser) {
 window.location.replace('index.html');
 return;
 }
 try { user = JSON.parse(loggedUser); } catch(e){}
 if (!user || !user.uid) {
 window.location.replace('index.html');
 return;
 }
 }
 renderProfile();
 loadSettings();
 }
 function renderProfile(){
 if (!user) return;
 const nameEl = document.getElementById('userName');
 const emailEl = document.getElementById('userEmail');
 const uidEl = document.getElementById('userUID');
 const avatarBox = document.getElementById('avatarBox');
 if (nameEl) nameEl.textContent = user.name || 'User';
 if (emailEl) emailEl.textContent = user.email || 'user@example.com';
 if (uidEl) uidEl.textContent = user.uid || 'PX-0000';
 if (avatarBox) {
 const initial = (user.name || 'U').trim().charAt(0).toUpperCase();
 avatarBox.innerHTML = `<span id="avatarInitial">${initial}</span>`;
 }
 }
 function copyUID(e){
 if (e) e.stopPropagation();
 const uid = user && user.uid ? user.uid : 'PX-0000';
 try {
 navigator.clipboard.writeText(uid);
 } catch(err) {
 const tmp = document.createElement('input');
 tmp.value = uid;
 document.body.appendChild(tmp);
 tmp.select();
 document.execCommand('copy');
 document.body.removeChild(tmp);
 }
 showToast('UID copied: ' + uid, 'success', 'Copied');
 }
 function openDialog(id) { document.getElementById(id).classList.add('active'); }
 function closeDialog(id) { document.getElementById(id).classList.remove('active'); }
 function openPasswordDialog() {
 restorePasswordBody();
 document.getElementById('oldPass').value = '';
 document.getElementById('newPass').value = '';
 document.getElementById('confirmPass').value = '';
 openDialog('passwordDialog');
 }
 function restorePasswordBody() {
 const body = document.getElementById('passwordBody');
 const buttons = document.getElementById('passwordButtons');
 if (body && buttons && !body.querySelector('input')) {
 body.innerHTML = `
 <div class="input-group">
 <div class="input-label">
 <svg viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
 Old Password <span class="req">*</span>
 </div>
 <div class="password-input-wrap">
 <input type="password" class="text-input" id="oldPass" placeholder="Enter old password" autocomplete="off">
 <button class="eye-toggle" onclick="togglePass('oldPass', this)">
 <svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
 </button>
 </div>
 </div>
 <div class="input-group">
 <div class="input-label">
 <svg viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
 New Password <span class="req">*</span>
 </div>
 <div class="password-input-wrap">
 <input type="password" class="text-input" id="newPass" placeholder="Enter new password" autocomplete="off">
 <button class="eye-toggle" onclick="togglePass('newPass', this)">
 <svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
 </button>
 </div>
 </div>
 <div class="input-group">
 <div class="input-label">
 <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
 Confirm Password <span class="req">*</span>
 </div>
 <div class="password-input-wrap">
 <input type="password" class="text-input" id="confirmPass" placeholder="Confirm new password" autocomplete="off">
 <button class="eye-toggle" onclick="togglePass('confirmPass', this)">
 <svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
 </button>
 </div>
 </div>
 `;
 buttons.innerHTML = `
 <button class="dialog-btn cancel" onclick="closeDialog('passwordDialog')">
 <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
 <span>Cancel</span>
 </button>
 <button class="dialog-btn confirm" onclick="submitPassword()">
 <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
 <span>Submit</span>
 </button>
 `;
 }
 }
 function togglePass(inputId, btn) {
 const input = document.getElementById(inputId);
 if (!input) return;
 if (input.type === 'password') {
 input.type = 'text';
 btn.innerHTML = '<svg viewBox="0 0 24 24"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>';
 } else {
 input.type = 'password';
 btn.innerHTML = '<svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
 }
 }
 async function submitPassword() {
 const oldEl = document.getElementById('oldPass');
 const newEl = document.getElementById('newPass');
 const confEl = document.getElementById('confirmPass');
 const oldVal = (oldEl.value || '').trim();
 const newVal = (newEl.value || '').trim();
 const confVal = (confEl.value || '').trim();
 if (!oldVal) { shakeInput(oldEl); showToast('Enter old password', 'error', 'Missing'); return; }
 if (!newVal) { shakeInput(newEl); showToast('Enter new password', 'error', 'Missing'); return; }
 if (newVal.length < 6) { shakeInput(newEl); showToast('Password min 6 characters', 'error', 'Too Short'); return; }
 if (newVal === oldVal) { shakeInput(newEl); showToast('New must differ from old', 'error', 'Invalid'); return; }
 if (newVal !== confVal) { shakeInput(confEl); showToast('Passwords do not match', 'error', 'Mismatch'); return; }
 if (user.password && oldVal !== user.password) {
 shakeInput(oldEl);
 showToast('Old password is incorrect', 'error', 'Wrong Password');
 return;
 }
 if (window.API_CONFIG.baseURL) {
 const res = await window.API.post(API_CONFIG.endpoints.changePassword, {
 uid: user.uid,
 oldPassword: oldVal,
 newPassword: newVal
 });
 if (!res.success) {
 showToast(res.error || 'Failed to change password', 'error', 'Error');
 return;
 }
 }
 user.password = newVal;
 localStorage.setItem('loggedUser', JSON.stringify(user));
 const body = document.getElementById('passwordBody');
 const buttons = document.getElementById('passwordButtons');
 body.innerHTML = `
 <div class="success-mini">
 <div class="sm-icon">
 <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
 </div>
 <div class="sm-title">Password Changed!</div>
 <div class="sm-desc">Your password has been updated</div>
 </div>
 `;
 buttons.innerHTML = `
 <button class="dialog-btn confirm" onclick="closeDialog('passwordDialog')" style="grid-column:1 / -1;">
 <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
 <span>Great, Thanks!</span>
 </button>
 `;
 showToast('Password changed successfully!', 'success', 'Success');
 }
 function openSettingsDialog() {
 loadSettings();
 openDialog('settingsDialog');
 }
 function loadSettings() {
 const s = (user && user.settings) || {};
 const map = {
 setNotif: s.notifications !== false,
 setDark: !!s.darkMode,
 setSound: s.sound !== false,
 setAutoAds: !!s.autoAds,
 setBio: !!s.biometric
 };
 Object.keys(map).forEach(id => {
 const el = document.getElementById(id);
 if (el) el.checked = map[id];
 });
 }
 function saveSettingsAndClose() {
 if (user) {
 user.settings = {
 notifications: document.getElementById('setNotif').checked,
 darkMode: document.getElementById('setDark').checked,
 sound: document.getElementById('setSound').checked,
 autoAds: document.getElementById('setAutoAds').checked,
 biometric: document.getElementById('setBio').checked
 };
 localStorage.setItem('loggedUser', JSON.stringify(user));
 }
 closeDialog('settingsDialog');
 showToast('Settings saved!', 'success', 'Saved');
 }
 function openLogout() {
 openDialog('logoutDialog');
 }
 function confirmLogout() {
 try {
 localStorage.removeItem('loggedUser');
 sessionStorage.clear();
 } catch(e) {}
 showToast('Logging out...', 'info', 'Goodbye');
 setTimeout(() => { window.location.href = 'index.html'; }, 700);
 }
 function shakeInput(el) {
 if (!el) return;
 el.style.transition = 'transform .1s ease';
 el.style.transform = 'translateX(-8px)';
 setTimeout(() => { el.style.transform = 'translateX(8px)'; }, 100);
 setTimeout(() => { el.style.transform = 'translateX(-6px)'; }, 200);
 setTimeout(() => { el.style.transform = 'translateX(6px)'; }, 300);
 setTimeout(() => { el.style.transform = 'translateX(-4px)'; }, 400);
 setTimeout(() => { el.style.transform = 'translateX(0)'; }, 500);
 }
 function goTo(page) { setTimeout(() => { window.location.href = page; }, 100); }
 function goToWithNotif(page, title, message){
 showToast(message || ('Opening ' + title + '...'), 'info', title);
 setTimeout(() => {
 window.location.href = page;
 }, 650);
 }
 function openCustomerService(){
 showToast('Connecting to support team...', 'info', 'Customer Service');
 setTimeout(() => {
 window.location.href = 'customer.html';
 }, 650);
 }
 document.querySelectorAll('.dialog-overlay').forEach(overlay => {
 overlay.addEventListener('click', e => {
 if (e.target === overlay) {
 overlay.classList.remove('active');
 }
 });
 });
 loadUserData();
 document.addEventListener('gesturestart', e => e.preventDefault());
 document.addEventListener('gesturechange', e => e.preventDefault());
 document.addEventListener('gestureend', e => e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e => {
 const now = Date.now();
 if (now - lastTouch <= 300) e.preventDefault();
 lastTouch = now;
 }, { passive: false });
 document.addEventListener('wheel', e => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });
 document.addEventListener('keydown', e => {
 if ((e.ctrlKey || e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault();
 });