window.APP_MODE = {
 DEMO_MODE: true,
 DEMO_USER: {
 uid: 'DEMO001',
 name: 'Demo User',
 email: 'demo@predxprofit.pk',
 whatsapp: '03001234567',
 wallet: 0,
 withdrawableWallet: 0,
 activePlans: 0,
 referralCode: 'PREDX001',
 todayEarning: 0,
 teamSize: 0,
 teamList: [],
 referralBalance: 0,
 weeklySalary: 0,
 adsWatched: 0,
 joinDate: new Date('2026-01-15').toISOString(),
 transactions: [],
 giftClaims: []
 }
 };
 window.API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 register: "/auth/register",
 login: "/auth/login",
 logout: "/auth/logout",
 getUser: "/user/me",
 updateUser: "/user/update",
 getNextUID: "/meta/next-uid",
 getPlans: "/plans",
 createDeposit: "/deposits",
 getDeposits: "/deposits/me",
 createWithdraw: "/withdraws",
 getWithdraws: "/withdraws/me",
 watchAd: "/ads/watch",
 getAdsHistory: "/ads/history",
 getTeam: "/team/me",
 getTransactions: "/transactions/me",
 redeemGift: "/gifts/redeem",
 getChats: "/chats/me",
 sendMessage: "/chats/send",
 getMessages: "/chats/:id/messages",
 getLatestUpdate: "/updates/latest"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const loggedUser = localStorage.getItem('loggedUser');
 if (loggedUser) {
 try {
 const u = JSON.parse(loggedUser);
 if (u.uid) h["X-User-UID"] = u.uid;
 } catch(e) {}
 }
 return h;
 }
 };
 window.API = {
 async call(endpoint, method = "GET", body = null) {
 if (!API_CONFIG.baseURL) return { success: false, error: "API baseURL not configured" };
 const url = API_CONFIG.baseURL + endpoint;
 const options = { method, headers: API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) return { success: false, error: data.message || data.error || "Request failed", data };
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); },
 put(ep, body) { return this.call(ep, "PUT", body); },
 del(ep) { return this.call(ep, "DELETE"); }
 };
function showToast(msg, type = 'success', title = null) {
 const holder = document.getElementById('notifHolder');
 if (!holder) return;
 if (type === 'success') {
 const errKeywords = ['error','invalid','failed','not found','wrong','incorrect','already','required','enter ','please','too short','too long','try again','doesn\'t','cannot','can not','not registered','not match'];
 const lower = String(msg).toLowerCase();
 if (errKeywords.some(k => lower.includes(k))) type = 'error';
 }
 const icons = {
 success: '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
 error: '<svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
 info: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
 };
 const titles = { success: title || 'Success', error: title || 'Error', info: title || 'Info' };
 const notif = document.createElement('div');
 notif.className = 'premium-notif ' + type;
 notif.innerHTML = `
 <div class="premium-notif-icon">${icons[type]}</div>
 <div class="premium-notif-text">
 <div class="premium-notif-title">${titles[type]}</div>
 <div class="premium-notif-msg">${msg}</div>
 </div>
 <button class="premium-notif-close" onclick="this.parentElement.classList.remove('show');setTimeout(()=>this.parentElement.remove(),500);">
 <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
 </button>
 `;
 holder.appendChild(notif);
 requestAnimationFrame(() => notif.classList.add('show'));
 setTimeout(() => {
 if (notif.parentElement) {
 notif.classList.remove('show');
 setTimeout(() => notif.remove(), 500);
 }
 }, 3500);
 }
 let user = null;
 let MEMBERS = [];
 let CLAIM_HISTORY = [];
 let GIFT_CODES = {}; 
 function loadUserData(){
 const loggedUser = localStorage.getItem('loggedUser');
 if (window.APP_MODE.DEMO_MODE) {
 if (loggedUser) {
 try { user = JSON.parse(loggedUser); } catch(e){}
 }
 if (!user || !user.uid) {
 user = JSON.parse(JSON.stringify(window.APP_MODE.DEMO_USER));
 localStorage.setItem('loggedUser', JSON.stringify(user));
 }
 } else {
 if (!loggedUser) {
 window.location.replace('index.html');
 return;
 }
 try { user = JSON.parse(loggedUser); } catch(e){}
 if (!user || !user.uid) {
 window.location.replace('index.html');
 return;
 }
 }
 MEMBERS = Array.isArray(user.teamList) ? user.teamList.map((m, i) => ({
 name: m.name || 'Unknown',
 initial: (m.name || 'U').charAt(0).toUpperCase(),
 level: m.level || 1,
 online: m.online !== false,
 joined: m.joined || 'recently',
 plan: m.plan || 0,
 bonus: m.bonus || calcBonus(m.plan || 0)
 })) : [];
 CLAIM_HISTORY = Array.isArray(user.giftClaims) ? user.giftClaims : [];
 const refCode = user.referralCode || 'PREDX001';
 document.getElementById('refLink').value = 'https://predxprofit.pk/?ref=' + refCode;
 renderMembers();
 updateTeamStats();
 }
 function calcBonus(plan) {
 if (plan < 1200) return 0;
 return Math.floor(plan / 1200) * 200;
 }
 function calcSalary(investment) {
 if (investment < 25000) return 0;
 return Math.floor(investment / 25000) * 2500;
 }
 function renderMembers() {
 const list = document.getElementById('membersList');
 if (!list) return;
 if (MEMBERS.length === 0) {
 list.innerHTML = `<div style="text-align:center;padding:30px;color:#94a3b8;font-family:'Rajdhani',sans-serif;font-size:12px;font-weight:800;letter-spacing:1px;text-transform:uppercase;">No Team Members Yet</div>`;
 return;
 }
 list.innerHTML = MEMBERS.map(m => `
 <div class="member-card lvl${m.level}">
 <div class="mc-avatar ${m.online ? '' : 'offline'}">${m.initial}</div>
 <div class="mc-content">
 <div class="mc-name">${m.name}</div>
 <div class="mc-meta">
 <span>${m.joined}</span>
 <span class="dot-sep"></span>
 <span>L${m.level}</span>
 <span class="mc-badge">+${m.bonus}</span>
 </div>
 </div>
 <div class="mc-right">
 <div class="mc-amount ${m.level === 2 ? 'blue' : m.level === 3 ? 'purple' : ''}">+Rs ${m.bonus.toLocaleString('en-IN')}</div>
 <div class="mc-time">Plan Rs ${m.plan.toLocaleString('en-IN')}</div>
 </div>
 </div>
 `).join('');
 }
 function updateTeamStats() {
 const total = MEMBERS.length;
 const active = MEMBERS.filter(m => m.online).length;
 const totalInv = MEMBERS.reduce((sum, m) => sum + m.plan, 0);
 const totalBonus = MEMBERS.reduce((sum, m) => sum + m.bonus, 0);
 const weeklySal = calcSalary(totalInv);
 document.getElementById('totalTeam').textContent = total;
 document.getElementById('activeTeam').textContent = active;
 document.getElementById('totalInvested').textContent = totalInv >= 1000 ? 'Rs ' + Math.round(totalInv/1000) + 'K' : 'Rs ' + totalInv;
 document.getElementById('weeklySalary').textContent = 'Rs ' + weeklySal.toLocaleString('en-IN');
 document.getElementById('memberCountBadge').textContent = total;
 document.getElementById('bcTeamCount').textContent = total + ' Referrals';
 document.getElementById('claimsCount').textContent = CLAIM_HISTORY.length;
 document.getElementById('balInt').textContent = totalBonus.toLocaleString('en-IN');
 if (user) {
 user.referralBalance = totalBonus;
 user.weeklySalary = weeklySal;
 user.teamSize = total;
 localStorage.setItem('loggedUser', JSON.stringify(user));
 }
 }
 function openFullList() {
 const listEl = document.getElementById('flmList');
 if (!listEl) return;
 if (CLAIM_HISTORY.length === 0) {
 listEl.innerHTML = `<div style="text-align:center;padding:40px 20px;color:#b45309;font-family:'Rajdhani',sans-serif;font-size:12px;font-weight:800;letter-spacing:1px;text-transform:uppercase;">No Claims Yet</div>`;
 } else {
 listEl.innerHTML = CLAIM_HISTORY.map(c => `
 <div class="flm-row">
 <div class="flm-avatar">${(c.name || 'U').charAt(0).toUpperCase()}</div>
 <div class="flm-info">
 <div class="flm-name">${c.name || 'You'}</div>
 <div class="flm-code">${c.code}</div>
 </div>
 <div class="flm-amount">+Rs ${(c.amount || 0).toLocaleString('en-IN')}</div>
 </div>
 `).join('');
 }
 document.getElementById('fullListOverlay').classList.add('active');
 }
 function closeFullList() {
 document.getElementById('fullListOverlay').classList.remove('active');
 }
 function closeFullListOutside(e) {
 if (e.target.id === 'fullListOverlay') closeFullList();
 }
 function copyRef() {
 const input = document.getElementById('refLink');
 if (!input) return;
 input.select();
 input.setSelectionRange(0, 99999);
 try { document.execCommand('copy'); } catch(e) {}
 if (navigator.clipboard && window.isSecureContext) {
 navigator.clipboard.writeText(input.value).catch(() => {});
 }
 showToast('Referral Link Copied!', 'success', 'Copied');
 window.getSelection && window.getSelection().removeAllRanges();
 }
 async function redeemGift() {
 const input = document.getElementById('giftInput');
 const code = (input.value || '').trim().toUpperCase();
 if (!code) {
 shakeElement(input.closest('.gift-input-wrap'));
 showToast('Please enter gift code', 'error', 'Missing Code');
 return;
 }
 let amount = 0;
 let success = false;
 if (window.API_CONFIG.baseURL) {
 const res = await window.API.post(API_CONFIG.endpoints.redeemGift, { code: code, uid: user.uid });
 if (res.success) {
 amount = res.data.amount || res.data.value || 0;
 success = amount > 0;
 } else {
 shakeElement(input.closest('.gift-input-wrap'));
 showToast(res.error || 'Invalid gift code', 'error', 'Invalid');
 return;
 }
 } else {
 if (!GIFT_CODES[code]) {
 shakeElement(input.closest('.gift-input-wrap'));
 showToast('Invalid gift code', 'error', 'Invalid');
 return;
 }
 amount = GIFT_CODES[code];
 success = true;
 }
 if (!success || amount <= 0) {
 shakeElement(input.closest('.gift-input-wrap'));
 showToast('Invalid gift code', 'error', 'Invalid');
 return;
 }
 user.wallet = (user.wallet || 0) + amount;
 user.withdrawableWallet = (user.withdrawableWallet || 0) + amount;
 user.giftClaims = user.giftClaims || [];
 user.giftClaims.unshift({
 name: user.name || 'You',
 code: code,
 amount: amount,
 date: new Date().toISOString()
 });
 localStorage.setItem('loggedUser', JSON.stringify(user));
 CLAIM_HISTORY = user.giftClaims;
 document.getElementById('claimsCount').textContent = CLAIM_HISTORY.length;
 document.getElementById('sdAmount').textContent = 'Rs ' + amount.toLocaleString('en-IN');
 document.getElementById('sdSub').textContent = 'Code: ' + code;
 document.getElementById('successOverlay').classList.add('active');
 showToast('+Rs ' + amount.toLocaleString('en-IN') + ' added to wallet!', 'success', 'Gift Redeemed');
 input.value = '';
 }
 function closeSuccessDialog() {
 document.getElementById('successOverlay').classList.remove('active');
 }
 function shakeElement(el) {
 if (!el) return;
 el.style.transition = 'transform .1s ease';
 el.style.transform = 'translateX(-8px)';
 setTimeout(() => { el.style.transform = 'translateX(8px)'; }, 100);
 setTimeout(() => { el.style.transform = 'translateX(-6px)'; }, 200);
 setTimeout(() => { el.style.transform = 'translateX(6px)'; }, 300);
 setTimeout(() => { el.style.transform = 'translateX(-4px)'; }, 400);
 setTimeout(() => { el.style.transform = 'translateX(0)'; }, 500);
 }
 let balHidden = false;
 let realRefBalance = 0;
 function toggleBal() {
 balHidden = !balHidden;
 const balInt = document.getElementById('balInt');
 const balDec = document.getElementById('balDec');
 const eyeIcon = document.getElementById('eyeIcon');
 if (balHidden) {
 balInt.textContent = '•••';
 balDec.textContent = '';
 eyeIcon.innerHTML = '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>';
 } else {
 const totalBonus = MEMBERS.reduce((sum, m) => sum + m.bonus, 0);
 balInt.textContent = totalBonus.toLocaleString('en-IN');
 balDec.textContent = '.00';
 eyeIcon.innerHTML = '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>';
 }
 }
 function goTo(page) { setTimeout(() => { window.location.href = page; }, 100); }
 function goToWithNotif(page, title, message){
 showToast(message || ('Opening ' + title + '...'), 'info', title);
 setTimeout(() => {
 window.location.href = page;
 }, 650);
 }
 function openCustomerService(){
 showToast('Connecting to support team...', 'info', 'Customer Service');
 setTimeout(() => {
 window.location.href = 'customer.html';
 }, 650);
 }
 loadUserData();
 document.addEventListener('gesturestart', e => e.preventDefault());
 document.addEventListener('gesturechange', e => e.preventDefault());
 document.addEventListener('gestureend', e => e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e => {
 const now = Date.now();
 if (now - lastTouch <= 300) e.preventDefault();
 lastTouch = now;
 }, { passive: false });
 document.addEventListener('wheel', e => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });
 document.addEventListener('keydown', e => {
 if ((e.ctrlKey || e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault();
 });