window.APP_MODE = {
 DEMO_MODE: true,
 DEMO_USER: {
 uid: 'DEMO001',
 name: 'Demo User',
 email: 'demo@predxprofit.pk',
 whatsapp: '03001234567',
 wallet: 0,
 withdrawableWallet: 0, 
 activePlans: 0,
 referralCode: 'PREDX001',
 todayEarning: 0,
 teamSize: 0,
 adsWatched: 0,
 joinDate: new Date('2026-01-15').toISOString(),
 transactions: []
 }
 };
 window.API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 register: "/auth/register",
 login: "/auth/login",
 logout: "/auth/logout",
 getUser: "/user/me",
 updateUser: "/user/update",
 getNextUID: "/meta/next-uid",
 getPlans: "/plans",
 createDeposit: "/deposits",
 getDeposits: "/deposits/me",
 createWithdraw: "/withdraws",
 getWithdraws: "/withdraws/me",
 watchAd: "/ads/watch",
 getAdsHistory: "/ads/history",
 getTeam: "/team/me",
 getTransactions: "/transactions/me",
 redeemGift: "/gifts/redeem",
 getChats: "/chats/me",
 sendMessage: "/chats/send",
 getMessages: "/chats/:id/messages",
 getLatestUpdate: "/updates/latest"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const loggedUser = localStorage.getItem('loggedUser');
 if (loggedUser) {
 try {
 const u = JSON.parse(loggedUser);
 if (u.uid) h["X-User-UID"] = u.uid;
 } catch(e) {}
 }
 return h;
 }
 };
 window.API = {
 async call(endpoint, method = "GET", body = null) {
 if (!API_CONFIG.baseURL) {
 return { success: false, error: "API baseURL not configured" };
 }
 const url = API_CONFIG.baseURL + endpoint;
 const options = { method, headers: API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) {
 return { success: false, error: data.message || data.error || "Request failed", data };
 }
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); },
 put(ep, body) { return this.call(ep, "PUT", body); },
 del(ep) { return this.call(ep, "DELETE"); }
 };
function showToast(msg, type = 'success', title = null) {
 const holder = document.getElementById('notifHolder');
 if (!holder) return;
 if (type === 'success') {
 const errKeywords = ['error','invalid','failed','not found','wrong','incorrect','already','required','enter ','please','too short','too long','try again','doesn\'t','cannot','can not','not registered','not match'];
 const lower = String(msg).toLowerCase();
 if (errKeywords.some(k => lower.includes(k))) type = 'error';
 }
 const icons = {
 success: '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
 error: '<svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
 info: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
 };
 const titles = {
 success: title || 'Success',
 error: title || 'Error',
 info: title || 'Info'
 };
 const notif = document.createElement('div');
 notif.className = 'premium-notif ' + type;
 notif.innerHTML = `
 <div class="premium-notif-icon">${icons[type]}</div>
 <div class="premium-notif-text">
 <div class="premium-notif-title">${titles[type]}</div>
 <div class="premium-notif-msg">${msg}</div>
 </div>
 <button class="premium-notif-close" onclick="this.parentElement.classList.remove('show');setTimeout(()=>this.parentElement.remove(),500);">
 <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
 </button>
 `;
 holder.appendChild(notif);
 requestAnimationFrame(() => notif.classList.add('show'));
 setTimeout(() => {
 if (notif.parentElement) {
 notif.classList.remove('show');
 setTimeout(() => notif.remove(), 500);
 }
 }, 3500);
 }
 const MIN_WITHDRAWAL = 100;
 let user = null;
 let realBalance = 0;
 let realWithdrawable = 0;
 function loadUserData(){
 const loggedUser = localStorage.getItem('loggedUser');
 if (window.APP_MODE.DEMO_MODE) {
 if (loggedUser) {
 try { user = JSON.parse(loggedUser); } catch(e){}
 }
 if (!user || !user.uid) {
 user = JSON.parse(JSON.stringify(window.APP_MODE.DEMO_USER));
 localStorage.setItem('loggedUser', JSON.stringify(user));
 }
 } else {
 if (!loggedUser) {
 window.location.replace('index.html');
 return;
 }
 try { user = JSON.parse(loggedUser); } catch(e){}
 if (!user || !user.uid) {
 window.location.replace('index.html');
 return;
 }
 }
 renderUserData();
 }
 function renderUserData(){
 if (!user) return;
 realBalance = user.wallet || 0;
 const wInt = Math.floor(realBalance);
 const wDec = (realBalance - wInt).toFixed(2).substring(1);
 document.getElementById('balInt').textContent = wInt.toLocaleString('en-IN');
 document.getElementById('balDec').textContent = wDec || '.00';
 document.getElementById('dashAmount').textContent = realBalance.toLocaleString('en-IN');
 adjustBalanceFont();
 realWithdrawable = typeof user.withdrawableWallet === 'number'
 ? user.withdrawableWallet
 : realBalance;
 document.getElementById('wdAmount').textContent = realWithdrawable.toLocaleString('en-IN');
 document.getElementById('maxWDAmount').textContent = realWithdrawable.toLocaleString('en-IN');
 document.getElementById('maxWDAmountInfo').textContent = realWithdrawable.toLocaleString('en-IN');
 document.getElementById('activePlanCount').textContent = user.activePlans || 0;
 }
 function adjustBalanceFont(){
 const wrap = document.getElementById('balAmount');
 if(!wrap) return;
 const text = document.getElementById('balInt').textContent || '';
 const len = text.length;
 let size = 34;
 if (len >= 8) size = 24;
 else if (len >= 7) size = 26;
 else if (len >= 6) size = 28;
 else if (len >= 5) size = 30;
 else if (len >= 4) size = 32;
 wrap.style.fontSize = size + 'px';
 }
 let selectedMethod = null;
 let methodListOpen = false;
 function toggleMethodList() {
 methodListOpen = !methodListOpen;
 const list = document.getElementById('methodList');
 const trigger = document.getElementById('methodTrigger');
 if (methodListOpen) {
 list.classList.add('open');
 trigger.classList.add('open');
 } else {
 list.classList.remove('open');
 trigger.classList.remove('open');
 }
 }
 function selectMethod(el) {
 document.querySelectorAll('.method-option').forEach(opt => opt.classList.remove('selected'));
 el.classList.add('selected');
 selectedMethod = el.getAttribute('data-method');
 document.getElementById('methodTitle').textContent = el.getAttribute('data-name');
 document.getElementById('methodSub').textContent = el.getAttribute('data-desc');
 setTimeout(() => {
 methodListOpen = false;
 document.getElementById('methodList').classList.remove('open');
 document.getElementById('methodTrigger').classList.remove('open');
 }, 350);
 el.style.transition = 'transform .12s ease';
 el.style.transform = 'scale(.97)';
 setTimeout(() => { el.style.transform = ''; }, 120);
 }
 function submitWithdrawal() {
 const amount = parseInt(document.getElementById('wdInputAmount').value);
 const number = document.getElementById('wdInputNumber').value.trim();
 const name = document.getElementById('wdInputName').value.trim();
 if (!selectedMethod) {
 shakeElement(document.querySelector('.method-box'));
 showToast('Please select your payment method', 'error', 'Missing Info');
 return;
 }
 if (!amount || amount < MIN_WITHDRAWAL) {
 shakeElement(document.getElementById('wdInputAmount').closest('.form-group'));
 showToast('Minimum withdrawal is Rs ' + MIN_WITHDRAWAL, 'error', 'Invalid Amount');
 return;
 }
 if (amount > realWithdrawable) {
 shakeElement(document.getElementById('wdInputAmount').closest('.form-group'));
 showToast('Max withdrawal: Rs ' + realWithdrawable.toLocaleString('en-IN'), 'error', 'Insufficient Balance');
 return;
 }
 if (!number || number.length < 10) {
 shakeElement(document.getElementById('wdInputNumber').closest('.form-group'));
 showToast('Please enter valid account number', 'error', 'Invalid Number');
 return;
 }
 if (!name || name.length < 3) {
 shakeElement(document.getElementById('wdInputName').closest('.form-group'));
 showToast('Please enter your account name', 'error', 'Invalid Name');
 return;
 }
 const tx = {
 id: 'WD' + Date.now(),
 type: 'withdrawal',
 uid: user.uid,
 name: user.name || name,
 email: user.email || '',
 method: selectedMethod,
 accountNumber: number,
 accountName: name,
 amount: amount,
 status: 'pending',
 submittedAt: new Date().toISOString()
 };
 user.wallet = Math.max(0, (user.wallet || 0) - amount);
 user.withdrawableWallet = Math.max(0, realWithdrawable - amount);
 user.transactions = user.transactions || [];
 user.transactions.unshift(tx);
 localStorage.setItem('loggedUser', JSON.stringify(user));
 localStorage.setItem('lastWithdrawal', JSON.stringify(tx));
 showLoadingDialog();
 setTimeout(() => {
 window.location.href = 'dashboard.html';
 }, 3500);
 }
 function showLoadingDialog() {
 const overlay = document.getElementById('loadingOverlay');
 overlay.classList.add('active');
 const steps = [
 { sub: 'Verifying balance', step: 'Verifying' },
 { sub: 'Checking account', step: 'Processing' },
 { sub: 'Sending to admin', step: 'Sending' },
 { sub: 'Almost done', step: 'Redirecting' }
 ];
 let i = 0;
 const subEl = document.getElementById('loadingSub');
 const stepEl = document.getElementById('loadingStep');
 const timer = setInterval(() => {
 i++;
 if (i >= steps.length) { clearInterval(timer); return; }
 subEl.textContent = steps[i].sub;
 stepEl.innerHTML = steps[i].step + '<span class="dot-pulse"><span></span><span></span><span></span></span>';
 }, 850);
 }
 function shakeElement(el) {
 if (!el) return;
 el.style.transition = 'transform .1s ease';
 el.style.transform = 'translateX(-8px)';
 setTimeout(() => { el.style.transform = 'translateX(8px)'; }, 100);
 setTimeout(() => { el.style.transform = 'translateX(-6px)'; }, 200);
 setTimeout(() => { el.style.transform = 'translateX(6px)'; }, 300);
 setTimeout(() => { el.style.transform = 'translateX(-4px)'; }, 400);
 setTimeout(() => { el.style.transform = 'translateX(0)'; }, 500);
 }
 let balHidden = false;
 function toggleBal() {
 balHidden = !balHidden;
 const balInt = document.getElementById('balInt');
 const balDec = document.getElementById('balDec');
 const eyeIcon = document.getElementById('eyeIcon');
 if (balHidden) {
 balInt.textContent = '•••';
 balDec.textContent = '';
 eyeIcon.innerHTML = '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>';
 } else {
 const wInt = Math.floor(realBalance);
 const wDec = (realBalance - wInt).toFixed(2).substring(1);
 balInt.textContent = wInt.toLocaleString('en-IN');
 balDec.textContent = wDec || '.00';
 eyeIcon.innerHTML = '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>';
 }
 adjustBalanceFont();
 }
 function goTo(page) { setTimeout(() => { window.location.href = page; }, 100); }
 function goToWithNotif(page, title, message){
 showToast(message || ('Opening ' + title + '...'), 'info', title);
 setTimeout(() => {
 window.location.href = page;
 }, 650);
 }
 function openCustomerService(){
 showToast('Connecting to support team...', 'info', 'Customer Service');
 setTimeout(() => {
 window.location.href = 'customer.html';
 }, 650);
 }
 loadUserData();
 document.addEventListener('gesturestart', e => e.preventDefault());
 document.addEventListener('gesturechange', e => e.preventDefault());
 document.addEventListener('gestureend', e => e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e => {
 const now = Date.now();
 if (now - lastTouch <= 300) e.preventDefault();
 lastTouch = now;
 }, { passive: false });
 document.addEventListener('wheel', e => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });
 document.addEventListener('keydown', e => {
 if ((e.ctrlKey || e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault();
 });