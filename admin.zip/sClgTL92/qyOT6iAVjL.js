window.APP_MODE = {
 DEMO_MODE: true,
 DEMO_USER: {
 uid: 'DEMO001',
 name: 'Demo User',
 email: 'demo@predxprofit.pk',
 whatsapp: '03001234567',
 wallet: 0,
 activePlans: 0,
 referralCode: 'PREDX001',
 todayEarning: 0,
 teamSize: 0,
 adsWatched: 0,
 joinDate: new Date('2026-01-15').toISOString()
 }
 };
 window.API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 register: "/auth/register",
 login: "/auth/login",
 logout: "/auth/logout",
 getUser: "/user/me",
 updateUser: "/user/update",
 getNextUID: "/meta/next-uid",
 getPlans: "/plans",
 createDeposit: "/deposits",
 getDeposits: "/deposits/me",
 createWithdraw: "/withdraws",
 getWithdraws: "/withdraws/me",
 watchAd: "/ads/watch",
 getAdsHistory: "/ads/history",
 getTeam: "/team/me",
 getTransactions: "/transactions/me",
 redeemGift: "/gifts/redeem",
 getChats: "/chats/me",
 sendMessage: "/chats/send",
 getMessages: "/chats/:id/messages",
 getLatestUpdate: "/updates/latest"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const loggedUser = localStorage.getItem('loggedUser');
 if (loggedUser) {
 try {
 const u = JSON.parse(loggedUser);
 if (u.uid) h["X-User-UID"] = u.uid;
 } catch(e) {}
 }
 return h;
 }
 };
 window.API = {
 async call(endpoint, method = "GET", body = null) {
 if (!API_CONFIG.baseURL) {
 return { success: false, error: "API baseURL not configured" };
 }
 const url = API_CONFIG.baseURL + endpoint;
 const options = { method, headers: API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) {
 return { success: false, error: data.message || data.error || "Request failed", data };
 }
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); },
 put(ep, body) { return this.call(ep, "PUT", body); },
 del(ep) { return this.call(ep, "DELETE"); }
 };
function showToast(msg, type = 'success', title = null) {
 const holder = document.getElementById('notifHolder');
 if (!holder) return;
 if (type === 'success') {
 const errKeywords = ['error','invalid','failed','not found','wrong','incorrect','already','required','enter ','please','too short','too long','try again','doesn\'t','cannot','can not','not registered','not match'];
 const lower = String(msg).toLowerCase();
 if (errKeywords.some(k => lower.includes(k))) type = 'error';
 }
 const icons = {
 success: '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
 error: '<svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
 info: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
 };
 const titles = {
 success: title || 'Success',
 error: title || 'Error',
 info: title || 'Info'
 };
 const notif = document.createElement('div');
 notif.className = 'premium-notif ' + type;
 notif.innerHTML = `
 <div class="premium-notif-icon">${icons[type]}</div>
 <div class="premium-notif-text">
 <div class="premium-notif-title">${titles[type]}</div>
 <div class="premium-notif-msg">${msg}</div>
 </div>
 <button class="premium-notif-close" onclick="this.parentElement.classList.remove('show');setTimeout(()=>this.parentElement.remove(),500);">
 <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
 </button>
 `;
 holder.appendChild(notif);
 requestAnimationFrame(() => notif.classList.add('show'));
 setTimeout(() => {
 if (notif.parentElement) {
 notif.classList.remove('show');
 setTimeout(() => notif.remove(), 500);
 }
 }, 3500);
 }
 function showLoading(){ document.getElementById('loadingOverlay').classList.add('active'); }
 function hideLoading(){ document.getElementById('loadingOverlay').classList.remove('active'); }
 const PLANS = [
 { amount: 600, badge: '🌱 Entry', icon: '<svg viewBox="0 0 24 24"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>' },
 { amount: 1200, badge: '🌿 Starter', icon: '<svg viewBox="0 0 24 24"><path d="M12 2l3 7h7l-5.5 4 2 7L12 16l-6.5 4 2-7L2 9h7z"/></svg>' },
 { amount: 1800, badge: '⭐ Popular', icon: '<svg viewBox="0 0 24 24"><path d="M2 4l3 12h14l3-12-6 7-4-7-4 7-6-7z"/></svg>' },
 { amount: 2400, badge: '🌟 Silver', icon: '<svg viewBox="0 0 24 24"><polygon points="12 2 15 9 22 9 17 14 19 21 12 17 5 21 7 14 2 9 9 9 12 2"/></svg>' },
 { amount: 4200, badge: '💫 Gold', icon: '<svg viewBox="0 0 24 24"><path d="M6 3h12l4 6-10 12L2 9z"/></svg>' },
 { amount: 5800, badge: '👑 Premium', icon: '<svg viewBox="0 0 24 24"><path d="M12 2l3 7h7l-5.5 4 2 7L12 16l-6.5 4 2-7L2 9h7z"/></svg>' },
 { amount: 8000, badge: '💎 Elite', icon: '<svg viewBox="0 0 24 24"><path d="M6 3h12l4 6-10 12L2 9z"/></svg>' },
 { amount: 12000, badge: '🔷 Diamond', icon: '<svg viewBox="0 0 24 24"><polygon points="12 2 15 9 22 9 17 14 19 21 12 17 5 21 7 14 2 9 9 9 12 2"/></svg>' },
 { amount: 18000, badge: '🏆 VIP', icon: '<svg viewBox="0 0 24 24"><path d="M2 4l3 12h14l3-12-6 7-4-7-4 7-6-7z"/></svg>' },
 { amount: 25000, badge: '💠 Royal', icon: '<svg viewBox="0 0 24 24"><path d="M12 2l3 7h7l-5.5 4 2 7L12 16l-6.5 4 2-7L2 9h7z"/></svg>' },
 { amount: 40000, badge: '🚀 Legend', icon: '<svg viewBox="0 0 24 24"><path d="M6 3h12l4 6-10 12L2 9z"/></svg>' }
 ];
 const PLAN_DAYS = 35;
 const THEMES = ['theme-green', 'theme-silver', 'theme-gold', 'theme-purple'];
 function calcDaily(amount) {
 return Math.round((amount / 600) * 120);
 }
 function calcTotal(amount) {
 return calcDaily(amount) * PLAN_DAYS;
 }
 function formatRs(n) {
 return 'Rs ' + n.toLocaleString('en-IN');
 }
 function renderPlans() {
 const wrap = document.getElementById('plansShowcase');
 if (!wrap) return;
 wrap.innerHTML = PLANS.map((p, idx) => {
 const theme = THEMES[idx % THEMES.length];
 const daily = calcDaily(p.amount);
 const total = calcTotal(p.amount);
 return `
 <div class="plan-show-card ${theme}">
 <div class="shine"></div>
 <div class="psc-inner">
 <div class="psc-top">
 <div class="psc-icon">${p.icon}</div>
 <div class="psc-name-block">
 <div class="psc-name">Rs ${p.amount.toLocaleString('en-IN')} Plan</div>
 <div class="psc-badge">${p.badge}</div>
 </div>
 </div>
 <div class="psc-invest-hero">
 <div class="psc-invest-lbl">
 <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
 Investment
 </div>
 <div class="psc-invest-val">${formatRs(p.amount)}</div>
 </div>
 <div class="psc-profit-grid">
 <div class="psc-profit-box">
 <div class="psc-profit-box-lbl">
 <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
 Daily Profit
 </div>
 <div class="psc-profit-box-val">${formatRs(daily)}</div>
 </div>
 <div class="psc-profit-box">
 <div class="psc-profit-box-lbl">
 <svg viewBox="0 0 24 24"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>
 Total Profit
 </div>
 <div class="psc-profit-box-val">${formatRs(total)}</div>
 </div>
 </div>
 <div class="psc-duration-bar">
 <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
 <div class="psc-duration-txt">Duration: <strong>${PLAN_DAYS} Days</strong></div>
 </div>
 <button class="psc-cta" onclick="openConfirm(${p.amount})">
 <svg viewBox="0 0 24 24"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
 <span>Invest Now</span>
 </button>
 </div>
 </div>
 `;
 }).join('');
 document.getElementById('planCountBadge').textContent = PLANS.length + ' PLANS';
 }
 renderPlans();
 let pendingPlanAmount = null;
 function openConfirm(amount) {
 pendingPlanAmount = amount;
 const daily = calcDaily(amount);
 const total = calcTotal(amount);
 document.getElementById('cdPlanName').textContent = 'Rs ' + amount.toLocaleString('en-IN') + ' Plan';
 document.getElementById('cdInvest').textContent = formatRs(amount);
 document.getElementById('cdDaily').textContent = formatRs(daily);
 document.getElementById('cdDuration').textContent = PLAN_DAYS + ' Days';
 document.getElementById('cdTotal').textContent = formatRs(total);
 document.getElementById('confirmOverlay').classList.add('active');
 }
 function closeConfirm() {
 document.getElementById('confirmOverlay').classList.remove('active');
 pendingPlanAmount = null;
 }
 function confirmInvest() {
 if (!pendingPlanAmount) {
 showToast('No plan selected', 'error', 'Error');
 return;
 }
 try {
 sessionStorage.setItem('selectedPlan', JSON.stringify({
 amount: pendingPlanAmount,
 daily: calcDaily(pendingPlanAmount),
 total: calcTotal(pendingPlanAmount),
 days: PLAN_DAYS
 }));
 } catch(e) {}
 document.getElementById('confirmOverlay').classList.remove('active');
 showToast('Plan selected! Redirecting...', 'success', 'Confirming');
 setTimeout(() => {
 window.location.href = 'active.html';
 }, 750);
 }
 function loadUserData(){
 const loggedUser = localStorage.getItem('loggedUser');
 let user = null;
 if (window.APP_MODE.DEMO_MODE) {
 if (loggedUser) {
 try { user = JSON.parse(loggedUser); } catch(e){}
 }
 if (!user || !user.uid) {
 user = window.APP_MODE.DEMO_USER;
 localStorage.setItem('loggedUser', JSON.stringify(user));
 }
 } else {
 if (!loggedUser) {
 window.location.replace('index.html');
 return;
 }
 try { user = JSON.parse(loggedUser); } catch(e){}
 if (!user || !user.uid) {
 window.location.replace('index.html');
 return;
 }
 }
 renderUserData(user);
 }
 let realBalance = 0;
 function renderUserData(user){
 if (!user) return;
 realBalance = user.wallet || 0;
 const wInt = Math.floor(realBalance);
 const wDec = (realBalance - wInt).toFixed(2).substring(1);
 document.getElementById('balInt').textContent = wInt.toLocaleString('en-IN');
 document.getElementById('balDec').textContent = wDec || '.00';
 document.getElementById('activePlanCount').textContent = user.activePlans || 0;
 adjustBalanceFont();
 }
 function adjustBalanceFont(){
 const wrap = document.getElementById('balAmount');
 if(!wrap) return;
 const text = document.getElementById('balInt').textContent || '';
 const len = text.length;
 let size = 34;
 if (len >= 8) size = 24;
 else if (len >= 7) size = 26;
 else if (len >= 6) size = 28;
 else if (len >= 5) size = 30;
 else if (len >= 4) size = 32;
 wrap.style.fontSize = size + 'px';
 }
 let balHidden = false;
 function toggleBal() {
 balHidden = !balHidden;
 const balInt = document.getElementById('balInt');
 const balDec = document.getElementById('balDec');
 const eyeIcon = document.getElementById('eyeIcon');
 if (balHidden) {
 balInt.textContent = '•••';
 balDec.textContent = '';
 eyeIcon.innerHTML = '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>';
 } else {
 const wInt = Math.floor(realBalance);
 const wDec = (realBalance - wInt).toFixed(2).substring(1);
 balInt.textContent = wInt.toLocaleString('en-IN');
 balDec.textContent = wDec || '.00';
 eyeIcon.innerHTML = '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>';
 }
 adjustBalanceFont();
 }
 function goTo(page) {
 setTimeout(() => { window.location.href = page; }, 100);
 }
 function goToWithNotif(page, title, message){
 showToast(message || ('Opening ' + title + '...'), 'info', title);
 setTimeout(() => {
 window.location.href = page;
 }, 650);
 }
 function openCustomerService(){
 showToast('Connecting to support team...', 'info', 'Customer Service');
 setTimeout(() => {
 window.location.href = 'customer.html';
 }, 650);
 }
 loadUserData();
 document.addEventListener('gesturestart', e => e.preventDefault());
 document.addEventListener('gesturechange', e => e.preventDefault());
 document.addEventListener('gestureend', e => e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e => {
 const now = Date.now();
 if (now - lastTouch <= 300) e.preventDefault();
 lastTouch = now;
 }, { passive: false });
 document.addEventListener('wheel', e => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });
 document.addEventListener('keydown', e => {
 if ((e.ctrlKey || e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault();
 });