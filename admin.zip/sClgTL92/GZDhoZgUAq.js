window.APP_MODE = {
 DEMO_MODE: true,
 DEMO_USER: {
 uid: 'DEMO001',
 name: 'Demo User',
 email: 'demo@predxprofit.pk',
 whatsapp: '03001234567',
 wallet: 0,
 withdrawableWallet: 0,
 activePlans: 0,
 referralCode: 'PREDX001',
 todayEarning: 0,
 teamSize: 0,
 teamList: [],
 referralBalance: 0,
 weeklySalary: 0,
 adsWatched: 0,
 joinDate: new Date('2026-01-15').toISOString(),
 transactions: [],
 deposits: [],
 withdraws: [],
 giftClaims: [],
 chatHistory: []
 }
 };
 window.API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 register: "/auth/register",
 login: "/auth/login",
 logout: "/auth/logout",
 getUser: "/user/me",
 updateUser: "/user/update",
 changePassword: "/user/change-password",
 getNextUID: "/meta/next-uid",
 getPlans: "/plans",
 createDeposit: "/deposits",
 getDeposits: "/deposits/me",
 createWithdraw: "/withdraws",
 getWithdraws: "/withdraws/me",
 watchAd: "/ads/watch",
 getAdsHistory: "/ads/history",
 getTeam: "/team/me",
 getTransactions: "/transactions/me",
 redeemGift: "/gifts/redeem",
 getChats: "/chats/me",
 sendMessage: "/chats/send",
 getMessages: "/chats/:id/messages",
 getLatestUpdate: "/updates/latest",
 getPaymentSettings: "/settings/payment",
 submitDepositProof: "/deposits/submit"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const loggedUser = localStorage.getItem('loggedUser');
 if (loggedUser) {
 try {
 const u = JSON.parse(loggedUser);
 if (u.uid) h["X-User-UID"] = u.uid;
 } catch(e) {}
 }
 return h;
 }
 };
 window.API = {
 async call(endpoint, method = "GET", body = null) {
 if (!API_CONFIG.baseURL) return { success: false, error: "API baseURL not configured" };
 const url = API_CONFIG.baseURL + endpoint;
 const options = { method, headers: API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) return { success: false, error: data.message || data.error || "Request failed", data };
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); },
 put(ep, body) { return this.call(ep, "PUT", body); },
 del(ep) { return this.call(ep, "DELETE"); }
 };
function showToast(msg, type = 'success', title = null) {
 const holder = document.getElementById('notifHolder');
 if (!holder) return;
 if (type === 'success') {
 const errKeywords = ['error','invalid','failed','not found','wrong','incorrect','already','required','enter ','please','too short','too long','try again','doesn\'t','cannot','can not','not registered','not match'];
 const lower = String(msg).toLowerCase();
 if (errKeywords.some(k => lower.includes(k))) type = 'error';
 }
 const icons = {
 success: '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
 error: '<svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
 info: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
 };
 const titles = { success: title || 'Success', error: title || 'Error', info: title || 'Info' };
 const notif = document.createElement('div');
 notif.className = 'premium-notif ' + type;
 notif.innerHTML = `
 <div class="premium-notif-icon">${icons[type]}</div>
 <div class="premium-notif-text">
 <div class="premium-notif-title">${titles[type]}</div>
 <div class="premium-notif-msg">${msg}</div>
 </div>
 <button class="premium-notif-close" onclick="this.parentElement.classList.remove('show');setTimeout(()=>this.parentElement.remove(),500);">
 <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
 </button>
 `;
 holder.appendChild(notif);
 requestAnimationFrame(() => notif.classList.add('show'));
 setTimeout(() => {
 if (notif.parentElement) {
 notif.classList.remove('show');
 setTimeout(() => notif.remove(), 500);
 }
 }, 3500);
 }
 const DEMO_TRANSACTIONS = [
 { type: 'deposit', title: 'Deposit — Rs 600 Plan', amount: 600, date: '14 Oct 2026', time: '10:24 AM', status: 'success' },
 { type: 'deposit', title: 'Deposit — Rs 1200 Plan', amount: 1200, date: '14 Oct 2026', time: '09:11 AM', status: 'success' },
 { type: 'deposit', title: 'Deposit — Rs 2400 Plan', amount: 2400, date: '12 Oct 2026', time: '06:30 PM', status: 'success' },
 { type: 'withdraw', title: 'Withdraw — Easypaisa', amount: 900, date: '01 Oct 2026', time: '08:07 AM', status: 'success' },
 { type: 'withdraw', title: 'Withdraw — Easypaisa', amount: 1360, date: '27 Sep 2026', time: '10:41 AM', status: 'success' },
 { type: 'ads', title: 'Ad Watched — Rs 600 Plan', amount: 120, date: '14 Oct 2026', time: '10:30 AM', status: 'success' },
 { type: 'ads', title: 'Ad Watched — Rs 1200 Plan', amount: 240, date: '14 Oct 2026', time: '09:15 AM', status: 'success' },
 { type: 'salary', title: 'Weekly Salary Bonus', amount: 2500, date: '10 Oct 2026', time: '12:00 PM', status: 'success' },
 { type: 'gift', title: 'Gift Code — WELCOME100', amount: 100, date: '08 Oct 2026', time: '05:14 PM', status: 'success' }
 ];
 let TRANSACTIONS = [];
 let currentFilter = 'all';
 let user = null;
 const TYPE_CONFIG = {
 deposit: {
 icon: '<svg viewBox="0 0 24 24"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="5 12 12 19 19 12"/></svg>',
 sign: '+',
 label: 'DEPOSIT'
 },
 withdraw: {
 icon: '<svg viewBox="0 0 24 24"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>',
 sign: '−',
 label: 'WITHDRAW'
 },
 ads: {
 icon: '<svg viewBox="0 0 24 24"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>',
 sign: '+',
 label: 'AD WATCH'
 },
 salary: {
 icon: '<svg viewBox="0 0 24 24"><rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13"/><path d="M5 12v9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-9"/><path d="M8 8a3 3 0 0 1 0-6c2 0 4 3 4 6"/><path d="M16 8a3 3 0 0 0 0-6c-2 0-4 3-4 6"/></svg>',
 sign: '+',
 label: 'SALARY'
 },
 gift: {
 icon: '<svg viewBox="0 0 24 24"><rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13"/><path d="M5 12v9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-9"/><path d="M8 8a3 3 0 0 1 0-6c2 0 4 3 4 6"/><path d="M16 8a3 3 0 0 0 0-6c-2 0-4 3-4 6"/></svg>',
 sign: '+',
 label: 'GIFT CODE'
 }
 };
 function loadUserData(){
 const loggedUser = localStorage.getItem('loggedUser');
 if (window.APP_MODE.DEMO_MODE) {
 if (loggedUser) {
 try { user = JSON.parse(loggedUser); } catch(e){}
 }
 if (!user || !user.uid) {
 user = JSON.parse(JSON.stringify(window.APP_MODE.DEMO_USER));
 localStorage.setItem('loggedUser', JSON.stringify(user));
 }
 } else {
 if (!loggedUser) {
 window.location.replace('index.html');
 return;
 }
 try { user = JSON.parse(loggedUser); } catch(e){}
 if (!user || !user.uid) {
 window.location.replace('index.html');
 return;
 }
 }
 loadTransactions();
 }
 function loadTransactions(){
 let all = [];
 if (Array.isArray(user.transactions) && user.transactions.length > 0) {
 all = all.concat(user.transactions.map(normalizeTx));
 }
 if (Array.isArray(user.deposits) && user.deposits.length > 0) {
 all = all.concat(user.deposits.map(d => normalizeTx({ ...d, type: 'deposit' })));
 }
 if (Array.isArray(user.withdraws) && user.withdraws.length > 0) {
 all = all.concat(user.withdraws.map(w => normalizeTx({ ...w, type: 'withdraw' })));
 }
 if (Array.isArray(user.giftClaims) && user.giftClaims.length > 0) {
 all = all.concat(user.giftClaims.map(g => normalizeTx({ ...g, type: 'gift' })));
 }
 if (Array.isArray(user.adsHistory) && user.adsHistory.length > 0) {
 all = all.concat(user.adsHistory.map(a => normalizeTx({ ...a, type: 'ads' })));
 }
 if (all.length > 0) {
 all.sort((a, b) => (b._ts || 0) - (a._ts || 0));
 TRANSACTIONS = all;
 }
 else if (window.APP_MODE.DEMO_MODE) {
 TRANSACTIONS = DEMO_TRANSACTIONS.map(normalizeTx);
 }
 else {
 TRANSACTIONS = [];
 }
 render();
 }
 function normalizeTx(t){
 let type = (t.type || '').toLowerCase();
 if (type === 'withdrawal') type = 'withdraw';
 if (type === 'ad') type = 'ads';
 if (type === 'giftcode' || type === 'gift_code' || type === 'redeem') type = 'gift';
 if (type === 'weeklysalary' || type === 'weekly_salary' || type === 'bonus') type = 'salary';
 if (!TYPE_CONFIG[type]) type = 'deposit'; 
 const amount = Number(t.amount || t.planAmount || t.withdrawAmount || t.reward || t.value || 0);
 let dateStr = t.date || '', timeStr = t.time || '', ts = 0;
 if (t.submittedAt || t.createdAt || t.dateIso) {
 const dt = new Date(t.submittedAt || t.createdAt || t.dateIso);
 ts = dt.getTime();
 dateStr = dt.getDate() + ' ' + ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][dt.getMonth()] + ' ' + dt.getFullYear();
 let h = dt.getHours(); const m = String(dt.getMinutes()).padStart(2,'0');
 const ampm = h >= 12 ? 'PM' : 'AM'; h = h % 12; if (h === 0) h = 12;
 timeStr = `${String(h).padStart(2,'0')}:${m} ${ampm}`;
 }
 let status = (t.status || 'success').toLowerCase();
 if (status === 'completed' || status === 'approved' || status === 'paid') status = 'success';
 if (status === 'failed' || status === 'rejected' || status === 'cancelled') status = 'failed';
 let title = t.title || t.description || '';
 if (!title) {
 if (type === 'deposit') title = 'Deposit — Rs ' + amount.toLocaleString('en-IN') + ' Plan';
 else if (type === 'withdraw') title = 'Withdraw — ' + (t.method || 'Easypaisa');
 else if (type === 'ads') title = 'Ad Watched Reward';
 else if (type === 'salary') title = 'Weekly Salary Bonus';
 else if (type === 'gift') title = 'Gift Code — ' + (t.code || '');
 }
 return {
 type: type,
 title: title,
 amount: amount,
 date: dateStr || '—',
 time: timeStr || '—',
 status: status,
 _ts: ts
 };
 }
 function statusIcon(status) {
 if (status === 'success') return '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>';
 if (status === 'pending') return '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>';
 return '<svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
 }
 function statusLabel(status) {
 if (status === 'success') return 'Completed';
 if (status === 'pending') return 'Pending';
 return 'Failed';
 }
 function render() {
 const list = document.getElementById('txList');
 const countEl = document.getElementById('txCount');
 if (!list) return;
 const filtered = currentFilter === 'all'
 ? TRANSACTIONS
 : TRANSACTIONS.filter(t => t.type === currentFilter);
 countEl.textContent = filtered.length + ' ITEM' + (filtered.length !== 1 ? 'S' : '');
 if (filtered.length === 0) {
 list.innerHTML = `
 <div class="empty-state">
 <div class="empty-icon">
 <svg viewBox="0 0 24 24">
 <rect x="3" y="4" width="18" height="16" rx="2"/>
 <line x1="3" y1="10" x2="21" y2="10"/>
 <line x1="7" y1="15" x2="11" y2="15"/>
 </svg>
 </div>
 <div class="empty-title">No Transactions Found</div>
 <div class="empty-desc">Try another filter</div>
 </div>
 `;
 return;
 }
 list.innerHTML = filtered.map(t => {
 const cfg = TYPE_CONFIG[t.type] || TYPE_CONFIG.deposit;
 return `
 <div class="tx-card ${t.type}">
 <div class="tx-top">
 <div class="tx-icon">${cfg.icon}</div>
 <div class="tx-info-block">
 <div class="tx-title">${escapeHtml(t.title)}</div>
 <div class="tx-datetime">
 <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
 <span>${t.date}, ${t.time}</span>
 </div>
 </div>
 <div class="tx-amount">${cfg.sign}Rs ${t.amount.toLocaleString('en-IN')}</div>
 </div>
 <div class="tx-divider"></div>
 <div class="tx-bottom">
 <div class="tx-type-lbl">
 <svg viewBox="0 0 24 24"><path d="M4 7V4h16v3"/><path d="M9 20h6"/><path d="M12 4v16"/></svg>
 <span>Type: <strong>${cfg.label}</strong></span>
 </div>
 <div class="tx-status ${t.status}">
 <span class="st-icon">${statusIcon(t.status)}</span>
 <span>${statusLabel(t.status)}</span>
 </div>
 </div>
 </div>
 `;
 }).join('');
 }
 function escapeHtml(s) {
 return String(s)
 .replace(/&/g, '&amp;')
 .replace(/</g, '&lt;')
 .replace(/>/g, '&gt;')
 .replace(/"/g, '&quot;')
 .replace(/'/g, '&#39;');
 }
 /* ==========================================================
 FILTER
 ========================================================== */
 function setFilter(filter, el) {
 currentFilter = filter;
 document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
 if (el) el.classList.add('active');
 render();
 }
 /* ==========================================================
 NAV
 ========================================================== */
 function goTo(page) { setTimeout(() => { window.location.href = page; }, 100); }
 function goToWithNotif(page, title, message){
 showToast(message || ('Opening ' + title + '...'), 'info', title);
 setTimeout(() => {
 window.location.href = page;
 }, 650);
 }
 function openCustomerService(){
 showToast('Connecting to support team...', 'info', 'Customer Service');
 setTimeout(() => {
 window.location.href = 'customer.html';
 }, 650);
 }
 /* ==========================================================
 INIT
 ========================================================== */
 loadUserData();
 /* ZOOM BLOCK */
 document.addEventListener('gesturestart', e => e.preventDefault());
 document.addEventListener('gesturechange', e => e.preventDefault());
 document.addEventListener('gestureend', e => e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e => {
 const now = Date.now();
 if (now - lastTouch <= 300) e.preventDefault();
 lastTouch = now;
 }, { passive: false });
 document.addEventListener('wheel', e => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });
 document.addEventListener('keydown', e => {
 if ((e.ctrlKey || e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault();
 });