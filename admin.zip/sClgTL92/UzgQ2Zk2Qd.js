window.APP_MODE = {
 DEMO_MODE: true,
 DEMO_USER: {
 uid: 'DEMO001',
 name: 'Demo User',
 email: 'demo@predxprofit.pk',
 whatsapp: '03001234567',
 wallet: 0,
 withdrawableWallet: 0,
 activePlans: 0,
 referralCode: 'PREDX001',
 todayEarning: 0,
 teamSize: 0,
 teamList: [],
 referralBalance: 0,
 weeklySalary: 0,
 adsWatched: 0,
 joinDate: new Date('2026-01-15').toISOString(),
 transactions: [],
 deposits: [],
 giftClaims: [],
 chatHistory: []
 }
 };
 window.API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 register: "/auth/register",
 login: "/auth/login",
 logout: "/auth/logout",
 getUser: "/user/me",
 updateUser: "/user/update",
 changePassword: "/user/change-password",
 getNextUID: "/meta/next-uid",
 getPlans: "/plans",
 createDeposit: "/deposits",
 getDeposits: "/deposits/me",
 createWithdraw: "/withdraws",
 getWithdraws: "/withdraws/me",
 watchAd: "/ads/watch",
 getAdsHistory: "/ads/history",
 getTeam: "/team/me",
 getTransactions: "/transactions/me",
 redeemGift: "/gifts/redeem",
 getChats: "/chats/me",
 sendMessage: "/chats/send",
 getMessages: "/chats/:id/messages",
 getLatestUpdate: "/updates/latest",
 getPaymentSettings: "/settings/payment",
 submitDepositProof: "/deposits/submit"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const loggedUser = localStorage.getItem('loggedUser');
 if (loggedUser) {
 try {
 const u = JSON.parse(loggedUser);
 if (u.uid) h["X-User-UID"] = u.uid;
 } catch(e) {}
 }
 return h;
 }
 };
 window.API = {
 async call(endpoint, method = "GET", body = null) {
 if (!API_CONFIG.baseURL) return { success: false, error: "API baseURL not configured" };
 const url = API_CONFIG.baseURL + endpoint;
 const options = { method, headers: API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) return { success: false, error: data.message || data.error || "Request failed", data };
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); },
 put(ep, body) { return this.call(ep, "PUT", body); },
 del(ep) { return this.call(ep, "DELETE"); }
 };
function showToast(msg, type = 'success', title = null) {
 const holder = document.getElementById('notifHolder');
 if (!holder) return;
 if (type === 'success') {
 const errKeywords = ['error','invalid','failed','not found','wrong','incorrect','already','required','enter ','please','too short','too long','try again','doesn\'t','cannot','can not','not registered','not match'];
 const lower = String(msg).toLowerCase();
 if (errKeywords.some(k => lower.includes(k))) type = 'error';
 }
 const icons = {
 success: '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
 error: '<svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
 info: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
 };
 const titles = { success: title || 'Success', error: title || 'Error', info: title || 'Info' };
 const notif = document.createElement('div');
 notif.className = 'premium-notif ' + type;
 notif.innerHTML = `
 <div class="premium-notif-icon">${icons[type]}</div>
 <div class="premium-notif-text">
 <div class="premium-notif-title">${titles[type]}</div>
 <div class="premium-notif-msg">${msg}</div>
 </div>
 <button class="premium-notif-close" onclick="this.parentElement.classList.remove('show');setTimeout(()=>this.parentElement.remove(),500);">
 <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
 </button>
 `;
 holder.appendChild(notif);
 requestAnimationFrame(() => notif.classList.add('show'));
 setTimeout(() => {
 if (notif.parentElement) {
 notif.classList.remove('show');
 setTimeout(() => notif.remove(), 500);
 }
 }, 3500);
 }
 const DEMO_DEPOSITS = [
 {
 plan: 600, tid: 'TXN8439217', date: '14/10/2026', time: '10:24:11 am',
 status: 'approved', accountName: 'Ahmed Khan', accountNumber: '03001234567',
 approvedDate: '14/10/2026, 10:26:00 am', dailyProfit: 120, duration: 35, totalProfit: 4200,
 screenshot: '', rejectReason: ''
 },
 {
 plan: 1200, tid: 'TXN8438105', date: '14/10/2026', time: '09:11:34 am',
 status: 'approved', accountName: 'Ahmed Khan', accountNumber: '03001234567',
 approvedDate: '14/10/2026, 09:13:20 am', dailyProfit: 240, duration: 35, totalProfit: 8400,
 screenshot: '', rejectReason: ''
 },
 {
 plan: 600, tid: 'TXN8409273', date: '10/10/2026', time: '04:20:08 pm',
 status: 'pending', accountName: 'Ahmed Khan', accountNumber: '03001234567',
 approvedDate: '', dailyProfit: 120, duration: 35, totalProfit: 4200,
 screenshot: '', rejectReason: ''
 },
 {
 plan: 1200, tid: 'TXN8384019', date: '05/10/2026', time: '09:40:55 am',
 status: 'rejected', accountName: 'Ahmed Khan', accountNumber: '03001234567',
 approvedDate: '', dailyProfit: 240, duration: 35, totalProfit: 8400,
 screenshot: '', rejectReason: 'Screenshot clear nahi tha aur TID verify nahi ho saki.'
 }
 ];
 let DEPOSITS = [];
 let currentFilter = 'all';
 let user = null;
 function loadUserData(){
 const loggedUser = localStorage.getItem('loggedUser');
 if (window.APP_MODE.DEMO_MODE) {
 if (loggedUser) {
 try { user = JSON.parse(loggedUser); } catch(e){}
 }
 if (!user || !user.uid) {
 user = JSON.parse(JSON.stringify(window.APP_MODE.DEMO_USER));
 localStorage.setItem('loggedUser', JSON.stringify(user));
 }
 } else {
 if (!loggedUser) {
 window.location.replace('index.html');
 return;
 }
 try { user = JSON.parse(loggedUser); } catch(e){}
 if (!user || !user.uid) {
 window.location.replace('index.html');
 return;
 }
 }
 loadDeposits();
 }
 function loadDeposits(){
 if (Array.isArray(user.deposits) && user.deposits.length > 0) {
 DEPOSITS = user.deposits.map(normalizeDeposit);
 }
 else if (Array.isArray(user.transactions) && user.transactions.length > 0) {
 const deps = user.transactions.filter(t => t.type === 'deposit');
 DEPOSITS = deps.map(normalizeDeposit);
 }
 else if (window.APP_MODE.DEMO_MODE) {
 DEPOSITS = DEMO_DEPOSITS;
 }
 else {
 DEPOSITS = [];
 }
 render();
 }
 function normalizeDeposit(d){
 let dateStr = d.date || '', timeStr = d.time || '';
 if (!dateStr && d.submittedAt) {
 const dt = new Date(d.submittedAt);
 dateStr = String(dt.getDate()).padStart(2,'0') + '/' + String(dt.getMonth()+1).padStart(2,'0') + '/' + dt.getFullYear();
 let h = dt.getHours(); const m = String(dt.getMinutes()).padStart(2,'0'); const s = String(dt.getSeconds()).padStart(2,'0');
 const ampm = h >= 12 ? 'pm' : 'am'; h = h % 12; if (h === 0) h = 12;
 timeStr = `${String(h).padStart(2,'0')}:${m}:${s} ${ampm}`;
 }
 const plan = d.planAmount || d.plan || 0;
 const dailyProfit = d.dailyProfit || d.daily || Math.round((plan/600)*120);
 const duration = d.days || d.duration || 35;
 const totalProfit = d.totalProfit || (dailyProfit * duration);
 return {
 plan: plan,
 tid: d.tid || d.transactionId || '—',
 date: dateStr || '—',
 time: timeStr || '—',
 status: d.status || 'pending',
 accountName: d.accountName || user.name || 'User',
 accountNumber: d.accountNumber || '—',
 approvedDate: d.approvedDate || '',
 dailyProfit: dailyProfit,
 duration: duration,
 totalProfit: totalProfit,
 screenshot: d.screenshot || d.screenshotUrl || '',
 rejectReason: d.rejectReason || d.reason || ''
 };
 }
 function statusIconSVG(status) {
 if (status === 'approved') return '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>';
 if (status === 'pending') return '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>';
 return '<svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
 }
 function statusLabel(status) {
 if (status === 'approved') return 'Approved';
 if (status === 'pending') return 'Pending';
 return 'Rejected';
 }
 function statusTitle(status) {
 if (status === 'approved') return 'Deposit Approved';
 if (status === 'pending') return 'Deposit Pending';
 return 'Deposit Rejected';
 }
 function statusSub(status) {
 if (status === 'approved') return 'Plan activated';
 if (status === 'pending') return 'Under verification';
 return 'Request rejected';
 }
 function render() {
 const list = document.getElementById('depositList');
 const countEl = document.getElementById('historyCount');
 if (!list) return;
 const filtered = currentFilter === 'all'
 ? DEPOSITS
 : DEPOSITS.filter(d => d.status === currentFilter);
 countEl.textContent = filtered.length + ' ITEM' + (filtered.length !== 1 ? 'S' : '');
 if (filtered.length === 0) {
 list.innerHTML = `
 <div class="empty-state">
 <div class="empty-icon">
 <svg viewBox="0 0 24 24">
 <line x1="12" y1="5" x2="12" y2="19"/>
 <polyline points="5 12 12 19 19 12"/>
 </svg>
 </div>
 <div class="empty-title">No Deposits Found</div>
 <div class="empty-desc">Your deposit history will appear here</div>
 </div>
 `;
 return;
 }
 list.innerHTML = filtered.map((d) => {
 const realIdx = DEPOSITS.indexOf(d);
 return `
 <div class="dp-card ${d.status}" onclick="openDetail(${realIdx})">
 <div class="dp-top">
 <div class="dp-icon">
 <svg viewBox="0 0 24 24">
 <line x1="12" y1="5" x2="12" y2="19"/>
 <polyline points="5 12 12 19 19 12"/>
 </svg>
 </div>
 <div class="dp-plan-block">
 <div class="dp-plan">Rs ${d.plan.toLocaleString('en-IN')} Plan</div>
 <div class="dp-datetime">
 <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
 <span>${d.date}, ${d.time}</span>
 </div>
 </div>
 <div class="dp-amount">+Rs ${d.plan.toLocaleString('en-IN')}</div>
 </div>
 <div class="dp-divider"></div>
 <div class="dp-bottom">
 <div class="dp-tid">
 <svg viewBox="0 0 24 24"><line x1="4" y1="9" x2="20" y2="9"/><line x1="4" y1="15" x2="20" y2="15"/><line x1="10" y1="3" x2="8" y2="21"/><line x1="16" y1="3" x2="14" y2="21"/></svg>
 <span>Transaction ID: <strong>${d.tid}</strong></span>
 </div>
 <div class="dp-status ${d.status}">
 <span class="st-icon">${statusIconSVG(d.status)}</span>
 <span>${statusLabel(d.status)}</span>
 </div>
 </div>
 </div>
 `;
 }).join('');
 }
 function openDetail(idx) {
 const d = DEPOSITS[idx];
 if (!d) return;
 const dialog = document.getElementById('detailDialog');
 const icon = document.getElementById('ddIcon');
 const title = document.getElementById('ddTitle');
 const sub = document.getElementById('ddSub');
 const body = document.getElementById('ddBody');
 const closeBtn = document.getElementById('ddCloseBtn');
 dialog.className = 'detail-dialog ' + d.status;
 closeBtn.className = 'dd-close-btn ' + d.status;
 icon.innerHTML = statusIconSVG(d.status);
 title.textContent = statusTitle(d.status);
 sub.textContent = statusSub(d.status);
 let html = `
 <div class="dd-amount-hero ${d.status}">
 <div class="dd-amount-lbl">Deposit Amount</div>
 <div class="dd-amount-val">+Rs ${d.plan.toLocaleString('en-IN')}</div>
 </div>
 <div class="dd-row">
 <div class="dd-row-lbl">
 <svg viewBox="0 0 24 24"><line x1="4" y1="9" x2="20" y2="9"/><line x1="4" y1="15" x2="20" y2="15"/><line x1="10" y1="3" x2="8" y2="21"/><line x1="16" y1="3" x2="14" y2="21"/></svg>
 TID
 </div>
 <div class="dd-row-val">${d.tid}</div>
 </div>
 <div class="dd-row">
 <div class="dd-row-lbl">
 <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
 Date
 </div>
 <div class="dd-row-val blue">${d.date}</div>
 </div>
 <div class="dd-row">
 <div class="dd-row-lbl">
 <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
 Time
 </div>
 <div class="dd-row-val blue">${d.time}</div>
 </div>
 <div class="dd-section-lbl">
 <svg viewBox="0 0 24 24"><path d="M12 2l3 7h7l-5.5 4 2 7L12 16l-6.5 4 2-7L2 9h7z"/></svg>
 Plan Details
 </div>
 <div class="dd-plan-card">
 <div class="dd-plan-row">
 <span class="dd-plan-lbl">Plan</span>
 <span class="dd-plan-val">Rs ${d.plan.toLocaleString('en-IN')} Plan</span>
 </div>
 <div class="dd-plan-row">
 <span class="dd-plan-lbl">Daily Profit</span>
 <span class="dd-plan-val gold">Rs ${d.dailyProfit.toLocaleString('en-IN')}</span>
 </div>
 <div class="dd-plan-row">
 <span class="dd-plan-lbl">Duration</span>
 <span class="dd-plan-val">${d.duration} Days</span>
 </div>
 <div class="dd-plan-row">
 <span class="dd-plan-lbl">Total Profit</span>
 <span class="dd-plan-val gold">Rs ${d.totalProfit.toLocaleString('en-IN')}</span>
 </div>
 </div>
 <div class="dd-section-lbl">
 <svg viewBox="0 0 24 24"><path d="M3 21h18M5 21V7l7-4 7 4v14M9 21v-6h6v6"/></svg>
 Payment Sent From
 </div>
 <div class="dd-bank-card">
 <div class="dd-bank-row">
 <span class="dd-bank-lbl">Account Name</span>
 <span class="dd-bank-val">${d.accountName}</span>
 </div>
 <div class="dd-bank-row">
 <span class="dd-bank-lbl">Account Number</span>
 <span class="dd-bank-val mono">${d.accountNumber}</span>
 </div>
 <div class="dd-bank-row">
 <span class="dd-bank-lbl">Method</span>
 <span class="dd-bank-val">Easypaisa</span>
 </div>
 </div>
 `;
 if (d.screenshot) {
 html += `
 <div class="dd-screenshot">
 <div class="dd-ss-lbl">
 <svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
 Payment Screenshot
 </div>
 <img class="dd-ss-img" src="${d.screenshot}" alt="Screenshot" onerror="this.style.display='none'">
 </div>
 `;
 }
 if (d.status === 'approved') {
 html += `
 <div class="dd-approved-note" style="margin-top:12px;">
 <div class="dd-approved-title">
 <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
 Deposit Successful
 </div>
 <div class="dd-approved-text">
 Aap ka plan <strong>Rs ${d.plan.toLocaleString('en-IN')}</strong> successfully activate ho gaya hai. Daily Rs ${d.dailyProfit} profit milna shuru ho gaya hai.
 ${d.approvedDate ? '<br><br><strong>Approved on:</strong> ' + d.approvedDate : ''}
 </div>
 </div>
 `;
 } else if (d.status === 'pending') {
 html += `
 <div class="dd-pending-note" style="margin-top:12px;">
 <div class="dd-pending-title">
 <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
 Under Verification
 </div>
 <div class="dd-pending-text">
 Aap ki deposit request verify ki ja rahi hai. Aam taur par <strong>30 minute</strong> ke andar approve ho jati hai. Thoda intezaar karein.
 </div>
 </div>
 `;
 } else {
 html += `
 <div class="dd-reason-box" style="margin-top:12px;">
 <div class="dd-reason-title">
 <svg viewBox="0 0 24 24"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
 Rejection Reason
 </div>
 <div class="dd-reason-text">${d.rejectReason || 'Koi wajah nahi di gayi.'}</div>
 </div>
 `;
 }
 body.innerHTML = html;
 document.getElementById('detailOverlay').classList.add('active');
 }
 function closeDetail() {
 document.getElementById('detailOverlay').classList.remove('active');
 }
 function closeDetailOutside(e) {
 if (e.target.id === 'detailOverlay') closeDetail();
 }
 function setFilter(filter, el) {
 currentFilter = filter;
 document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
 if (el) el.classList.add('active');
 render();
 }
 function goTo(page) { setTimeout(() => { window.location.href = page; }, 100); }
 function goToWithNotif(page, title, message){
 showToast(message || ('Opening ' + title + '...'), 'info', title);
 setTimeout(() => {
 window.location.href = page;
 }, 650);
 }
 function openCustomerService(){
 showToast('Connecting to support team...', 'info', 'Customer Service');
 setTimeout(() => {
 window.location.href = 'customer.html';
 }, 650);
 }
 loadUserData();
 document.addEventListener('gesturestart', e => e.preventDefault());
 document.addEventListener('gesturechange', e => e.preventDefault());
 document.addEventListener('gestureend', e => e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e => {
 const now = Date.now();
 if (now - lastTouch <= 300) e.preventDefault();
 lastTouch = now;
 }, { passive: false });
 document.addEventListener('wheel', e => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });
 document.addEventListener('keydown', e => {
 if ((e.ctrlKey || e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault();
 });