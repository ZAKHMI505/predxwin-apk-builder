window.APP_MODE = {
 DEMO_MODE: true,
 DEMO_USER: {
 uid: 'DEMO001',
 name: 'Demo User',
 email: 'demo@predxprofit.pk',
 whatsapp: '03001234567',
 wallet: 0,
 withdrawableWallet: 0,
 activePlans: 0,
 referralCode: 'PREDX001',
 todayEarning: 0,
 teamSize: 0,
 teamList: [],
 referralBalance: 0,
 weeklySalary: 0,
 adsWatched: 0,
 joinDate: new Date('2026-01-15').toISOString(),
 transactions: [],
 giftClaims: []
 }
 };
 window.PAYMENT_SETTINGS = {
 qrImageUrl: '',
 method: 'Easypaisa',
 accountName: 'Parveen Bibi',
 accountNumber: '03461885739',
 bankName: '',
 iban: ''
 };
 window.API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 register: "/auth/register",
 login: "/auth/login",
 logout: "/auth/logout",
 getUser: "/user/me",
 updateUser: "/user/update",
 changePassword: "/user/change-password",
 getNextUID: "/meta/next-uid",
 getPlans: "/plans",
 createDeposit: "/deposits",
 getDeposits: "/deposits/me",
 createWithdraw: "/withdraws",
 getWithdraws: "/withdraws/me",
 watchAd: "/ads/watch",
 getAdsHistory: "/ads/history",
 getTeam: "/team/me",
 getTransactions: "/transactions/me",
 redeemGift: "/gifts/redeem",
 getChats: "/chats/me",
 sendMessage: "/chats/send",
 getMessages: "/chats/:id/messages",
 getLatestUpdate: "/updates/latest",
 getPaymentSettings: "/settings/payment",
 submitDepositProof: "/deposits/submit"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const loggedUser = localStorage.getItem('loggedUser');
 if (loggedUser) {
 try {
 const u = JSON.parse(loggedUser);
 if (u.uid) h["X-User-UID"] = u.uid;
 } catch(e) {}
 }
 return h;
 }
 };
 window.API = {
 async call(endpoint, method = "GET", body = null) {
 if (!API_CONFIG.baseURL) return { success: false, error: "API baseURL not configured" };
 const url = API_CONFIG.baseURL + endpoint;
 const options = { method, headers: API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) return { success: false, error: data.message || data.error || "Request failed", data };
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); },
 put(ep, body) { return this.call(ep, "PUT", body); },
 del(ep) { return this.call(ep, "DELETE"); }
 };
function showToast(msg, type = 'success', title = null) {
 const holder = document.getElementById('notifHolder');
 if (!holder) return;
 if (type === 'success') {
 const errKeywords = ['error','invalid','failed','not found','wrong','incorrect','already','required','enter ','please','too short','too long','try again','doesn\'t','cannot','can not','not registered','not match'];
 const lower = String(msg).toLowerCase();
 if (errKeywords.some(k => lower.includes(k))) type = 'error';
 }
 const icons = {
 success: '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
 error: '<svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
 info: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
 };
 const titles = { success: title || 'Success', error: title || 'Error', info: title || 'Info' };
 const notif = document.createElement('div');
 notif.className = 'premium-notif ' + type;
 notif.innerHTML = `
 <div class="premium-notif-icon">${icons[type]}</div>
 <div class="premium-notif-text">
 <div class="premium-notif-title">${titles[type]}</div>
 <div class="premium-notif-msg">${msg}</div>
 </div>
 <button class="premium-notif-close" onclick="this.parentElement.classList.remove('show');setTimeout(()=>this.parentElement.remove(),500);">
 <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
 </button>
 `;
 holder.appendChild(notif);
 requestAnimationFrame(() => notif.classList.add('show'));
 setTimeout(() => {
 if (notif.parentElement) {
 notif.classList.remove('show');
 setTimeout(() => notif.remove(), 500);
 }
 }, 3500);
 }
 let selectedPlan = { amount: 600, daily: 120, total: 4200, days: 35 };
 try {
 const saved = sessionStorage.getItem('selectedPlan');
 if (saved) {
 const parsed = JSON.parse(saved);
 if (parsed && parsed.amount) selectedPlan = { ...selectedPlan, ...parsed };
 }
 } catch(e) {}
 function fmtRs(n) { return 'Rs ' + Number(n || 0).toLocaleString('en-IN'); }
 document.getElementById('spcPlanName').textContent = fmtRs(selectedPlan.amount) + ' Plan';
 document.getElementById('spcInvest').textContent = fmtRs(selectedPlan.amount);
 document.getElementById('spcDaily').textContent = fmtRs(selectedPlan.daily);
 document.getElementById('spcTotal').textContent = fmtRs(selectedPlan.total);
 document.getElementById('spcDays').textContent = (selectedPlan.days || 35) + ' Days';
 document.getElementById('sdPlan').textContent = fmtRs(selectedPlan.amount);
 async function loadPaymentSettings() {
 let settings = null;
 if (window.API_CONFIG.baseURL) {
 try {
 const res = await window.API.get(API_CONFIG.endpoints.getPaymentSettings);
 if (res.success && res.data) {
 settings = res.data.settings || res.data;
 }
 } catch(e) {
 console.warn('⚠️ Payment settings API failed, using fallback');
 }
 }
 if (!settings) {
 try {
 const cached = localStorage.getItem('paymentSettings');
 if (cached) settings = JSON.parse(cached);
 } catch(e) {}
 }
 if (!settings) settings = window.PAYMENT_SETTINGS;
 applyPaymentSettings(settings);
 }
 function applyPaymentSettings(s) {
 if (!s) return;
 const accNum = s.accountNumber || s.number || '';
 const adNumber = document.getElementById('adNumber');
 if (adNumber && accNum) adNumber.textContent = accNum;
 const accName = s.accountName || s.name || '';
 const adName = document.getElementById('adName');
 if (adName && accName) adName.textContent = accName;
 const method = s.method || 'Easypaisa';
 const adMethod = document.getElementById('adMethod');
 if (adMethod) adMethod.textContent = method;
 const qrMethodName = document.getElementById('qrMethodName');
 if (qrMethodName) qrMethodName.textContent = method;
 const stMethodBadge = document.getElementById('stMethodBadge');
 if (stMethodBadge) stMethodBadge.textContent = method;
 loadQRImage(s, accNum);
 }
 function loadQRImage(s, accNum) {
 const img = document.getElementById('qrImage');
 const loading = document.getElementById('qrLoading');
 if (!img) return;
 let qrUrl = '';
 if (s.qrImageUrl && String(s.qrImageUrl).trim()) {
 qrUrl = s.qrImageUrl;
 }
 else if (accNum) {
 qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=400x400&margin=0&data=' + encodeURIComponent(accNum);
 }
 if (!qrUrl) {
 if (loading) loading.style.display = 'none';
 img.style.display = 'block';
 img.src = 'data:image/svg+xml;utf8,' + encodeURIComponent(`
 <svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400">
 <rect width="400" height="400" fill="#fff"/>
 <text x="200" y="200" text-anchor="middle" font-family="Arial" font-size="16" fill="#ef4444">QR Not Available</text>
 </svg>
 `);
 return;
 }
 img.onload = () => {
 if (loading) loading.style.display = 'none';
 img.style.display = 'block';
 };
 img.onerror = () => {
 if (loading) loading.style.display = 'none';
 img.style.display = 'block';
 img.src = 'data:image/svg+xml;utf8,' + encodeURIComponent(`
 <svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400">
 <rect width="400" height="400" fill="#fff"/>
 <text x="200" y="200" text-anchor="middle" font-family="Arial" font-size="16" fill="#ef4444">QR Load Failed</text>
 </svg>
 `);
 };
 img.src = qrUrl;
 }
 function downloadQR() {
 const img = document.getElementById('qrImage');
 if (!img || !img.src || img.style.display === 'none') {
 showToast('QR not loaded yet', 'error', 'Error');
 return;
 }
 const a = document.createElement('a');
 a.href = img.src;
 a.download = 'predxprofit-qr.png';
 a.target = '_blank';
 document.body.appendChild(a);
 a.click();
 document.body.removeChild(a);
 showToast('QR downloading...', 'success', 'Download');
 }
 function copyAccountNumber() {
 const num = document.getElementById('adNumber').textContent || '';
 copyText(num, 'Account number copied!');
 }
 function copyText(text, msg) {
 if (navigator.clipboard && window.isSecureContext) {
 navigator.clipboard.writeText(text).then(() => showToast(msg || 'Copied!', 'success', 'Copied')).catch(() => legacyCopy(text, msg));
 } else {
 legacyCopy(text, msg);
 }
 }
 function legacyCopy(text, msg) {
 const ta = document.createElement('textarea');
 ta.value = text;
 ta.style.position = 'fixed';
 ta.style.opacity = '0';
 document.body.appendChild(ta);
 ta.select();
 try { document.execCommand('copy'); showToast(msg || 'Copied!', 'success', 'Copied'); } catch(e) {}
 document.body.removeChild(ta);
 }
 let uploadedFile = null;
 let uploadedFileDataUrl = null;
 function handleFile(input) {
 const file = input.files && input.files[0];
 if (!file) return;
 if (file.size > 5 * 1024 * 1024) {
 showToast('File too large (max 5MB)', 'error', 'Too Large');
 input.value = '';
 return;
 }
 uploadedFile = file;
 const box = document.getElementById('uploadBox');
 const preview = document.getElementById('uploadPreview');
 const previewImg = document.getElementById('previewImg');
 const filename = document.getElementById('uploadFilename');
 const reader = new FileReader();
 reader.onload = function(e) {
 uploadedFileDataUrl = e.target.result;
 previewImg.src = e.target.result;
 filename.textContent = '✓ ' + file.name;
 preview.classList.add('show');
 box.classList.add('has-file');
 };
 reader.readAsDataURL(file);
 showToast('Screenshot attached!', 'success', 'Uploaded');
 }
 async function submitPayment() {
 const tid = (document.getElementById('tidInput').value || '').trim();
 if (!tid) {
 shakeInput(document.getElementById('tidInput'));
 showToast('Please enter Transaction ID', 'error', 'Missing');
 return;
 }
 if (tid.length < 6) {
 shakeInput(document.getElementById('tidInput'));
 showToast('Transaction ID too short', 'error', 'Invalid');
 return;
 }
 if (!uploadedFile) {
 shakeInput(document.getElementById('uploadBox'));
 showToast('Please upload screenshot', 'error', 'Missing');
 return;
 }
 const depositData = {
 uid: getCurrentUid(),
 planAmount: selectedPlan.amount,
 dailyProfit: selectedPlan.daily,
 totalProfit: selectedPlan.total,
 days: selectedPlan.days || 35,
 tid: tid,
 screenshot: uploadedFileDataUrl ? uploadedFileDataUrl.substring(0, 100) + '...' : '', 
 screenshotName: uploadedFile.name,
 method: window.PAYMENT_SETTINGS.method,
 accountNumber: window.PAYMENT_SETTINGS.accountNumber,
 status: 'pending',
 submittedAt: new Date().toISOString()
 };
 try {
 const loggedUser = JSON.parse(localStorage.getItem('loggedUser') || '{}');
 loggedUser.transactions = loggedUser.transactions || [];
 loggedUser.transactions.unshift({
 id: 'DEP' + Date.now(),
 type: 'deposit',
 uid: loggedUser.uid,
 planAmount: selectedPlan.amount,
 tid: tid,
 method: window.PAYMENT_SETTINGS.method,
 accountNumber: window.PAYMENT_SETTINGS.accountNumber,
 status: 'pending',
 submittedAt: new Date().toISOString()
 });
 localStorage.setItem('loggedUser', JSON.stringify(loggedUser));
 } catch(e) {}
 if (window.API_CONFIG.baseURL) {
 try {
 await window.API.post(API_CONFIG.endpoints.submitDepositProof, depositData);
 } catch(e) {
 console.warn('⚠️ Deposit submit API failed');
 }
 }
 document.getElementById('sdTid').textContent = tid.length > 14 ? tid.slice(0, 14) + '...' : tid;
 document.getElementById('successOverlay').classList.add('active');
 showToast('Payment submitted for verification!', 'success', 'Submitted');
 setTimeout(() => {
 goToDashboard();
 }, 2500);
 }
 function getCurrentUid() {
 try {
 const u = JSON.parse(localStorage.getItem('loggedUser') || '{}');
 return u.uid || 'DEMO001';
 } catch(e) { return 'DEMO001'; }
 }
 function shakeInput(el) {
 if (!el) return;
 el.style.transition = 'transform .1s ease';
 el.style.transform = 'translateX(-8px)';
 setTimeout(() => { el.style.transform = 'translateX(8px)'; }, 100);
 setTimeout(() => { el.style.transform = 'translateX(-6px)'; }, 200);
 setTimeout(() => { el.style.transform = 'translateX(6px)'; }, 300);
 setTimeout(() => { el.style.transform = 'translateX(-4px)'; }, 400);
 setTimeout(() => { el.style.transform = 'translateX(0)'; }, 500);
 }
 function goToDashboard() {
 try { sessionStorage.removeItem('selectedPlan'); } catch(e) {}
 window.location.href = 'dashboard.html';
 }
 function goTo(page) { setTimeout(() => { window.location.href = page; }, 100); }
 function goToWithNotif(page, title, message){
 showToast(message || ('Opening ' + title + '...'), 'info', title);
 setTimeout(() => {
 window.location.href = page;
 }, 650);
 }
 function openCustomerService(){
 showToast('Connecting to support team...', 'info', 'Customer Service');
 setTimeout(() => {
 window.location.href = 'customer.html';
 }, 650);
 }
 loadPaymentSettings();
 document.addEventListener('gesturestart', e => e.preventDefault());
 document.addEventListener('gesturechange', e => e.preventDefault());
 document.addEventListener('gestureend', e => e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e => {
 const now = Date.now();
 if (now - lastTouch <= 300) e.preventDefault();
 lastTouch = now;
 }, { passive: false });
 document.addEventListener('wheel', e => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });
 document.addEventListener('keydown', e => {
 if ((e.ctrlKey || e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault();
 });