window.APP_MODE = {
 DEMO_MODE: true,
 DEMO_USER: {
 uid: 'DEMO001',
 name: 'Demo User',
 email: 'demo@predxprofit.pk',
 whatsapp: '03001234567',
 wallet: 0,
 withdrawableWallet: 0,
 activePlans: 0,
 referralCode: 'PREDX001',
 todayEarning: 0,
 teamSize: 0,
 teamList: [],
 referralBalance: 0,
 weeklySalary: 0,
 adsWatched: 0,
 joinDate: new Date('2026-01-15').toISOString(),
 transactions: [],
 deposits: [],
 withdraws: [],
 giftClaims: [],
 chatHistory: []
 }
 };
 window.API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 register: "/auth/register",
 login: "/auth/login",
 logout: "/auth/logout",
 getUser: "/user/me",
 updateUser: "/user/update",
 changePassword: "/user/change-password",
 getNextUID: "/meta/next-uid",
 getPlans: "/plans",
 createDeposit: "/deposits",
 getDeposits: "/deposits/me",
 createWithdraw: "/withdraws",
 getWithdraws: "/withdraws/me",
 watchAd: "/ads/watch",
 getAdsHistory: "/ads/history",
 getTeam: "/team/me",
 getTransactions: "/transactions/me",
 redeemGift: "/gifts/redeem",
 getChats: "/chats/me",
 sendMessage: "/chats/send",
 getMessages: "/chats/:id/messages",
 getLatestUpdate: "/updates/latest",
 getPaymentSettings: "/settings/payment",
 submitDepositProof: "/deposits/submit"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const loggedUser = localStorage.getItem('loggedUser');
 if (loggedUser) {
 try {
 const u = JSON.parse(loggedUser);
 if (u.uid) h["X-User-UID"] = u.uid;
 } catch(e) {}
 }
 return h;
 }
 };
 window.API = {
 async call(endpoint, method = "GET", body = null) {
 if (!API_CONFIG.baseURL) return { success: false, error: "API baseURL not configured" };
 const url = API_CONFIG.baseURL + endpoint;
 const options = { method, headers: API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) return { success: false, error: data.message || data.error || "Request failed", data };
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); },
 put(ep, body) { return this.call(ep, "PUT", body); },
 del(ep) { return this.call(ep, "DELETE"); }
 };
function showToast(msg, type = 'success', title = null) {
 const holder = document.getElementById('notifHolder');
 if (!holder) return;
 if (type === 'success') {
 const errKeywords = ['error','invalid','failed','not found','wrong','incorrect','already','required','enter ','please','too short','too long','try again','doesn\'t','cannot','can not','not registered','not match'];
 const lower = String(msg).toLowerCase();
 if (errKeywords.some(k => lower.includes(k))) type = 'error';
 }
 const icons = {
 success: '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
 error: '<svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
 info: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
 };
 const titles = { success: title || 'Success', error: title || 'Error', info: title || 'Info' };
 const notif = document.createElement('div');
 notif.className = 'premium-notif ' + type;
 notif.innerHTML = `
 <div class="premium-notif-icon">${icons[type]}</div>
 <div class="premium-notif-text">
 <div class="premium-notif-title">${titles[type]}</div>
 <div class="premium-notif-msg">${msg}</div>
 </div>
 <button class="premium-notif-close" onclick="this.parentElement.classList.remove('show');setTimeout(()=>this.parentElement.remove(),500);">
 <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
 </button>
 `;
 holder.appendChild(notif);
 requestAnimationFrame(() => notif.classList.add('show'));
 setTimeout(() => {
 if (notif.parentElement) {
 notif.classList.remove('show');
 setTimeout(() => notif.remove(), 500);
 }
 }, 3500);
 }
 const DEMO_WITHDRAWS = [
 {
 method: 'Easypaisa', amount: 900, tid: '1009025',
 date: '01/10/2026', time: '8:07:51 am',
 status: 'approved', accountName: 'Parveen Bibi', accountNumber: '03461885739',
 approvedDate: '01/10/2026, 3:45:20 pm', rejectReason: ''
 },
 {
 method: 'Easypaisa', amount: 900, tid: '1008850',
 date: '30/09/2026', time: '8:53:44 pm',
 status: 'approved', accountName: 'Parveen Bibi', accountNumber: '03461885739',
 approvedDate: '01/10/2026, 10:12:05 am', rejectReason: ''
 },
 {
 method: 'JazzCash', amount: 2500, tid: '1004998',
 date: '24/09/2026', time: '11:22:10 am',
 status: 'pending', accountName: 'Ahmed Khan', accountNumber: '03001234567',
 approvedDate: '', rejectReason: ''
 },
 {
 method: 'Easypaisa', amount: 1800, tid: '1003210',
 date: '20/09/2026', time: '5:14:08 pm',
 status: 'rejected', accountName: 'Parveen Bibi', accountNumber: '03461885739',
 approvedDate: '',
 rejectReason: 'Aap ke account number aur naam mein mismatch hai. Sahi details ke saath dobara request karein.'
 }
 ];
 let WITHDRAWS = [];
 let currentFilter = 'all';
 let user = null;
 function loadUserData(){
 const loggedUser = localStorage.getItem('loggedUser');
 if (window.APP_MODE.DEMO_MODE) {
 if (loggedUser) {
 try { user = JSON.parse(loggedUser); } catch(e){}
 }
 if (!user || !user.uid) {
 user = JSON.parse(JSON.stringify(window.APP_MODE.DEMO_USER));
 localStorage.setItem('loggedUser', JSON.stringify(user));
 }
 } else {
 if (!loggedUser) {
 window.location.replace('index.html');
 return;
 }
 try { user = JSON.parse(loggedUser); } catch(e){}
 if (!user || !user.uid) {
 window.location.replace('index.html');
 return;
 }
 }
 loadWithdraws();
 }
 function loadWithdraws(){
 if (Array.isArray(user.withdraws) && user.withdraws.length > 0) {
 WITHDRAWS = user.withdraws.map(normalizeWithdraw);
 }
 else if (Array.isArray(user.transactions) && user.transactions.length > 0) {
 const wds = user.transactions.filter(t => t.type === 'withdrawal' || t.type === 'withdraw');
 WITHDRAWS = wds.map(normalizeWithdraw);
 }
 else if (window.APP_MODE.DEMO_MODE) {
 WITHDRAWS = DEMO_WITHDRAWS;
 }
 else {
 WITHDRAWS = [];
 }
 render();
 }
 function normalizeWithdraw(w){
 let dateStr = w.date || '', timeStr = w.time || '';
 if (!dateStr && w.submittedAt) {
 const dt = new Date(w.submittedAt);
 dateStr = String(dt.getDate()).padStart(2,'0') + '/' + String(dt.getMonth()+1).padStart(2,'0') + '/' + dt.getFullYear();
 let h = dt.getHours(); const m = String(dt.getMinutes()).padStart(2,'0'); const s = String(dt.getSeconds()).padStart(2,'0');
 const ampm = h >= 12 ? 'pm' : 'am'; h = h % 12; if (h === 0) h = 12;
 timeStr = `${String(h).padStart(2,'0')}:${m}:${s} ${ampm}`;
 }
 let status = (w.status || 'pending').toLowerCase();
 if (status === 'success' || status === 'completed' || status === 'paid') status = 'approved';
 if (status === 'failed' || status === 'cancelled') status = 'rejected';
 return {
 method: w.method || w.paymentMethod || 'Easypaisa',
 amount: Number(w.amount || w.withdrawAmount || 0),
 tid: w.tid || w.transactionId || w.id || '—',
 date: dateStr || '—',
 time: timeStr || '—',
 status: status,
 accountName: w.accountName || w.name || user.name || 'User',
 accountNumber: w.accountNumber || w.number || '—',
 approvedDate: w.approvedDate || '',
 rejectReason: w.rejectReason || w.reason || ''
 };
 }
 function statusIconSVG(status) {
 if (status === 'approved') return '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>';
 if (status === 'pending') return '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>';
 return '<svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
 }
 function statusIconBig(status) {
 if (status === 'approved') return '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>';
 if (status === 'pending') return '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>';
 return '<svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
 }
 function statusLabel(status) {
 if (status === 'approved') return 'Approved';
 if (status === 'pending') return 'Pending';
 return 'Rejected';
 }
 function statusTitle(status) {
 if (status === 'approved') return 'Withdrawal Approved';
 if (status === 'pending') return 'Withdrawal Pending';
 return 'Withdrawal Rejected';
 }
 function statusSub(status) {
 if (status === 'approved') return 'Paid to your account';
 if (status === 'pending') return 'Under review';
 return 'Request rejected';
 }
 function render() {
 const list = document.getElementById('withdrawList');
 const countEl = document.getElementById('historyCount');
 if (!list) return;
 const filtered = currentFilter === 'all'
 ? WITHDRAWS
 : WITHDRAWS.filter(w => w.status === currentFilter);
 countEl.textContent = filtered.length + ' ITEM' + (filtered.length !== 1 ? 'S' : '');
 if (filtered.length === 0) {
 list.innerHTML = `
 <div class="empty-state">
 <div class="empty-icon">
 <svg viewBox="0 0 24 24">
 <line x1="12" y1="19" x2="12" y2="5"/>
 <polyline points="5 12 12 5 19 12"/>
 </svg>
 </div>
 <div class="empty-title">No Withdrawals Found</div>
 <div class="empty-desc">Your withdrawal history will appear here</div>
 </div>
 `;
 return;
 }
 list.innerHTML = filtered.map((w) => {
 const realIdx = WITHDRAWS.indexOf(w);
 return `
 <div class="wd-card ${w.status}" onclick="openDetail(${realIdx})">
 <div class="wd-top">
 <div class="wd-icon">
 <svg viewBox="0 0 24 24">
 <line x1="12" y1="19" x2="12" y2="5"/>
 <polyline points="5 12 12 5 19 12"/>
 </svg>
 </div>
 <div class="wd-method-block">
 <div class="wd-method">${w.method}</div>
 <div class="wd-datetime">
 <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
 <span>${w.date}, ${w.time}</span>
 </div>
 </div>
 <div class="wd-amount">Rs ${w.amount.toLocaleString('en-IN')}.00</div>
 </div>
 <div class="wd-divider"></div>
 <div class="wd-bottom">
 <div class="wd-tid">
 <svg viewBox="0 0 24 24"><line x1="4" y1="9" x2="20" y2="9"/><line x1="4" y1="15" x2="20" y2="15"/><line x1="10" y1="3" x2="8" y2="21"/><line x1="16" y1="3" x2="14" y2="21"/></svg>
 <span>Transaction ID: <strong>${w.tid}</strong></span>
 </div>
 <div class="wd-status ${w.status}">
 <span class="st-icon">${statusIconSVG(w.status)}</span>
 <span>${statusLabel(w.status)}</span>
 </div>
 </div>
 </div>
 `;
 }).join('');
 }
 function openDetail(idx) {
 const w = WITHDRAWS[idx];
 if (!w) return;
 const dialog = document.getElementById('detailDialog');
 const icon = document.getElementById('ddIcon');
 const title = document.getElementById('ddTitle');
 const sub = document.getElementById('ddSub');
 const body = document.getElementById('ddBody');
 const closeBtn = document.getElementById('ddCloseBtn');
 dialog.className = 'detail-dialog ' + w.status;
 closeBtn.className = 'dd-close-btn ' + w.status;
 icon.innerHTML = statusIconBig(w.status);
 title.textContent = statusTitle(w.status);
 sub.textContent = statusSub(w.status);
 let bodyHTML = `
 <div class="dd-amount-hero ${w.status}">
 <div class="dd-amount-lbl">Withdraw Amount</div>
 <div class="dd-amount-val">Rs ${w.amount.toLocaleString('en-IN')}.00</div>
 </div>
 <div class="dd-row">
 <div class="dd-row-lbl">
 <svg viewBox="0 0 24 24"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
 Method
 </div>
 <div class="dd-row-val green">${w.method}</div>
 </div>
 <div class="dd-row">
 <div class="dd-row-lbl">
 <svg viewBox="0 0 24 24"><line x1="4" y1="9" x2="20" y2="9"/><line x1="4" y1="15" x2="20" y2="15"/><line x1="10" y1="3" x2="8" y2="21"/><line x1="16" y1="3" x2="14" y2="21"/></svg>
 TID
 </div>
 <div class="dd-row-val">${w.tid}</div>
 </div>
 <div class="dd-row">
 <div class="dd-row-lbl">
 <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
 Request Date
 </div>
 <div class="dd-row-val blue">${w.date}</div>
 </div>
 <div class="dd-row">
 <div class="dd-row-lbl">
 <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
 Request Time
 </div>
 <div class="dd-row-val blue">${w.time}</div>
 </div>
 `;
 bodyHTML += `
 <div class="dd-section-lbl">
 <svg viewBox="0 0 24 24"><path d="M3 21h18M5 21V7l7-4 7 4v14M9 21v-6h6v6"/></svg>
 Payment Sent To
 </div>
 <div class="dd-bank-card">
 <div class="dd-bank-row">
 <span class="dd-bank-lbl">Account Name</span>
 <span class="dd-bank-val">${w.accountName}</span>
 </div>
 <div class="dd-bank-row">
 <span class="dd-bank-lbl">Account Number</span>
 <span class="dd-bank-val mono">${w.accountNumber}</span>
 </div>
 <div class="dd-bank-row">
 <span class="dd-bank-lbl">Method</span>
 <span class="dd-bank-val">${w.method}</span>
 </div>
 </div>
 `;
 if (w.status === 'approved') {
 bodyHTML += `
 <div class="dd-approved-note">
 <div class="dd-approved-title">
 <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
 Payment Successful
 </div>
 <div class="dd-approved-text">
 Aap ki payment <strong>Rs ${w.amount.toLocaleString('en-IN')}</strong> aap ke account mein successfully bhej di gayi hai.
 ${w.approvedDate ? '<br><br><strong>Approved on:</strong> ' + w.approvedDate : ''}
 </div>
 </div>
 `;
 } else if (w.status === 'pending') {
 bodyHTML += `
 <div class="dd-pending-note">
 <div class="dd-pending-title">
 <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
 Under Review
 </div>
 <div class="dd-pending-text">
 Aap ki withdrawal request abhi review mein hai. Aam taur par <strong>24 ghante</strong> ke andar process ho jati hai. Thoda intezaar karein.
 </div>
 </div>
 `;
 } else {
 bodyHTML += `
 <div class="dd-reason-box">
 <div class="dd-reason-title">
 <svg viewBox="0 0 24 24"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
 Rejection Reason
 </div>
 <div class="dd-reason-text">${w.rejectReason || 'Koi wajah nahi di gayi.'}</div>
 </div>
 `;
 }
 body.innerHTML = bodyHTML;
 document.getElementById('detailOverlay').classList.add('active');
 }
 function closeDetail() {
 document.getElementById('detailOverlay').classList.remove('active');
 }
 function closeDetailOutside(e) {
 if (e.target.id === 'detailOverlay') closeDetail();
 }
 function setFilter(filter, el) {
 currentFilter = filter;
 document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
 if (el) el.classList.add('active');
 render();
 }
 function goTo(page) { setTimeout(() => { window.location.href = page; }, 100); }
 function goToWithNotif(page, title, message){
 showToast(message || ('Opening ' + title + '...'), 'info', title);
 setTimeout(() => {
 window.location.href = page;
 }, 650);
 }
 function openCustomerService(){
 showToast('Connecting to support team...', 'info', 'Customer Service');
 setTimeout(() => {
 window.location.href = 'customer.html';
 }, 650);
 }
 loadUserData();
 document.addEventListener('gesturestart', e => e.preventDefault());
 document.addEventListener('gesturechange', e => e.preventDefault());
 document.addEventListener('gestureend', e => e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e => {
 const now = Date.now();
 if (now - lastTouch <= 300) e.preventDefault();
 lastTouch = now;
 }, { passive: false });
 document.addEventListener('wheel', e => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });
 document.addEventListener('keydown', e => {
 if ((e.ctrlKey || e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault();
 });