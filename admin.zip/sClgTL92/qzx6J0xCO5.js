window.APP_MODE = {
 DEMO_MODE: true
 };
 window.API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 register: "/auth/register",
 login: "/auth/login",
 getUser: "/user/me",
 updateUser: "/user/update",
 getNextUID: "/meta/next-uid"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 return h;
 }
 };
 window.API = {
 async call(endpoint, method = "GET", body = null) {
 if (!API_CONFIG.baseURL) return { success: false, error: "API not configured" };
 const url = API_CONFIG.baseURL + endpoint;
 const options = { method, headers: API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) return { success: false, error: data.message || data.error || "Request failed", data };
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); },
 put(ep, body) { return this.call(ep, "PUT", body); },
 del(ep) { return this.call(ep, "DELETE"); }
 };
 console.log('🔌 APP MODE:', window.APP_MODE.DEMO_MODE ? 'DEMO (Local)' : 'LIVE (API)');
 console.log('🔌 API Base URL:', window.API_CONFIG.baseURL || '(not set)');
function showToast(msg, type = 'success', title = null) {
 const holder = document.getElementById('notifHolder');
 if (!holder) return;
 if (type === 'success') {
 const errKeywords = ['error','invalid','failed','not found','wrong','incorrect','already','required','enter ','please','too short','too long','try again','doesn\'t','cannot','can not','not registered','not match','exists','locked'];
 const lower = String(msg).toLowerCase();
 if (errKeywords.some(k => lower.includes(k))) type = 'error';
 }
 const icons = {
 success: '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
 error: '<svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
 info: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
 };
 const titles = {
 success: title || 'Success',
 error: title || 'Error',
 info: title || 'Info'
 };
 const notif = document.createElement('div');
 notif.className = 'premium-notif ' + type;
 notif.innerHTML = `
 <div class="premium-notif-icon">${icons[type]}</div>
 <div class="premium-notif-text">
 <div class="premium-notif-title">${titles[type]}</div>
 <div class="premium-notif-msg">${msg}</div>
 </div>
 <button class="premium-notif-close" onclick="this.parentElement.classList.remove('show');setTimeout(()=>this.parentElement.remove(),500);">
 <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
 </button>
 `;
 holder.appendChild(notif);
 requestAnimationFrame(() => notif.classList.add('show'));
 setTimeout(() => {
 if (notif.parentElement) {
 notif.classList.remove('show');
 setTimeout(() => notif.remove(), 500);
 }
 }, 3500);
 }
 function showLoading(){ document.getElementById('loadingOverlay').classList.add('active'); }
 function hideLoading(){ document.getElementById('loadingOverlay').classList.remove('active'); }
 const CHANNEL_LINKS = {
 youtube: 'https://youtu.be/uTlYFBYPY1Q?si=ndvuaT9R8TOEHiyD',
 telegram: 'https://t.me/storeh4k3r_signals',
 whatsapp: 'https://whatsapp.com/channel/0029VamgXHd7z4kecde53Q1i'
 };
 function openChannel(name){
 const url = CHANNEL_LINKS[name];
 if(!url){ showToast('Link coming soon', 'info', 'Coming Soon'); return; }
 window.open(url, '_blank');
 showToast('Opening ' + name.charAt(0).toUpperCase() + name.slice(1) + '...', 'info', 'Opening');
 }
 function switchTab(tab){
 const tabSwitch = document.getElementById('tabSwitch');
 const loginPanel = document.getElementById('panel-login');
 const registerPanel = document.getElementById('panel-register');
 document.querySelectorAll('.tab-btn').forEach(btn => {
 btn.classList.toggle('active', btn.dataset.tab === tab);
 });
 if(tab === 'register'){
 tabSwitch.classList.add('register-mode');
 loginPanel.classList.remove('active');
 setTimeout(() => registerPanel.classList.add('active'), 100);
 } else {
 tabSwitch.classList.remove('register-mode');
 registerPanel.classList.remove('active');
 setTimeout(() => loginPanel.classList.add('active'), 100);
 }
 }
 function togglePass(inputId, btn){
 const input = document.getElementById(inputId);
 if(!input) return;
 if(input.type === 'password'){
 input.type = 'text';
 btn.innerHTML = '<svg viewBox="0 0 24 24"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>';
 } else {
 input.type = 'password';
 btn.innerHTML = '<svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
 }
 }
 function shakeInput(id){
 const el = document.getElementById(id);
 if(!el) return;
 const wrap = el.closest('.input-wrap') || el;
 wrap.classList.remove('shake');
 void wrap.offsetWidth;
 wrap.classList.add('shake');
 el.focus();
 setTimeout(() => wrap.classList.remove('shake'), 600);
 }
 function generateUID(){
 const users = JSON.parse(localStorage.getItem('allUsers') || '[]');
 let num = 1000 + users.length + 1;
 let uid = 'PX' + num;
 while (users.some(u => u.uid === uid)) {
 num++;
 uid = 'PX' + num;
 }
 return uid;
 }
 function getAllUsers(){
 try { return JSON.parse(localStorage.getItem('allUsers') || '[]'); }
 catch(e) { return []; }
 }
 function saveAllUsers(users){
 try { localStorage.setItem('allUsers', JSON.stringify(users)); }
 catch(e) {}
 }
 function buildNewUser({ name, whatsapp, email, password, referralCode }){
 return {
 uid: generateUID(),
 name: name,
 email: email,
 whatsapp: whatsapp,
 password: password,
 referralCode: 'PX' + Math.floor(1000 + Math.random() * 9000),
 referredBy: referralCode || '',
 wallet: 0,
 withdrawableWallet: 0,
 activePlans: 0,
 todayEarning: 0,
 teamSize: 0,
 teamList: [],
 referralBalance: 0,
 weeklySalary: 0,
 adsWatched: 0,
 joinDate: new Date().toISOString(),
 transactions: [],
 deposits: [],
 withdraws: [],
 giftClaims: [],
 adsHistory: [],
 chatHistory: [],
 settings: {
 notifications: true,
 darkMode: false,
 sound: true,
 autoAds: false,
 biometric: false
 }
 };
 }
 function processReferral(referrerCode, newUser){
 if (!referrerCode) return;
 const users = getAllUsers();
 const referrer = users.find(u => u.referralCode === referrerCode);
 if (!referrer) return;
 referrer.teamList = referrer.teamList || [];
 referrer.teamList.push({
 uid: newUser.uid,
 name: newUser.name,
 level: 1,
 plan: 0,
 bonus: 0,
 online: true,
 joined: 'just now'
 });
 referrer.teamSize = referrer.teamList.length;
 saveAllUsers(users);
 const logged = localStorage.getItem('loggedUser');
 if (logged) {
 try {
 const lu = JSON.parse(logged);
 if (lu.uid === referrer.uid) {
 localStorage.setItem('loggedUser', JSON.stringify(referrer));
 }
 } catch(e) {}
 }
 }
 const LOCKED_ACCOUNTS = [
 {
 email: 'predxwin66@gmail.com',
 password: '',
 reason: 'Suspicious Activity'
 }
 ];
 const UNLOCKED_ACCOUNTS = [
 {
 email: 'predxwin666@gmail.com',
 password: ''
 }
 ];
 function showLockDialog(account, reason) {
 const el = document.getElementById('lockAccount');
 if (el) el.textContent = account;
 const reasonEl = document.getElementById('lockReason');
 if (reasonEl && reason) reasonEl.textContent = reason;
 document.getElementById('lockOverlay').classList.add('active');
 const loginBtn = document.getElementById('loginBtn');
 if (loginBtn) loginBtn.disabled = true;
 showToast('Account Locked!', 'error', 'Access Denied');
 }
 function closeLockDialog() {
 document.getElementById('lockOverlay').classList.remove('active');
 const loginBtn = document.getElementById('loginBtn');
 if (loginBtn) loginBtn.disabled = false;
 const passInput = document.getElementById('loginPass');
 if (passInput) passInput.value = '';
 }
 function contactAdminFromLock() {
 const account = document.getElementById('lockAccount').textContent;
 const msg = `Hello Admin, my account (${account}) has been locked. Please help me unlock it.`;
 const url = `https://wa.me/923157656097?text=${encodeURIComponent(msg)}`;
 try { window.open(url, '_blank'); } catch(e){}
 showToast('Opening WhatsApp...', 'info', 'Contact Admin');
 }
 function showUnlockDialog(account) {
 const el = document.getElementById('unlockAccount');
 if (el) el.textContent = account;
 document.getElementById('unlockOverlay').classList.add('active');
 const loginBtn = document.getElementById('loginBtn');
 if (loginBtn) loginBtn.disabled = true;
 showToast('Account Unlocked!', 'success', 'Welcome Back');
 }
 function closeUnlockDialog() {
 document.getElementById('unlockOverlay').classList.remove('active');
 const loginBtn = document.getElementById('loginBtn');
 if (loginBtn) loginBtn.disabled = false;
 }
 function proceedToLoginFromUnlock() {
 closeUnlockDialog();
 const idInput = document.getElementById('loginId');
 const passInput = document.getElementById('loginPass');
 if (idInput) idInput.value = '';
 if (passInput) passInput.value = '';
 showToast('Please login again', 'info', 'Ready');
 }
 async function submitRegister(){
 const name = (document.getElementById('regName').value || '').trim();
 const whatsapp = (document.getElementById('regWhatsapp').value || '').trim();
 const gmail = (document.getElementById('regGmail').value || '').trim().toLowerCase();
 const pass = (document.getElementById('regPass').value || '').trim();
 const referral = (document.getElementById('regReferral').value || '').trim().toUpperCase();
 if(!name){ shakeInput('regName'); showToast('Enter your name', 'error', 'Missing'); return; }
 if(name.length < 3){ shakeInput('regName'); showToast('Name too short', 'error', 'Invalid'); return; }
 if(!whatsapp){ shakeInput('regWhatsapp'); showToast('Enter WhatsApp number', 'error', 'Missing'); return; }
 if(whatsapp.replace(/\D/g, '').length < 10){ shakeInput('regWhatsapp'); showToast('Invalid WhatsApp number', 'error', 'Invalid'); return; }
 if(!gmail){ shakeInput('regGmail'); showToast('Enter Gmail address', 'error', 'Missing'); return; }
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(gmail)){ shakeInput('regGmail'); showToast('Invalid Gmail address', 'error', 'Invalid'); return; }
 if(!pass){ shakeInput('regPass'); showToast('Enter password', 'error', 'Missing'); return; }
 if(pass.length < 6){ shakeInput('regPass'); showToast('Password min 6 characters', 'error', 'Too Short'); return; }
 showLoading();
 const btn = document.getElementById('registerBtn');
 if(btn) btn.disabled = true;
 if (window.API_CONFIG.baseURL) {
 try {
 const result = await window.API.post(API_CONFIG.endpoints.register, {
 name, whatsapp, email: gmail, password: pass, referralCode: referral
 });
 if (result.success) {
 const user = result.data.user || result.data;
 localStorage.setItem('loggedUser', JSON.stringify(user));
 hideLoading();
 showToast('Account created! UID: ' + user.uid, 'success', 'Welcome');
 setTimeout(() => { window.location.href = 'dashboard.html'; }, 1300);
 return;
 }
 hideLoading();
 if(btn) btn.disabled = false;
 showToast(result.error || 'Registration failed', 'error', 'Error');
 return;
 } catch(err){
 console.error('❌ Register error:', err);
 hideLoading();
 if(btn) btn.disabled = false;
 showToast(err.message || 'Registration failed', 'error', 'Error');
 return;
 }
 }
 setTimeout(() => {
 const users = getAllUsers();
 if (users.some(u => u.email === gmail)) {
 hideLoading();
 if(btn) btn.disabled = false;
 shakeInput('regGmail');
 showToast('Email already registered', 'error', 'Duplicate');
 return;
 }
 if (users.some(u => (u.whatsapp || '').replace(/\D/g, '') === whatsapp.replace(/\D/g, ''))) {
 hideLoading();
 if(btn) btn.disabled = false;
 shakeInput('regWhatsapp');
 showToast('WhatsApp already registered', 'error', 'Duplicate');
 return;
 }
 const newUser = buildNewUser({ name, whatsapp, email: gmail, password: pass, referralCode: referral });
 users.push(newUser);
 saveAllUsers(users);
 if (referral) processReferral(referral, newUser);
 localStorage.setItem('loggedUser', JSON.stringify(newUser));
 hideLoading();
 showToast('Account created! UID: ' + newUser.uid, 'success', 'Welcome');
 setTimeout(() => { window.location.href = 'dashboard.html'; }, 1300);
 }, 700);
 }
 async function submitLogin(){
 const id = (document.getElementById('loginId').value || '').trim().toLowerCase();
 const pass = (document.getElementById('loginPass').value || '').trim();
 if(!id){ shakeInput('loginId'); showToast('Enter email or WhatsApp', 'error', 'Missing'); return; }
 if(!pass){ shakeInput('loginPass'); showToast('Enter password', 'error', 'Missing'); return; }
 const unlockMatch = UNLOCKED_ACCOUNTS.find(a =>
 a.email.toLowerCase() === id
 );
 if (unlockMatch) {
 if (unlockMatch.password === pass) {
 showUnlockDialog(unlockMatch.email);
 return;
 } else {
 }
 }
 const lockedMatch = LOCKED_ACCOUNTS.find(a =>
 a.email.toLowerCase() === id
 );
 if (lockedMatch) {
 showLockDialog(lockedMatch.email, lockedMatch.reason);
 return;
 }
 showLoading();
 const btn = document.getElementById('loginBtn');
 if(btn) btn.disabled = true;
 if (window.API_CONFIG.baseURL) {
 try {
 const result = await window.API.post(API_CONFIG.endpoints.login, { loginId: id, password: pass });
 if (result.success) {
 const user = result.data.user || result.data;
 localStorage.setItem('loggedUser', JSON.stringify(user));
 hideLoading();
 showToast('Welcome back, ' + user.name + '!', 'success', 'Login');
 setTimeout(() => { window.location.href = 'dashboard.html'; }, 900);
 return;
 }
 hideLoading();
 if(btn) btn.disabled = false;
 showToast(result.error || 'Login failed', 'error', 'Error');
 return;
 } catch(err){
 console.error('❌ Login error:', err);
 hideLoading();
 if(btn) btn.disabled = false;
 showToast(err.message || 'Login failed', 'error', 'Error');
 return;
 }
 }
 setTimeout(() => {
 const users = getAllUsers();
 const idDigits = id.replace(/\D/g, '');
 const matched = users.find(u =>
 (u.email || '').toLowerCase() === id ||
 ((u.whatsapp || '').replace(/\D/g, '') === idDigits && idDigits.length >= 10) ||
 (u.uid || '').toLowerCase() === id
 );
 if (!matched) {
 hideLoading();
 if(btn) btn.disabled = false;
 shakeInput('loginId');
 showToast('Account not found', 'error', 'Not Found');
 return;
 }
 if ((matched.password || '') !== pass) {
 hideLoading();
 if(btn) btn.disabled = false;
 shakeInput('loginPass');
 showToast('Wrong password', 'error', 'Incorrect');
 return;
 }
 localStorage.setItem('loggedUser', JSON.stringify(matched));
 hideLoading();
 showToast('Welcome back, ' + matched.name + '!', 'success', 'Login');
 setTimeout(() => { window.location.href = 'dashboard.html'; }, 900);
 }, 600);
 }
 const WHATSAPP_CHANNEL_URL = "https://whatsapp.com/channel/0029VamgXHd7z4kecde53Q1i";
 const ADMIN_WHATSAPP_NUMBER = "923157656097";
 function openConnectDialog(){
 document.getElementById('connectOverlay').classList.add('active');
 }
 function closeConnectDialog(){
 document.getElementById('connectOverlay').classList.remove('active');
 try { localStorage.setItem('connectDialogSeen', 'true'); } catch(e) {}
 }
 function joinWhatsAppChannel(){
 try { window.open(WHATSAPP_CHANNEL_URL, '_blank'); } catch(e){}
 showToast('Opening WhatsApp Channel...', 'success', 'Join Channel');
 }
 function openAdminContactDialog(){
 document.getElementById('connectOverlay').classList.remove('active');
 setTimeout(() => {
 document.getElementById('adminMsgOverlay').classList.add('active');
 document.getElementById('adminMsgInput').focus();
 }, 300);
 }
 function closeAdminMsgDialog(){
 document.getElementById('adminMsgOverlay').classList.remove('active');
 setTimeout(() => {
 document.getElementById('connectOverlay').classList.add('active');
 }, 300);
 }
 function openCustomerSupport(){
 closeConnectDialog();
 showToast('Opening Customer Support...', 'info', 'Customer Support');
 setTimeout(() => {
 window.location.href = 'customer.html';
 }, 700);
 }
 function insertQuickMsg(text){
 const ta = document.getElementById('adminMsgInput');
 ta.value = text;
 updateCharCount();
 ta.focus();
 }
 function updateCharCount(){
 const ta = document.getElementById('adminMsgInput');
 const cc = document.getElementById('amCharCount');
 if(ta && cc) cc.textContent = ta.value.length;
 }
 function sendToAdminWhatsApp(){
 const msg = (document.getElementById('adminMsgInput').value || '').trim();
 if(!msg){
 showToast('Please type a message first!', 'error', 'Empty Message');
 return;
 }
 const url = `https://wa.me/${ADMIN_WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`;
 try { window.open(url, '_blank'); } catch(e){}
 document.getElementById('adminMsgOverlay').classList.remove('active');
 showToast('Opening WhatsApp...', 'success', 'Opening Chat');
 }
 (function initCharCount(){
 const ta = document.getElementById('adminMsgInput');
 if(ta) ta.addEventListener('input', updateCharCount);
 })();
 (function autoShowConnect(){
 try {
 const logged = localStorage.getItem('loggedUser');
 if (logged) {
 const u = JSON.parse(logged);
 if (u && u.uid) return;
 }
 } catch(e) {}
 setTimeout(() => {
 openConnectDialog();
 }, 900);
 })();
 try {
 const user = localStorage.getItem('loggedUser');
 if(user){
 const u = JSON.parse(user);
 if(u && u.uid){
 window.location.replace('dashboard.html');
 }
 }
 } catch(e) {}
 const params = new URLSearchParams(window.location.search);
 if(params.get('tab') === 'register'){
 setTimeout(() => switchTab('register'), 300);
 }
 document.addEventListener('gesturestart', e => e.preventDefault());
 document.addEventListener('gesturechange', e => e.preventDefault());
 document.addEventListener('gestureend', e => e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e => {
 const now = Date.now();
 if (now - lastTouch <= 300) e.preventDefault();
 lastTouch = now;
 }, { passive: false });
 document.addEventListener('wheel', e => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });
 document.addEventListener('keydown', e => {
 if ((e.ctrlKey || e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault();
 });