window.APP_MODE = {
 DEMO_MODE: true,
 DEMO_USER: {
 uid: 'DEMO001',
 name: 'Demo User',
 email: 'demo@predxprofit.pk',
 whatsapp: '03001234567',
 wallet: 0,
 withdrawableWallet: 0,
 activePlans: 0,
 referralCode: 'PREDX001',
 todayEarning: 0,
 teamSize: 0,
 teamList: [],
 referralBalance: 0,
 weeklySalary: 0,
 adsWatched: 0,
 joinDate: new Date('2026-01-15').toISOString(),
 transactions: [],
 deposits: [],
 withdraws: [],
 giftClaims: [],
 adsHistory: [],
 chatHistory: []
 }
 };
 window.API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 register: "/auth/register",
 login: "/auth/login",
 logout: "/auth/logout",
 getUser: "/user/me",
 updateUser: "/user/update",
 changePassword: "/user/change-password",
 getNextUID: "/meta/next-uid",
 getPlans: "/plans",
 createDeposit: "/deposits",
 getDeposits: "/deposits/me",
 createWithdraw: "/withdraws",
 getWithdraws: "/withdraws/me",
 watchAd: "/ads/watch",
 getAdsHistory: "/ads/history",
 getTeam: "/team/me",
 getTransactions: "/transactions/me",
 redeemGift: "/gifts/redeem",
 getChats: "/chats/me",
 sendMessage: "/chats/send",
 getMessages: "/chats/:id/messages",
 getLatestUpdate: "/updates/latest",
 getPaymentSettings: "/settings/payment",
 submitDepositProof: "/deposits/submit"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const loggedUser = localStorage.getItem('loggedUser');
 if (loggedUser) {
 try {
 const u = JSON.parse(loggedUser);
 if (u.uid) h["X-User-UID"] = u.uid;
 } catch(e) {}
 }
 return h;
 }
 };
 window.API = {
 async call(endpoint, method = "GET", body = null) {
 if (!API_CONFIG.baseURL) return { success: false, error: "API baseURL not configured" };
 const url = API_CONFIG.baseURL + endpoint;
 const options = { method, headers: API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) return { success: false, error: data.message || data.error || "Request failed", data };
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); },
 put(ep, body) { return this.call(ep, "PUT", body); },
 del(ep) { return this.call(ep, "DELETE"); }
 };
function showToast(msg, type = 'success', title = null) {
 const holder = document.getElementById('notifHolder');
 if (!holder) return;
 if (type === 'success') {
 const errKeywords = ['error','invalid','failed','not found','wrong','incorrect','already','required','enter ','please','too short','too long','try again','doesn\'t','cannot','can not','not registered','not match'];
 const lower = String(msg).toLowerCase();
 if (errKeywords.some(k => lower.includes(k))) type = 'error';
 }
 const icons = {
 success: '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
 error: '<svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
 info: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
 };
 const titles = { success: title || 'Success', error: title || 'Error', info: title || 'Info' };
 const notif = document.createElement('div');
 notif.className = 'premium-notif ' + type;
 notif.innerHTML = `
 <div class="premium-notif-icon">${icons[type]}</div>
 <div class="premium-notif-text">
 <div class="premium-notif-title">${titles[type]}</div>
 <div class="premium-notif-msg">${msg}</div>
 </div>
 <button class="premium-notif-close" onclick="this.parentElement.classList.remove('show');setTimeout(()=>this.parentElement.remove(),500);">
 <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
 </button>
 `;
 holder.appendChild(notif);
 requestAnimationFrame(() => notif.classList.add('show'));
 setTimeout(() => {
 if (notif.parentElement) {
 notif.classList.remove('show');
 setTimeout(() => notif.remove(), 500);
 }
 }, 3500);
 }
 const DEMO_ADS = [
 { plan: 600, reward: 120, date: '14 Oct', time: '10:24 AM', today: true },
 { plan: 1200, reward: 240, date: '14 Oct', time: '09:11 AM', today: true },
 { plan: 600, reward: 120, date: '13 Oct', time: '08:45 PM', today: false },
 { plan: 2400, reward: 480, date: '12 Oct', time: '06:30 PM', today: false },
 { plan: 1200, reward: 240, date: '11 Oct', time: '07:15 AM', today: false },
 { plan: 600, reward: 120, date: '10 Oct', time: '04:20 PM', today: false },
 { plan: 3600, reward: 720, date: '08 Oct', time: '12:05 PM', today: false },
 { plan: 1200, reward: 240, date: '05 Oct', time: '09:40 AM', today: false },
 { plan: 600, reward: 120, date: '02 Oct', time: '07:30 PM', today: false }
 ];
 const LEVELS = ['lvl1', 'lvl2', 'lvl3'];
 let ADS_HISTORY = [];
 let user = null;
 function loadUserData(){
 const loggedUser = localStorage.getItem('loggedUser');
 if (window.APP_MODE.DEMO_MODE) {
 if (loggedUser) {
 try { user = JSON.parse(loggedUser); } catch(e){}
 }
 if (!user || !user.uid) {
 user = JSON.parse(JSON.stringify(window.APP_MODE.DEMO_USER));
 localStorage.setItem('loggedUser', JSON.stringify(user));
 }
 } else {
 if (!loggedUser) {
 window.location.replace('index.html');
 return;
 }
 try { user = JSON.parse(loggedUser); } catch(e){}
 if (!user || !user.uid) {
 window.location.replace('index.html');
 return;
 }
 }
 loadAdsHistory();
 }
 function loadAdsHistory(){
 let items = [];
 if (Array.isArray(user.adsHistory) && user.adsHistory.length > 0) {
 items = user.adsHistory.map(normalizeAd);
 }
 else if (Array.isArray(user.transactions) && user.transactions.length > 0) {
 const ads = user.transactions.filter(t => (t.type || '').toLowerCase() === 'ads');
 items = ads.map(normalizeAd);
 }
 else if (window.APP_MODE.DEMO_MODE) {
 items = DEMO_ADS.slice();
 }
 else {
 items = [];
 }
 items.sort((a, b) => (b._ts || 0) - (a._ts || 0));
 ADS_HISTORY = items;
 render();
 }
 function normalizeAd(a){
 let dateStr = a.date || '', timeStr = a.time || '', ts = 0;
 let isToday = a.today === true;
 if (a.watchedAt || a.submittedAt || a.dateIso || a.createdAt) {
 const dt = new Date(a.watchedAt || a.submittedAt || a.dateIso || a.createdAt);
 ts = dt.getTime();
 const now = new Date();
 isToday = dt.toDateString() === now.toDateString();
 const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
 dateStr = dt.getDate() + ' ' + months[dt.getMonth()];
 let h = dt.getHours(); const m = String(dt.getMinutes()).padStart(2,'0');
 const ampm = h >= 12 ? 'PM' : 'AM'; h = h % 12; if (h === 0) h = 12;
 timeStr = `${String(h).padStart(2,'0')}:${m} ${ampm}`;
 }
 return {
 plan: Number(a.plan || a.planAmount || 0),
 reward: Number(a.reward || a.daily || a.amount || a.dailyProfit || 0),
 date: dateStr || '—',
 time: timeStr || '—',
 today: isToday,
 _ts: ts
 };
 }
 function render() {
 const list = document.getElementById('historyList');
 const countEl = document.getElementById('historyCount');
 if (!list) return;
 const totalAds = ADS_HISTORY.length;
 const totalEarned = ADS_HISTORY.reduce((s, i) => s + i.reward, 0);
 const todayCount = ADS_HISTORY.filter(i => i.today).length;
 const avgReward = totalAds ? Math.round(totalEarned / totalAds) : 0;
 document.getElementById('earnedInt').textContent = totalEarned.toLocaleString('en-IN');
 document.getElementById('watchedCount').textContent = totalAds + ' Ads';
 document.getElementById('statTotal').textContent = totalAds;
 document.getElementById('statToday').textContent = todayCount;
 document.getElementById('statAvg').textContent = 'Rs ' + avgReward.toLocaleString('en-IN');
 countEl.textContent = totalAds + ' ADS';
 if (totalAds === 0) {
 list.innerHTML = `
 <div class="empty-state">
 <div class="empty-icon">
 <svg viewBox="0 0 24 24">
 <polygon points="23 7 16 12 23 17 23 7"/>
 <rect x="1" y="5" width="15" height="14" rx="2" ry="2"/>
 </svg>
 </div>
 <div class="empty-title">No Ads Watched Yet</div>
 <div class="empty-desc">Start watching ads to see history</div>
 </div>
 `;
 return;
 }
 list.innerHTML = ADS_HISTORY.map((item, idx) => {
 const lvl = LEVELS[idx % LEVELS.length];
 const amountClass = lvl === 'lvl2' ? 'blue' : lvl === 'lvl3' ? 'purple' : '';
 const planLabel = item.plan >= 1000 ? (item.plan/1000) + 'K' : String(item.plan);
 return `
 <div class="member-card ${lvl}">
 <div class="mc-avatar">${planLabel}</div>
 <div class="mc-content">
 <div class="mc-name">Rs ${item.plan.toLocaleString('en-IN')} Plan Ad</div>
 <div class="mc-meta">
 <span>${item.date}</span>
 <span class="dot-sep"></span>
 <span>${item.time}</span>
 <span class="mc-badge">${item.today ? 'TODAY' : 'AD'}</span>
 </div>
 </div>
 <div class="mc-right">
 <div class="mc-amount ${amountClass}">+Rs ${item.reward.toLocaleString('en-IN')}</div>
 <div class="mc-time">Profit</div>
 </div>
 </div>
 `;
 }).join('');
 }
 function goTo(page) { setTimeout(() => { window.location.href = page; }, 100); }
 function goToWithNotif(page, title, message){
 showToast(message || ('Opening ' + title + '...'), 'info', title);
 setTimeout(() => {
 window.location.href = page;
 }, 650);
 }
 function openCustomerService(){
 showToast('Connecting to support team...', 'info', 'Customer Service');
 setTimeout(() => {
 window.location.href = 'customer.html';
 }, 650);
 }
 loadUserData();
 document.addEventListener('gesturestart', e => e.preventDefault());
 document.addEventListener('gesturechange', e => e.preventDefault());
 document.addEventListener('gestureend', e => e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e => {
 const now = Date.now();
 if (now - lastTouch <= 300) e.preventDefault();
 lastTouch = now;
 }, { passive: false });
 document.addEventListener('wheel', e => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });
 document.addEventListener('keydown', e => {
 if ((e.ctrlKey || e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault();
 });