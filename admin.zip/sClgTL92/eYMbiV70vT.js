window.APP_MODE = {
 DEMO_MODE: true,
 DEMO_USER: {
 uid: 'DEMO001',
 name: 'Demo User',
 email: 'demo@predxprofit.pk',
 whatsapp: '03001234567',
 wallet: 0,
 activePlans: 0,
 referralCode: 'PREDX001',
 todayEarning: 0,
 teamSize: 0,
 adsWatched: 0,
 joinDate: new Date('2026-01-15').toISOString()
 }
 };
 window.API_CONFIG = {
 baseURL: "",
 apiKey: "",
 endpoints: {
 register: "/auth/register",
 login: "/auth/login",
 logout: "/auth/logout",
 getUser: "/user/me",
 updateUser: "/user/update",
 getNextUID: "/meta/next-uid",
 getPlans: "/plans",
 createDeposit: "/deposits",
 getDeposits: "/deposits/me",
 createWithdraw: "/withdraws",
 getWithdraws: "/withdraws/me",
 watchAd: "/ads/watch",
 getAdsHistory: "/ads/history",
 getTeam: "/team/me",
 getTransactions: "/transactions/me",
 redeemGift: "/gifts/redeem",
 getChats: "/chats/me",
 sendMessage: "/chats/send",
 getMessages: "/chats/:id/messages",
 getLatestUpdate: "/updates/latest"
 },
 getHeaders: function() {
 const h = { "Content-Type": "application/json" };
 if (this.apiKey) h["Authorization"] = "Bearer " + this.apiKey;
 const loggedUser = localStorage.getItem('loggedUser');
 if (loggedUser) {
 try {
 const u = JSON.parse(loggedUser);
 if (u.uid) h["X-User-UID"] = u.uid;
 } catch(e) {}
 }
 return h;
 }
 };
 window.API = {
 async call(endpoint, method = "GET", body = null) {
 if (!API_CONFIG.baseURL) {
 return { success: false, error: "API baseURL not configured" };
 }
 const url = API_CONFIG.baseURL + endpoint;
 const options = { method, headers: API_CONFIG.getHeaders() };
 if (body) options.body = JSON.stringify(body);
 try {
 const res = await fetch(url, options);
 const data = await res.json().catch(() => ({}));
 if (!res.ok) {
 return { success: false, error: data.message || data.error || "Request failed", data };
 }
 return { success: true, data };
 } catch (err) {
 return { success: false, error: err.message || "Network error" };
 }
 },
 get(ep) { return this.call(ep, "GET"); },
 post(ep, body) { return this.call(ep, "POST", body); },
 put(ep, body) { return this.call(ep, "PUT", body); },
 del(ep) { return this.call(ep, "DELETE"); }
 };
function showToast(msg, type = 'success', title = null) {
 const holder = document.getElementById('notifHolder');
 if (!holder) return;
 if (type === 'success') {
 const errKeywords = ['error','invalid','failed','not found','wrong','incorrect','already','required','enter ','please','too short','too long','try again','doesn\'t','cannot','can not','not registered','not match'];
 const lower = String(msg).toLowerCase();
 if (errKeywords.some(k => lower.includes(k))) type = 'error';
 }
 const icons = {
 success: '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
 error: '<svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
 info: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
 };
 const titles = {
 success: title || 'Success',
 error: title || 'Error',
 info: title || 'Info'
 };
 const notif = document.createElement('div');
 notif.className = 'premium-notif ' + type;
 notif.innerHTML = `
 <div class="premium-notif-icon">${icons[type]}</div>
 <div class="premium-notif-text">
 <div class="premium-notif-title">${titles[type]}</div>
 <div class="premium-notif-msg">${msg}</div>
 </div>
 <button class="premium-notif-close" onclick="this.parentElement.classList.remove('show');setTimeout(()=>this.parentElement.remove(),500);">
 <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
 </button>
 `;
 holder.appendChild(notif);
 requestAnimationFrame(() => notif.classList.add('show'));
 setTimeout(() => {
 if (notif.parentElement) {
 notif.classList.remove('show');
 setTimeout(() => notif.remove(), 500);
 }
 }, 3500);
 }
 function showLoading(){ document.getElementById('loadingOverlay').classList.add('active'); }
 function hideLoading(){ document.getElementById('loadingOverlay').classList.remove('active'); }
 function goTo(page){
 setTimeout(() => { window.location.href = page; }, 100);
 }
 function goToWithNotif(page, title, message){
 showToast(message || ('Opening ' + title + '...'), 'info', title);
 setTimeout(() => {
 window.location.href = page;
 }, 650);
 }
 function openCustomerService(){
 showToast('Connecting to support team...', 'info', 'Customer Service');
 setTimeout(() => {
 window.location.href = 'customer.html';
 }, 650);
 }
 let balHidden = false;
 let realBalance = 0;
 function toggleBal(){
 balHidden = !balHidden;
 const balInt = document.getElementById('balInt');
 const balDec = document.getElementById('balDec');
 const eyeIcon = document.getElementById('eyeIcon');
 if(balHidden){
 balInt.textContent = '•••';
 balDec.textContent = '';
 eyeIcon.innerHTML = '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>';
 } else {
 const wInt = Math.floor(realBalance);
 const wDec = (realBalance - wInt).toFixed(2).substring(1);
 balInt.textContent = wInt.toLocaleString('en-IN');
 balDec.textContent = wDec || '.00';
 eyeIcon.innerHTML = '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>';
 }
 adjustBalanceFont();
 }
 function adjustBalanceFont(){
 const wrap = document.getElementById('balAmount');
 if(!wrap) return;
 const intEl = document.getElementById('balInt');
 const text = intEl.textContent || '';
 const len = text.length;
 let size = 34;
 if (len >= 8) size = 24;
 else if (len >= 7) size = 26;
 else if (len >= 6) size = 28;
 else if (len >= 5) size = 30;
 else if (len >= 4) size = 32;
 wrap.style.fontSize = size + 'px';
 }
 function copyRef(){
 const input = document.getElementById('refLink');
 if(!input) return;
 input.select();
 input.setSelectionRange(0, 99999);
 try { document.execCommand('copy'); } catch(e){}
 if(navigator.clipboard && window.isSecureContext){
 navigator.clipboard.writeText(input.value).catch(() => {});
 }
 showToast('Referral link copied!');
 window.getSelection && window.getSelection().removeAllRanges();
 }
 async function loadUserData(){
 const loggedUser = localStorage.getItem('loggedUser');
 let user = null;
 if (window.APP_MODE.DEMO_MODE) {
 if (loggedUser) {
 try { user = JSON.parse(loggedUser); } catch(e){}
 }
 if (!user || !user.uid) {
 user = window.APP_MODE.DEMO_USER;
 localStorage.setItem('loggedUser', JSON.stringify(user));
 }
 renderUserData(user);
 return;
 }
 if (!loggedUser) {
 window.location.replace('index.html');
 return;
 }
 try { user = JSON.parse(loggedUser); } catch(e){}
 if (!user || !user.uid) {
 window.location.replace('index.html');
 return;
 }
 if (window.API_CONFIG.baseURL) {
 try {
 const result = await window.API.get(API_CONFIG.endpoints.getUser);
 if (!result.success) {
 renderUserData(user);
 return;
 }
 const freshUser = result.data.user || result.data;
 renderUserData(freshUser);
 localStorage.setItem('loggedUser', JSON.stringify({
 uid: freshUser.uid,
 name: freshUser.name,
 email: freshUser.email,
 whatsapp: freshUser.whatsapp
 }));
 } catch(err){
 renderUserData(user);
 }
 } else {
 renderUserData(user);
 }
 }
 function renderUserData(user){
 if(!user) return;
 realBalance = user.wallet || 0;
 const wInt = Math.floor(realBalance);
 const wDec = (realBalance - wInt).toFixed(2).substring(1);
 document.getElementById('balInt').textContent = wInt.toLocaleString('en-IN');
 document.getElementById('balDec').textContent = wDec || '.00';
 document.getElementById('activePlansCount').textContent = user.activePlans || 0;
 const refCode = user.referralCode || '';
 document.getElementById('refLink').value = 'https://predxprofit.pk/?ref=' + refCode;
 document.getElementById('todayEarning').textContent = 'Rs ' + (user.todayEarning || 0).toLocaleString('en-IN');
 document.getElementById('teamSize').textContent = user.teamSize || 0;
 document.getElementById('adsWatched').textContent = user.adsWatched || 0;
 if(user.joinDate){
 const d = new Date(user.joinDate);
 document.getElementById('activeSince').textContent = d.toLocaleDateString('en-IN', { month:'short', year:'numeric' });
 }
 adjustBalanceFont();
 }
 async function checkForUpdates(){
 if (window.APP_MODE.DEMO_MODE) {
 setTimeout(() => {
 openConnectDialog();
 }, 800);
 return;
 }
 try {
 const result = await window.API.get(API_CONFIG.endpoints.getLatestUpdate);
 if(!result.success){
 setTimeout(() => {
 openConnectDialog();
 }, 800);
 return;
 }
 const update = result.data.update || result.data;
 const dismissed = localStorage.getItem('dismissedUpdate_' + update.version);
 if(dismissed === 'true') {
 setTimeout(() => {
 openConnectDialog();
 }, 800);
 return;
 }
 showUpdateDialog(update);
 } catch(err){
 console.warn('⚠️ Could not fetch update:', err);
 setTimeout(() => {
 openConnectDialog();
 }, 800);
 }
 }
 function showUpdateDialog(update){
 document.getElementById('udVersion').textContent = update.version || 'v1.0.0';
 document.getElementById('udDate').textContent = update.date || new Date().toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' });
 document.getElementById('udTitle').textContent = update.title || 'What\'s New';
 document.getElementById('udBody').textContent = update.body || '';
 document.getElementById('updateOverlay').classList.add('active');
 }
 function closeUpdateDialog(){
 const version = document.getElementById('udVersion').textContent;
 try { localStorage.setItem('dismissedUpdate_' + version, 'true'); } catch(e) {}
 document.getElementById('updateOverlay').classList.remove('active');
 setTimeout(() => {
 openConnectDialog();
 }, 400);
 }
 function startPolling(){
 if (window.APP_MODE.DEMO_MODE) return;
 if (!window.API_CONFIG.baseURL) return;
 setInterval(async () => {
 const loggedUser = localStorage.getItem('loggedUser');
 if(!loggedUser) return;
 try {
 const result = await window.API.get(API_CONFIG.endpoints.getUser);
 if(result.success){
 const freshUser = result.data.user || result.data;
 renderUserData(freshUser);
 }
 } catch(e){}
 }, 15000);
 }
 const WHATSAPP_CHANNEL_URL = "https://whatsapp.com/channel/0029VamgXHd7z4kecde53Q1i";
 const ADMIN_WHATSAPP_NUMBER = "923157656097";
 function openConnectDialog(){
 document.getElementById('connectOverlay').classList.add('active');
 }
 function closeConnectDialog(){
 document.getElementById('connectOverlay').classList.remove('active');
 try { localStorage.setItem('connectDialogSeen', 'true'); } catch(e) {}
 }
 function joinWhatsAppChannel(){
 try { window.open(WHATSAPP_CHANNEL_URL, '_blank'); } catch(e){}
 showToast('Opening WhatsApp Channel...', 'success', 'Join Channel');
 }
 function openAdminContactDialog(){
 document.getElementById('connectOverlay').classList.remove('active');
 setTimeout(() => {
 document.getElementById('adminMsgOverlay').classList.add('active');
 document.getElementById('adminMsgInput').focus();
 }, 300);
 }
 function closeAdminMsgDialog(){
 document.getElementById('adminMsgOverlay').classList.remove('active');
 setTimeout(() => {
 document.getElementById('connectOverlay').classList.add('active');
 }, 300);
 }
 function openCustomerSupport(){
 closeConnectDialog();
 showToast('Opening Customer Support...', 'info', 'Customer Support');
 setTimeout(() => {
 window.location.href = 'customer.html';
 }, 700);
 }
 function insertQuickMsg(text){
 const ta = document.getElementById('adminMsgInput');
 ta.value = text;
 updateCharCount();
 ta.focus();
 }
 function updateCharCount(){
 const ta = document.getElementById('adminMsgInput');
 const cc = document.getElementById('amCharCount');
 if(ta && cc) cc.textContent = ta.value.length;
 }
 function sendToAdminWhatsApp(){
 const msg = (document.getElementById('adminMsgInput').value || '').trim();
 if(!msg){
 showToast('Please type a message first!', 'error', 'Empty Message');
 return;
 }
 const url = `https://wa.me/${ADMIN_WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`;
 try { window.open(url, '_blank'); } catch(e){}
 document.getElementById('adminMsgOverlay').classList.remove('active');
 showToast('Opening WhatsApp...', 'success', 'Opening Chat');
 }
 (function initCharCount(){
 const ta = document.getElementById('adminMsgInput');
 if(ta) ta.addEventListener('input', updateCharCount);
 })();
 loadUserData();
 startPolling();
 setTimeout(checkForUpdates, 1200);
 document.addEventListener('gesturestart', e => e.preventDefault());
 document.addEventListener('gesturechange', e => e.preventDefault());
 document.addEventListener('gestureend', e => e.preventDefault());
 let lastTouch = 0;
 document.addEventListener('touchend', e => {
 const now = Date.now();
 if (now - lastTouch <= 300) e.preventDefault();
 lastTouch = now;
 }, { passive: false });
 document.addEventListener('wheel', e => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });
 document.addEventListener('keydown', e => {
 if ((e.ctrlKey || e.metaKey) && ['+','-','=','0'].includes(e.key)) e.preventDefault();
 });