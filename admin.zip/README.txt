PREDX PROFIT - STATIC HOSTING BUNDLE
====================================
Is folder ki SAARI files apni hosting ke public folder (Vercel: repo root / public, cPanel: public_html) mein upload karein.

Links (bina .html ke):
  /login  /register  /dashboard  /plans  /payment  /withdraw  /team  /support  /ads ...
  Admin: /predx-admin/login  /predx-admin/dashboard ...

Server (API) is hosting par nahi, Lovable par chalta hai:
  https://api-connect-core.lovable.app
Isliye ye bundle tabhi kaam karega jab woh site live ho.
