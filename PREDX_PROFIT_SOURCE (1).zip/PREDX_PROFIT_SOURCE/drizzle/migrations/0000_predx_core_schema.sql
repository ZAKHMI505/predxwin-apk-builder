create extension if not exists pgcrypto with schema extensions;

-- ========== ADMINS ==========
create table public.admins (
  id uuid primary key default gen_random_uuid(),
  gmail text not null unique,
  password_hash text not null,
  created_at timestamptz not null default now()
);
grant all on public.admins to service_role;
alter table public.admins enable row level security;

-- ========== APP USERS ==========
create table public.app_users (
  id uuid primary key default gen_random_uuid(),
  uid text not null unique,
  name text not null,
  phone text,
  gmail text not null unique,
  password_hash text not null,
  balance numeric(14,2) not null default 0,
  valid_amount numeric(14,2) not null default 0,
  withdraw_balance numeric(14,2) not null default 0,
  active_plan_id uuid,
  plan_started_at timestamptz,
  referred_by text,
  locked boolean not null default false,
  created_at timestamptz not null default now()
);
create index on public.app_users (referred_by);
grant all on public.app_users to service_role;
alter table public.app_users enable row level security;

-- ========== SESSIONS ==========
create table public.sessions (
  token text primary key,
  user_id uuid,
  admin_id uuid,
  kind text not null check (kind in ('user','admin')),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default now() + interval '30 days'
);
create index on public.sessions (user_id);
grant all on public.sessions to service_role;
alter table public.sessions enable row level security;

-- ========== PLANS ==========
create table public.plans (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  price numeric(14,2) not null,
  daily_return numeric(14,2) not null default 0,
  duration_days int not null default 30,
  max_daily_withdraw numeric(14,2) not null default 100,
  sort_order int not null default 0,
  active boolean not null default true
);
grant all on public.plans to service_role;
alter table public.plans enable row level security;

-- ========== DEPOSITS ==========
create table public.deposits (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  plan_id uuid,
  amount numeric(14,2) not null,
  txn_id text,
  screenshot_url text,
  status text not null default 'pending' check (status in ('pending','accepted','rejected')),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);
create index on public.deposits (user_id);
create index on public.deposits (status);
grant all on public.deposits to service_role;
alter table public.deposits enable row level security;

-- ========== WITHDRAWALS ==========
create table public.withdrawals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  amount numeric(14,2) not null,
  method text,
  account_name text,
  account_number text,
  status text not null default 'pending' check (status in ('pending','accepted','rejected')),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);
create index on public.withdrawals (user_id);
create index on public.withdrawals (status);
grant all on public.withdrawals to service_role;
alter table public.withdrawals enable row level security;

-- ========== TRANSACTIONS ==========
create table public.transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  kind text not null,
  amount numeric(14,2) not null,
  note text,
  created_at timestamptz not null default now()
);
create index on public.transactions (user_id, created_at desc);
grant all on public.transactions to service_role;
alter table public.transactions enable row level security;

-- ========== ADS WATCHES ==========
create table public.ads_watches (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  watch_date date not null default current_date,
  reward numeric(14,2) not null default 0,
  created_at timestamptz not null default now(),
  unique (user_id, watch_date)
);
grant all on public.ads_watches to service_role;
alter table public.ads_watches enable row level security;

-- ========== GIFT CODES ==========
create table public.gift_codes (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  amount numeric(14,2) not null,
  max_uses int not null default 1,
  uses int not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
grant all on public.gift_codes to service_role;
alter table public.gift_codes enable row level security;

create table public.gift_code_redemptions (
  id uuid primary key default gen_random_uuid(),
  code_id uuid not null,
  user_id uuid not null,
  amount numeric(14,2) not null,
  created_at timestamptz not null default now(),
  unique (code_id, user_id)
);
grant all on public.gift_code_redemptions to service_role;
alter table public.gift_code_redemptions enable row level security;

-- ========== SUPPORT ==========
create table public.support_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  sender text not null check (sender in ('user','admin')),
  body text not null,
  created_at timestamptz not null default now()
);
create index on public.support_messages (user_id, created_at);
grant all on public.support_messages to service_role;
alter table public.support_messages enable row level security;

-- ========== SETTINGS (notice, payment accounts, salary rules) ==========
create table public.app_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
grant all on public.app_settings to service_role;
alter table public.app_settings enable row level security;

-- ========== SEED ==========
insert into public.admins (gmail, password_hash)
values ('zakhmihacker505@gmail.com', extensions.crypt('CHANGE_ME_ADMIN_PASSWORD', extensions.gen_salt('bf', 10)));

insert into public.app_settings (key, value) values
  ('notice', '{"enabled": true, "title": "Welcome to PredX Profit", "body": "New update aa gaya hai. Daily ad dekh kar bonus kamayein!", "button_text": "OK", "button_link": ""}'::jsonb),
  ('payment_accounts', '[{"method":"Easypaisa","account_name":"PredX Profit","account_number":"03000000000"},{"method":"JazzCash","account_name":"PredX Profit","account_number":"03110000000"}]'::jsonb),
  ('salary_rules', '{"team_levels":[{"level":1,"percent":10},{"level":2,"percent":5},{"level":3,"percent":2}],"agent_min_members":10}'::jsonb),
  ('withdraw_rules', '{"withdraw_percent_of_dashboard":50,"ads_max_daily_withdraw":100}'::jsonb);

insert into public.plans (name, price, daily_return, duration_days, max_daily_withdraw, sort_order) values
  ('Plan 1', 1000, 60, 30, 100, 1),
  ('Plan 2', 3000, 190, 30, 200, 2),
  ('Plan 3', 5000, 330, 30, 350, 3),
  ('Plan 4', 10000, 700, 30, 700, 4),
  ('Plan 5', 25000, 1800, 30, 1800, 5),
  ('Plan 6', 50000, 3800, 30, 3800, 6);