ALTER TABLE public.ads_watches ADD COLUMN IF NOT EXISTS deposit_id uuid;
ALTER TABLE public.ads_watches DROP CONSTRAINT IF EXISTS ads_watches_user_id_watch_date_key;
CREATE UNIQUE INDEX IF NOT EXISTS ads_watches_deposit_day ON public.ads_watches (deposit_id, watch_date);
UPDATE public.app_users SET withdraw_balance = balance;
DELETE FROM public.plans;
INSERT INTO public.plans (name, price, daily_return, duration_days, max_daily_withdraw, sort_order) VALUES
('Rs 600 Plan',600,120,35,100,1),('Rs 1200 Plan',1200,240,35,100,2),('Rs 1800 Plan',1800,360,35,100,3),
('Rs 2400 Plan',2400,480,35,100,4),('Rs 4200 Plan',4200,840,35,100,5),('Rs 5800 Plan',5800,1160,35,100,6),
('Rs 8000 Plan',8000,1600,35,100,7),('Rs 12000 Plan',12000,2400,35,100,8),('Rs 18000 Plan',18000,3600,35,100,9),
('Rs 25000 Plan',25000,5000,35,100,10),('Rs 40000 Plan',40000,8000,35,100,11);