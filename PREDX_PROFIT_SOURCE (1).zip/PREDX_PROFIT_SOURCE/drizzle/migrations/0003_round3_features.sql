ALTER TABLE public.withdrawals ADD COLUMN IF NOT EXISTS proof_path text;
ALTER TABLE public.support_messages ADD COLUMN IF NOT EXISTS attachment_path text;
ALTER TABLE public.support_messages ADD COLUMN IF NOT EXISTS attachment_type text;
ALTER TABLE public.app_users ADD COLUMN IF NOT EXISTS device_warned boolean NOT NULL DEFAULT false;
ALTER TABLE public.app_users ADD COLUMN IF NOT EXISTS unlock_notice boolean NOT NULL DEFAULT false;
CREATE TABLE IF NOT EXISTS public.user_devices (
  device_id text NOT NULL,
  user_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_seen timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (device_id, user_id)
);
GRANT ALL ON public.user_devices TO service_role;
ALTER TABLE public.user_devices ENABLE ROW LEVEL SECURITY;