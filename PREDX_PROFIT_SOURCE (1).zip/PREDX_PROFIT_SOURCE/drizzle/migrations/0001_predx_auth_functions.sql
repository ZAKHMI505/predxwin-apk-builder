create or replace function public.predx_hash(_pw text)
returns text language sql volatile security definer set search_path = public, extensions
as $$ select extensions.crypt(_pw, extensions.gen_salt('bf', 10)) $$;

create or replace function public.predx_verify_admin(_gmail text, _pw text)
returns uuid language sql stable security definer set search_path = public, extensions
as $$
  select id from public.admins
  where lower(gmail) = lower(_gmail)
    and password_hash = extensions.crypt(_pw, password_hash)
  limit 1
$$;

create or replace function public.predx_verify_user(_gmail text, _pw text)
returns uuid language sql stable security definer set search_path = public, extensions
as $$
  select id from public.app_users
  where lower(gmail) = lower(_gmail)
    and password_hash = extensions.crypt(_pw, password_hash)
  limit 1
$$;

revoke all on function public.predx_hash(text) from public, anon, authenticated;
revoke all on function public.predx_verify_admin(text, text) from public, anon, authenticated;
revoke all on function public.predx_verify_user(text, text) from public, anon, authenticated;
grant execute on function public.predx_hash(text) to service_role;
grant execute on function public.predx_verify_admin(text, text) to service_role;
grant execute on function public.predx_verify_user(text, text) to service_role;