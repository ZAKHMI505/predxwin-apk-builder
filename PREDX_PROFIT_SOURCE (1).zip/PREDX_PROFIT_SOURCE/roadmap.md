# PredX fixes (round 2)
- [x] Account lock, deposit status, referral domain, same balance, support chat, admin stats, readable URLs, browser tests

# Round 3
- [x] Support chat: user screenshot/file reaches admin chat (admin can send images too)
- [x] Withdraw accepted in admin shows Approved in user panel
- [x] Withdraw dialog (user): "Payment Screenshot" button showing admin's upload
- [x] Withdraw request shows selected method + account to admin
- [x] Withdraw rule: needs own plan; after 3 plan days needs 1 member (1200+) else 50% of ad profit
- [x] Admin wallet: image upload -> auto link -> QR updates
- [x] Admin profile agents: real users with 10+ members
- [x] Dashboard live withdrawals: real (active plan) + fake
- [x] Referral bonus 200 first / 100 repeat (1200+); agent salary 2500 only if 10+ members all above 1200
- [x] Daily ad at 5:00 AM PKT, unwatched stack newest first
- [x] Unlock dialog on next login after admin unlock
- [x] One account per phone: 2nd -> warning, continued use -> lock; 3rd -> lock
- [x] Website icon + name "Predx Profit Pro"
- [x] Fix live "page didn't load" error (startup code)
- [ ] Publish (user presses Publish)
