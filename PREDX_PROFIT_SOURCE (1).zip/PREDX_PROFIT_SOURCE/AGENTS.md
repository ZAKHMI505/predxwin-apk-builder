<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep original panel HTML under src/panels and serve it through src/lib/panel-pages.ts; centralize canonical URLs, legacy redirects, page identity, and absolute asset paths there so static hosting cannot bypass routing or collide with prerendered output.
- Panel bridge scripts must use the injected page identity and absolute canonical destinations, not filename matching against random URL slugs; this prevents login loops and broken post-login navigation.
- Never place credentials or deployment notes containing credentials in public assets; all files there are anonymously downloadable.
- Panel bridge scripts are edited only in src/panel-src/*.js and rebuilt into obfuscated public copies with src/panel-src/build.sh; public copies are generated output so the shipped JS stays unreadable.
- Panel pages use readable public URLs (/login, /dashboard, /predx-admin/dashboard) mapped to obfuscated file folders in src/lib/panel-pages.ts; old random-slug and .html links 308-redirect there.
- Panel pages are pre-rendered at module load using pure string work only; never construct Request/Response or do I/O/randomness at module scope, because the live server runtime rejects it and every page errors.
