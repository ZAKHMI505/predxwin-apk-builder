export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      admins: {
        Row: {
          created_at: string
          gmail: string
          id: string
          password_hash: string
        }
        Insert: {
          created_at?: string
          gmail: string
          id?: string
          password_hash: string
        }
        Update: {
          created_at?: string
          gmail?: string
          id?: string
          password_hash?: string
        }
        Relationships: []
      }
      ads_watches: {
        Row: {
          created_at: string
          deposit_id: string | null
          id: string
          reward: number
          user_id: string
          watch_date: string
        }
        Insert: {
          created_at?: string
          deposit_id?: string | null
          id?: string
          reward?: number
          user_id: string
          watch_date?: string
        }
        Update: {
          created_at?: string
          deposit_id?: string | null
          id?: string
          reward?: number
          user_id?: string
          watch_date?: string
        }
        Relationships: []
      }
      app_settings: {
        Row: {
          key: string
          updated_at: string
          value: Json
        }
        Insert: {
          key: string
          updated_at?: string
          value?: Json
        }
        Update: {
          key?: string
          updated_at?: string
          value?: Json
        }
        Relationships: []
      }
      app_users: {
        Row: {
          active_plan_id: string | null
          balance: number
          created_at: string
          device_warned: boolean
          device_warned_at: string | null
          gmail: string
          id: string
          locked: boolean
          name: string
          password_hash: string
          phone: string | null
          plan_started_at: string | null
          referred_by: string | null
          uid: string
          unlock_notice: boolean
          valid_amount: number
          withdraw_balance: number
        }
        Insert: {
          active_plan_id?: string | null
          balance?: number
          created_at?: string
          device_warned?: boolean
          device_warned_at?: string | null
          gmail: string
          id?: string
          locked?: boolean
          name: string
          password_hash: string
          phone?: string | null
          plan_started_at?: string | null
          referred_by?: string | null
          uid: string
          unlock_notice?: boolean
          valid_amount?: number
          withdraw_balance?: number
        }
        Update: {
          active_plan_id?: string | null
          balance?: number
          created_at?: string
          device_warned?: boolean
          device_warned_at?: string | null
          gmail?: string
          id?: string
          locked?: boolean
          name?: string
          password_hash?: string
          phone?: string | null
          plan_started_at?: string | null
          referred_by?: string | null
          uid?: string
          unlock_notice?: boolean
          valid_amount?: number
          withdraw_balance?: number
        }
        Relationships: []
      }
      deposits: {
        Row: {
          amount: number
          created_at: string
          id: string
          plan_id: string | null
          reviewed_at: string | null
          screenshot_url: string | null
          status: string
          txn_id: string | null
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          plan_id?: string | null
          reviewed_at?: string | null
          screenshot_url?: string | null
          status?: string
          txn_id?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          plan_id?: string | null
          reviewed_at?: string | null
          screenshot_url?: string | null
          status?: string
          txn_id?: string | null
          user_id?: string
        }
        Relationships: []
      }
      gift_code_redemptions: {
        Row: {
          amount: number
          code_id: string
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          amount: number
          code_id: string
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          amount?: number
          code_id?: string
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      gift_codes: {
        Row: {
          active: boolean
          amount: number
          code: string
          created_at: string
          id: string
          max_uses: number
          uses: number
        }
        Insert: {
          active?: boolean
          amount: number
          code: string
          created_at?: string
          id?: string
          max_uses?: number
          uses?: number
        }
        Update: {
          active?: boolean
          amount?: number
          code?: string
          created_at?: string
          id?: string
          max_uses?: number
          uses?: number
        }
        Relationships: []
      }
      plans: {
        Row: {
          active: boolean
          daily_return: number
          duration_days: number
          id: string
          max_daily_withdraw: number
          name: string
          price: number
          sort_order: number
        }
        Insert: {
          active?: boolean
          daily_return?: number
          duration_days?: number
          id?: string
          max_daily_withdraw?: number
          name: string
          price: number
          sort_order?: number
        }
        Update: {
          active?: boolean
          daily_return?: number
          duration_days?: number
          id?: string
          max_daily_withdraw?: number
          name?: string
          price?: number
          sort_order?: number
        }
        Relationships: []
      }
      sessions: {
        Row: {
          admin_id: string | null
          created_at: string
          expires_at: string
          kind: string
          token: string
          user_id: string | null
        }
        Insert: {
          admin_id?: string | null
          created_at?: string
          expires_at?: string
          kind: string
          token: string
          user_id?: string | null
        }
        Update: {
          admin_id?: string | null
          created_at?: string
          expires_at?: string
          kind?: string
          token?: string
          user_id?: string | null
        }
        Relationships: []
      }
      support_messages: {
        Row: {
          attachment_path: string | null
          attachment_type: string | null
          body: string
          created_at: string
          id: string
          sender: string
          user_id: string
        }
        Insert: {
          attachment_path?: string | null
          attachment_type?: string | null
          body: string
          created_at?: string
          id?: string
          sender: string
          user_id: string
        }
        Update: {
          attachment_path?: string | null
          attachment_type?: string | null
          body?: string
          created_at?: string
          id?: string
          sender?: string
          user_id?: string
        }
        Relationships: []
      }
      transactions: {
        Row: {
          amount: number
          created_at: string
          id: string
          kind: string
          note: string | null
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          kind: string
          note?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          kind?: string
          note?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_devices: {
        Row: {
          created_at: string
          device_id: string
          last_seen: string
          user_id: string
        }
        Insert: {
          created_at?: string
          device_id: string
          last_seen?: string
          user_id: string
        }
        Update: {
          created_at?: string
          device_id?: string
          last_seen?: string
          user_id?: string
        }
        Relationships: []
      }
      withdrawals: {
        Row: {
          account_name: string | null
          account_number: string | null
          amount: number
          created_at: string
          id: string
          method: string | null
          proof_path: string | null
          reviewed_at: string | null
          status: string
          user_id: string
        }
        Insert: {
          account_name?: string | null
          account_number?: string | null
          amount: number
          created_at?: string
          id?: string
          method?: string | null
          proof_path?: string | null
          reviewed_at?: string | null
          status?: string
          user_id: string
        }
        Update: {
          account_name?: string | null
          account_number?: string | null
          amount?: number
          created_at?: string
          id?: string
          method?: string | null
          proof_path?: string | null
          reviewed_at?: string | null
          status?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      predx_hash: { Args: { _pw: string }; Returns: string }
      predx_verify_admin: {
        Args: { _gmail: string; _pw: string }
        Returns: string
      }
      predx_verify_user: {
        Args: { _gmail: string; _pw: string }
        Returns: string
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
