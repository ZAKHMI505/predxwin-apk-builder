// Keep original panel documents private to the bundle; serve them through one URL resolver.
// Files stay in obfuscated folders; public addresses are readable names.
const documents = import.meta.glob('/src/panels/**/index.html', {
  eager: true, query: '?raw', import: 'default',
}) as Record<string, string>;

type Page = { url: string; file: string };
const user: Record<string, Page> = {
  index: { url: '/login', file: '/' },
  dashboard: { url: '/dashboard', file: '/MoQTbEoJGu/' },
  profile: { url: '/profile', file: '/es8i3hkWtO/' },
  plan: { url: '/plans', file: '/jYf4YW0zCE/' },
  active: { url: '/payment', file: '/HoHrdkUWZO/' },
  withdraw: { url: '/withdraw', file: '/hTltNpuuCe/' },
  'deposit-history': { url: '/deposit-history', file: '/6WjWiqX2HI/' },
  'withdraw-history': { url: '/withdraw-history', file: '/TRSeY8iA7G/' },
  transactions: { url: '/transactions', file: '/eufweJ92ey/' },
  ads: { url: '/ads', file: '/MEwKAQP8Ox/' },
  'ads-history': { url: '/ads-history', file: '/VWOPPdRaV5/' },
  team: { url: '/team', file: '/vOhDwMMOd4/' },
  customer: { url: '/support', file: '/LzDhBOAwdG/' },
};
const A = '/predx-admin';
const admin: Record<string, Page> = {
  index: { url: `${A}/login`, file: `${A}/` },
  'admin-dashboard': { url: `${A}/dashboard`, file: `${A}/NyBqrXlOnG/` },
  'admin-deposits': { url: `${A}/deposits`, file: `${A}/ZvHWHjHMUJ/` },
  'admin-request-deposits': { url: `${A}/deposit-requests`, file: `${A}/wtyv9iZexk/` },
  'admin-withdraws': { url: `${A}/withdrawals`, file: `${A}/Xrln9wpE86/` },
  'admin-request-withdraws': { url: `${A}/withdraw-requests`, file: `${A}/UWdtuwfRBQ/` },
  'admin-giftcodes': { url: `${A}/gift-codes`, file: `${A}/OpzVbe7lS0/` },
  'admin-plans': { url: `${A}/plans`, file: `${A}/Pa7mQs2Xv9/` },
  'admin-profile': { url: `${A}/profile`, file: `${A}/yNykHVsJ1E/` },
  'admin-settings': { url: `${A}/settings`, file: `${A}/DjdHIld64M/` },
  'admin-wallet': { url: `${A}/wallet`, file: `${A}/r8XRtIkQZt/` },
  'admin-support': { url: `${A}/support`, file: `${A}/bBihXXyEhb/` },
};
const USER_LOGIN: Page = user['index']!;
const ADMIN_LOGIN: Page = admin['index']!;
const aliases: Record<string, string> = {
  login: 'index', register: 'index', 'admin-login': 'index', 'admin-users': 'admin-dashboard',
};

export const userPages = Object.fromEntries(Object.entries(user).map(([k, p]) => [k, p.url]));
export const adminPages = Object.fromEntries(Object.entries(admin).map(([k, p]) => [k, p.url]));
// Navigation map given to page scripts (includes aliases so old names keep working).
const routeMap = (pages: Record<string, Page>, isAdmin: boolean) => {
  const m: Record<string, string> = Object.fromEntries(Object.entries(pages).map(([k, p]) => [k, p.url]));
  for (const [a, t] of Object.entries(aliases)) if (pages[t] && (isAdmin === a.startsWith('admin'))) m[a] = pages[t].url;
  if (!isAdmin) m['register'] = '/register';
  return m;
};

const htmlByFile = Object.fromEntries(Object.entries(documents).map(([file, html]) => [
  file.replace('/src/panels', '').replace(/index\.html$/, ''), html,
]));
type Hit = { name: string; page: Page; isAdmin: boolean; tab?: 'register' };
const byUrl = new Map<string, Hit>();
const byFile = new Map<string, Hit>();
for (const [isAdmin, pages] of [[false, user], [true, admin]] as const) {
  for (const [name, page] of Object.entries(pages)) {
    const hit = { name, page, isAdmin };
    byUrl.set(page.url, hit);
    byFile.set(page.file, hit);
  }
}
byUrl.set('/register', { name: 'index', page: USER_LOGIN, isAdmin: false, tab: 'register' });

/** Returns the canonical readable URL for any current or legacy address. */
export function resolvePanelPath(pathname: string): string | undefined {
  let path: string;
  try { path = decodeURIComponent(pathname); } catch { return undefined; }
  const clean = path.length > 1 ? path.replace(/\/+$/, '') : path;
  if (byUrl.has(clean)) return clean;
  if (clean === '' || clean === '/' || clean === '/index.html') return USER_LOGIN.url;
  if (clean === A) return ADMIN_LOGIN.url;
  const dir = `${clean.replace(/\/index\.html$/i, '')}/`;
  if (byFile.has(dir)) return byFile.get(dir)!.page.url;
  const leaf = clean.split('/').filter(Boolean).at(-1) || 'index';
  const raw = leaf.replace(/\.html$/i, '');
  if (raw === 'register') return '/register';
  const name = aliases[raw] && !(raw === 'login' && path.startsWith(A)) ? aliases[raw] : raw;
  const inAdmin = path.startsWith(`${A}/`) || raw.startsWith('admin-');
  if (inAdmin) return admin[name]?.url ?? (raw === 'login' ? ADMIN_LOGIN.url : undefined);
  return user[name]?.url;
}

export function panelHead(path: string) {
  const canonical = resolvePanelPath(path) || USER_LOGIN.url;
  const hit = byUrl.get(canonical);
  const html = hit ? htmlByFile[hit.page.file] || '' : '';
  let title = (html.match(/<title>(.*?)<\/title>/)?.[1] || 'Predx Profit Pro').replace(/Pred[xX] ?Profit(?! Pro)/gi, 'Predx Profit Pro');
  if (hit?.tab === 'register') title = 'Register • Predx Profit Pro';
  else if (hit && hit.name === 'index' && !hit.isAdmin) title = 'Login • Predx Profit Pro';
  const description = `${title.replace(/ • /g, ' — ')} account portal.`;
  return { meta: [
    { title }, { name: 'description', content: description },
    { property: 'og:title', content: title }, { property: 'og:description', content: description },
    { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary' },
  ] };
}

const legacySlugs: [RegExp, string][] = [...Object.values(user), ...Object.values(admin)]
  .filter((p) => p.file.length > 2 && !p.file.endsWith('predx-admin/'))
  .map((p) => [new RegExp(`(["'\`])${p.file.replace(/\//g, '\\/')}\\1`, 'g'), p.url]);

// Inline <style>/<script> blocks are moved into random-named external files and the
// remaining markup is squeezed onto one line, so "view source" shows only a tiny shell.
const hidden = new Map<string, { body: string; type: string }>();
function hashName(text: string): string {
  let a = 0x811c9dc5, b = 0x1b873593;
  for (let i = 0; i < text.length; i++) {
    const c = text.charCodeAt(i);
    a = Math.imul(a ^ c, 16777619); b = Math.imul(b ^ c, 2246822519);
  }
  return ((a >>> 0).toString(36) + (b >>> 0).toString(36)).slice(0, 12);
}
// Hidden files are spread over 20 random-looking folders; CSS is split into 3 one-line parts.
const FOLDERS = Array.from({ length: 20 }, (_v, i) => hashName('predx-folder-' + i).slice(0, 8));
function stash(body: string, ext: 'css' | 'js'): string {
  const h = hashName(body + ext);
  const folder = FOLDERS[parseInt(h.slice(0, 6), 36) % FOLDERS.length];
  const path = `/${folder}/${h}.${ext}`;
  hidden.set(path, { body, type: ext === 'css' ? 'text/css; charset=utf-8' : 'text/javascript; charset=utf-8' });
  return path;
}
function minifyCss(css: string): string {
  return css.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\s+/g, ' ').replace(/\s*([{};,>])\s*/g, '$1').trim();
}
// Split only between top-level rules so every part is valid CSS and order is kept.
function splitCss(css: string, parts = 3): string[] {
  const cuts: number[] = [];
  let depth = 0;
  for (let i = 0; i < css.length; i++) {
    const c = css[i];
    if (c === '{') depth++;
    else if (c === '}') { depth--; if (depth === 0) cuts.push(i + 1); }
  }
  if (depth !== 0 || cuts.length < parts) return [css];
  const out: string[] = [];
  let start = 0;
  for (let k = 1; k < parts; k++) {
    const end = cuts[Math.floor((cuts.length * k) / parts) - 1]!;
    out.push(css.slice(start, end)); start = end;
  }
  out.push(css.slice(start));
  return out.filter((x) => x.trim());
}
export function hideSource(html: string): string {
  return html
    .replace(/<!--[\s\S]*?-->/g, '')
    .replace(/<style[^>]*>([\s\S]*?)<\/style>/gi, (_m, css: string) =>
      splitCss(minifyCss(css)).map((part) => `<link rel="stylesheet" href="${stash(part, 'css')}">`).join(''))
    .replace(/<script(?![^>]*\bsrc=)([^>]*)>([\s\S]*?)<\/script>/gi, (m, attrs: string, js: string) =>
      /type=["'](?!text\/javascript|module)/i.test(attrs) || !js.trim() ? m : `<script src="${stash(js, 'js')}"></script>`)
    .replace(/>\s+</g, '><')
    .replace(/\s*\n\s*/g, ' ')
    .trim();
}

// Pure string work only: this also runs at module load, where the server runtime forbids I/O objects.
function renderPanel(canonical: string): string | undefined {
  const hit = byUrl.get(canonical);
  const original = hit && htmlByFile[hit.page.file];
  if (!hit || !original) return undefined;
  const { isAdmin } = hit;
  const routes = routeMap(isAdmin ? admin : user, isAdmin);
  const context = `<base href="${isAdmin ? `${A}/` : '/'}"><link rel="icon" type="image/png" href="/favicon.png"><link rel="apple-touch-icon" href="/apple-touch-icon.png"><meta name="application-name" content="Predx Profit Pro"><meta name="apple-mobile-web-app-title" content="Predx Profit Pro"><script>window.__PREDX_PAGE__=${JSON.stringify(hit.name)};window.__PREDX_TAB__=${JSON.stringify(hit.tab || '')};window.__PREDX_ROUTES__=${JSON.stringify(routes)};</script>`;
  const meta = panelHead(canonical).meta.filter(m => 'content' in m).map(m => {
    const attr = 'property' in m ? `property="${m.property}"` : `name="${'name' in m ? m.name : ''}"`;
    return `<meta ${attr} content="${String(m.content).replace(/&/g, '&amp;').replace(/"/g, '&quot;')}">`;
  }).join('');
  let html = original
    .replace('<head>', `<head>${context}${meta}`)
    .replace(/<title>.*?<\/title>/, `<title>${panelHead(canonical).meta[0]!.title}</title>`)
    .replace(/window\.__PREDX_API__="[^"]*"/, 'window.__PREDX_API__="/api/public/predx"')
    .replace(/((?:src|href)=["'])((?:\.\.\/)*)(iUJGQRAJ|sClgTL92|2AkrE7jW|ti7PrelT)\//g,
      (_match, attr: string, _relative: string, folder: string) => `${attr}${isAdmin ? `${A}/` : '/'}${folder}/`)
    .replace(/(["'])([\w-]+)\.html\1/g, (match, quote: string, name: string) =>
      routes[name] ? `${quote}${routes[name]}${quote}` : match);
  for (const [re, to] of legacySlugs) html = html.replace(re, (_m, q: string) => `${q}${to}${q}`);
  return hideSource(html);
}

// Build every page (and its hidden files) once so any server instance can answer /_x/ requests.
const rendered = new Map<string, string>();
for (const path of byUrl.keys()) {
  const html = renderPanel(path);
  if (html) rendered.set(path, html);
}

export function servePanel(request: Request): Response {
  const url = new URL(request.url);
  const asset = hidden.get(url.pathname);
  if (asset) return new Response(asset.body, { headers: { 'content-type': asset.type, 'cache-control': 'public, max-age=3600' } });
  const canonical = resolvePanelPath(url.pathname);
  if (!canonical) return new Response('Page not found', { status: 404 });
  if (url.pathname !== canonical) return new Response(null, {
    status: 308, headers: { location: canonical + url.search, 'cache-control': 'no-cache' },
  });
  const html = rendered.get(canonical);
  if (!html) return new Response('Page not found', { status: 404 });
  return new Response(html, { headers: {
    'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store',
  } });
}
