import { describe, expect, it, vi } from 'vitest';
import { adminPages, userPages, resolvePanelPath, servePanel } from '@/lib/panel-pages';

describe('Panel document routing', () => {
  for (const [name, canonical] of [...Object.entries(userPages), ...Object.entries(adminPages)]) {
    const admin = canonical.startsWith('/predx-admin/');
    const legacy = `${admin ? '/predx-admin/' : '/'}${name}.html`;
    it(`serves ${legacy} at its canonical extension-free address`, async () => {
      expect(resolvePanelPath(legacy)).toBe(canonical);
      const redirect = servePanel(new Request(`https://example.test${legacy}?ref=check`));
      expect(redirect.status).toBe(308);
      expect(redirect.headers.get('location')).toBe(`${canonical}?ref=check`);
      const response = servePanel(new Request(`https://example.test${canonical}`));
      expect(response.status).toBe(200);
      const html = await response.text();
      expect(html).not.toContain('\n');
      expect(html).not.toMatch(/<script(?![^>]*src=)[^>]*>[^<]/);
      const scripts = [...html.matchAll(/src="(\/[\w]{8}\/[\w]+\.js)"/g)].map(m => m[1]!);
      const code = (await Promise.all(scripts.map(s => servePanel(new Request(`https://example.test${s}`)).text()))).join('');
      expect(code).toContain('window.__PREDX_PAGE__=');
      expect(code).toContain('window.__PREDX_API__="/api/public/predx"');
      expect(html).toContain('<base href=');
      expect(html).not.toMatch(/(?:src|href)=["']\.\.\//);
    });
  }
  it('loads without creating requests or responses (the live server forbids that at startup)', async () => {
    vi.resetModules();
    const [OrigRequest, OrigResponse] = [globalThis.Request, globalThis.Response];
    const forbidden = class { constructor() { throw new Error('created at module load'); } };
    globalThis.Request = forbidden as unknown as typeof Request;
    globalThis.Response = forbidden as unknown as typeof Response;
    try {
      await expect(import('@/lib/panel-pages')).resolves.toBeDefined();
    } finally {
      globalThis.Request = OrigRequest;
      globalThis.Response = OrigResponse;
    }
  });
  it('normalizes nested legacy links and preserves unknown-page errors', () => {
    expect(resolvePanelPath('/MoQTbEoJGu/profile.html')).toBe(userPages['profile']);
    expect(resolvePanelPath('/predx-admin/NyBqrXlOnG/admin-deposits.html')).toBe(adminPages['admin-deposits']);
    expect(resolvePanelPath('/MoQTbEoJGu/index.html')).toBe(userPages['dashboard']);
    expect(resolvePanelPath('/missing.html')).toBeUndefined();
    expect(resolvePanelPath('/%ZZ')).toBeUndefined();
    expect(servePanel(new Request('https://example.test/missing.html')).status).toBe(404);
  });
});
