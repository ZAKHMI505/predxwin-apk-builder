import { createFileRoute } from '@tanstack/react-router';
import { panelHead, servePanel } from '@/lib/panel-pages';

export const Route = createFileRoute('/$')({
  head: ({ params }) => panelHead(`/${params._splat || ''}`),
  server: { handlers: { GET: ({ request }) => servePanel(request) } },
  component: () => null,
});
