import { createFileRoute } from "@tanstack/react-router";

type Json = Record<string, unknown>;

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
  "Access-Control-Allow-Headers": "content-type,authorization",
  "Access-Control-Max-Age": "86400",
};

function ok(data: unknown, status = 200) {
  return new Response(JSON.stringify({ ok: true, data }), {
    status,
    headers: { "content-type": "application/json", "cache-control": "no-store", ...CORS },
  });
}

function fail(message: string, status = 400) {
  return new Response(JSON.stringify({ ok: false, error: message }), {
    status,
    headers: { "content-type": "application/json", "cache-control": "no-store", ...CORS },
  });
}

function makeToken() {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

function makeUid() {
  return String(Math.floor(10_000_000 + Math.random() * 89_999_999));
}

function num(v: unknown): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function str(v: unknown): string {
  return typeof v === "string" ? v.trim() : "";
}

async function getDb() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

type Db = Awaited<ReturnType<typeof getDb>>;

async function resolveSession(db: Db, request: Request, kind: "user" | "admin") {
  const header = request.headers.get("authorization") ?? "";
  const token = header.toLowerCase().startsWith("bearer ") ? header.slice(7).trim() : "";
  if (!token) return null;
  const { data } = await db
    .from("sessions")
    .select("token,user_id,admin_id,kind,expires_at")
    .eq("token", token)
    .eq("kind", kind)
    .maybeSingle();
  if (!data) return null;
  if (new Date(data.expires_at).getTime() < Date.now()) return null;
  return data;
}

async function logTxn(db: Db, userId: string, kind: string, amount: number, note: string) {
  await db.from("transactions").insert({ user_id: userId, kind, amount, note });
}

async function setting(db: Db, key: string): Promise<Json> {
  const { data } = await db.from("app_settings").select("value").eq("key", key).maybeSingle();
  return (data?.value ?? {}) as Json;
}

async function uploadDataUrl(db: Db, bucket: string, key: string, dataUrl: string, max: number) {
  if (!dataUrl.startsWith("data:")) return { error: "bad" as const };
  const comma = dataUrl.indexOf(",");
  const mime = dataUrl.slice(5, comma).split(";")[0] || "application/octet-stream";
  const raw = atob(dataUrl.slice(comma + 1));
  if (raw.length > max) return { error: "big" as const };
  const bytes = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
  const ext = (mime.split("/")[1] || "bin").replace(/[^a-z0-9]/gi, "").slice(0, 5) || "bin";
  const path = `${key}.${ext}`;
  const { error } = await db.storage.from(bucket).upload(path, bytes, { contentType: mime, upsert: true });
  return error ? { error: "fail" as const } : { path, mime };
}

async function signed(db: Db, bucket: string, path: string | null | undefined) {
  if (!path) return null;
  const { data } = await db.storage.from(bucket).createSignedUrl(path, 3600);
  return data?.signedUrl ?? null;
}

const DAY = 86_400_000;
const dayKey = (t: number) => new Date(t).toISOString().slice(0, 10); // UTC midnight == 5:00 AM Pakistan time

// Device rule: one account per phone. 2nd account -> warning, continued use -> lock. 3rd account -> lock.
async function deviceCheck(db: Db, user: { id: string; device_warned: boolean; device_warned_at: string | null }, devices: string[], escalate: boolean) {
  const ids = devices.map((d) => d.replace(/[^\w:-]/g, "").slice(0, 80)).filter((d) => d.length >= 8).slice(0, 3);
  if (!ids.length) return "ok";
  const { data: rows } = await db.from("user_devices").select("user_id,created_at").in("device_id", ids);
  const mine = (rows ?? []).filter((r) => r.user_id === user.id).map((r) => Date.parse(r.created_at));
  const myFirst = mine.length ? Math.min(...mine) : Date.now();
  // Only accounts that reached this phone before me count; the phone's first account is never flagged.
  const others = new Set((rows ?? []).filter((r) => r.user_id !== user.id && Date.parse(r.created_at) < myFirst).map((r) => r.user_id));
  await db.from("user_devices").upsert(ids.map((d) => ({ device_id: d, user_id: user.id, last_seen: new Date().toISOString() })), { onConflict: "device_id,user_id", ignoreDuplicates: false });
  if (!others.size) return "ok";
  const lock = async () => { await lockBoth(db, user.id, await selfReferrer(db, user.id)); return "lock"; };
  if (others.size >= 2) return lock();
  if (!user.device_warned) {
    await db.from("app_users").update({ device_warned: true, device_warned_at: new Date().toISOString() }).eq("id", user.id);
    return "warn";
  }
  const since = user.device_warned_at ? Date.now() - new Date(user.device_warned_at).getTime() : Infinity;
  if (escalate || since > 30 * 60_000) return lock();
  return "warn";
}
// Self-referral: account made from a referrer's link on the referrer's own phone. Returns the referrer id.
async function selfReferrer(db: Db, userId: string): Promise<string | null> {
  const { data: me } = await db.from("app_users").select("referred_by").eq("id", userId).maybeSingle();
  if (!me?.referred_by) return null;
  const { data: ref } = await db.from("app_users").select("id").eq("uid", me.referred_by).maybeSingle();
  if (!ref || ref.id === userId) return null;
  const { data: rows } = await db.from("user_devices").select("device_id,user_id").in("user_id", [userId, ref.id]);
  const mine = new Set((rows ?? []).filter((r) => r.user_id === userId).map((r) => r.device_id));
  return (rows ?? []).some((r) => r.user_id === ref.id && mine.has(r.device_id)) ? ref.id : null;
}
async function lockBoth(db: Db, userId: string, refId: string | null) {
  await db.from("app_users").update({ locked: true }).in("id", refId ? [userId, refId] : [userId]);
  await db.from("sessions").delete().in("user_id", refId ? [userId, refId] : [userId]);
}
const devicesOf = (body: Json) => [str(body["device"]), str(body["fp"])];

const PLAN_DAYS = 35;
const dailyFor = (amount: number) => Math.round((amount / 600) * 120);
// Referral: member's first plan (1200+) -> 200, every later plan (1200+) -> 100.
const referralBonus = (amount: number, priorPlans: number) => (amount < 1200 ? 0 : priorPlans === 0 ? 200 : 100);
const AGENT_MIN = 10;
const AGENT_SALARY = 2500;

async function activePlans(db: Db, userId: string) {
  const { data } = await db
    .from("deposits")
    .select("id,amount,reviewed_at,created_at")
    .eq("user_id", userId)
    .eq("status", "accepted")
    .order("reviewed_at", { ascending: true });
  const now = Date.now();
  const all = (data ?? []).map((d) => ({
    deposit_id: d.id,
    amount: Number(d.amount),
    daily: dailyFor(Number(d.amount)),
    days: PLAN_DAYS,
    started_at: d.reviewed_at ?? d.created_at,
  }));
  const ids = all.map((p) => p.deposit_id);
  const { data: watched } = ids.length
    ? await db.from("ads_watches").select("deposit_id,watch_date,reward").in("deposit_id", ids)
    : { data: [] as { deposit_id: string | null; watch_date: string; reward: number }[] };
  const done = new Set((watched ?? []).map((w) => `${w.deposit_id}|${w.watch_date}`));
  const todayKey = dayKey(now);
  // One ad per plan per day (unlocks 5 AM PKT); unwatched ads stack, newest first.
  const ads: { deposit_id: string; ad_date: string; amount: number; daily: number; days: number; started_at: string; watched_today: boolean }[] = [];
  const plans: typeof all = [];
  for (const p of all) {
    const start = Date.parse(dayKey(Date.parse(p.started_at)));
    if (now >= start + PLAN_DAYS * DAY) continue;
    plans.push(p);
    let pendingAny = false;
    for (let t = start; t <= now && t < start + PLAN_DAYS * DAY; t += DAY) {
      const k = dayKey(t);
      if (!done.has(`${p.deposit_id}|${k}`)) { ads.push({ ...p, ad_date: k, watched_today: false }); pendingAny = true; }
    }
    if (!pendingAny) ads.push({ ...p, ad_date: todayKey, watched_today: true });
  }
  ads.sort((a, b) => (a.ad_date < b.ad_date ? 1 : a.ad_date > b.ad_date ? -1 : 0));
  return {
    plans: ads,
    plan_count: plans.length,
    today_earning: (watched ?? []).filter((w) => w.watch_date === todayKey).reduce((a, w) => a + Number(w.reward), 0),
    first_started: plans[0]?.started_at ?? null,
  };
}

async function teamInfo(db: Db, uid: string) {
  const { data: members } = await db
    .from("app_users")
    .select("id,uid,name,created_at")
    .eq("referred_by", uid)
    .order("created_at", { ascending: false })
    .limit(1000);
  const ids = (members ?? []).map((m) => m.id);
  const { data: deps } = ids.length
    ? await db.from("deposits").select("user_id,amount,reviewed_at").eq("status", "accepted").in("user_id", ids).order("reviewed_at")
    : { data: [] as { user_id: string; amount: number; reviewed_at: string | null }[] };
  const list = (members ?? []).map((m) => {
    const mine = (deps ?? []).filter((d) => d.user_id === m.id);
    const invest = mine.reduce((a, d) => a + Number(d.amount), 0);
    const bonus = mine.reduce((a, d, i) => a + referralBonus(Number(d.amount), i), 0);
    const maxPlan = mine.reduce((a, d) => Math.max(a, Number(d.amount)), 0);
    return { uid: m.uid, name: m.name, created_at: m.created_at, invest, bonus, max_plan: maxPlan, has_plan: mine.length > 0 };
  });
  const teamInvest = list.reduce((a, m) => a + m.invest, 0);
  // Agent salary: 10+ members AND every member bought a plan above 1200.
  const salaryOk = list.length >= AGENT_MIN && list.every((m) => m.max_plan > 1200);
  return {
    members: list,
    team_bonus: list.reduce((a, m) => a + m.bonus, 0),
    team_invest: teamInvest,
    buyers: list.filter((m) => m.has_plan).length,
    has_1200_member: list.some((m) => m.max_plan >= 1200),
    weekly_salary: salaryOk ? AGENT_SALARY : 0,
    salary_eligible: salaryOk,
  };
}

// Withdraw limit: needs own plan; after first 3 plan days, needs 1 member with 1200+ plan or only 50% of ad profit.
async function withdrawInfo(db: Db, user: { id: string; balance: number | string }, ap: { first_started: string | null }, team: { has_1200_member: boolean }) {
  const balance = Number(user.balance);
  const { count: everPlan } = await db.from("deposits").select("id", { count: "exact", head: true }).eq("user_id", user.id).eq("status", "accepted");
  if (!everPlan) return { withdrawable: 0, restricted: true, reason: "Withdraw ke liye pehle plan purchase karein" };
  const started = ap.first_started ? Date.parse(ap.first_started) : 0;
  if (!started || Date.now() - started < 3 * DAY || team.has_1200_member) return { withdrawable: balance, restricted: false, reason: "" };
  const [{ data: ads }, { data: wds }] = await Promise.all([
    db.from("ads_watches").select("reward").eq("user_id", user.id),
    db.from("withdrawals").select("amount,status").eq("user_id", user.id).neq("status", "rejected"),
  ]);
  const adTotal = (ads ?? []).reduce((a, r) => a + Number(r.reward), 0);
  const taken = (wds ?? []).reduce((a, r) => a + Number(r.amount), 0);
  const cap = Math.max(0, Math.floor(adTotal * 0.5 - taken));
  return { withdrawable: Math.min(balance, cap), restricted: true, reason: "1 member (Rs 1200+ plan) join karwayein, warna sirf 50% ad profit withdraw hoga" };
}

async function attach(db: Db, userId: string, body: Json) {
  const data = str(body["attachment"]);
  if (!data) return null;
  const name = str(body["file_name"]).replace(/[|]/g, "").slice(0, 120) || "file";
  const up = await uploadDataUrl(db, "chat-files", `${userId}/${Date.now()}`, data, 10_000_000);
  if ("error" in up) return { error: up.error };
  return { path: up.path, type: `${up.mime.startsWith("image/") ? "image" : "file"}|${name}` };
}

async function withAttachments(db: Db, rows: { attachment_path: string | null; attachment_type: string | null }[]) {
  return Promise.all(rows.map(async ({ attachment_path, attachment_type, ...m }) => {
    const [kind, name] = (attachment_type ?? "").split("|");
    const url = await signed(db, "chat-files", attachment_path);
    return { ...m, image: url && kind === "image" ? url : null, file: url && kind === "file" ? name : null, file_url: url && kind === "file" ? url : null };
  }));
}

// ---------------------------------------------------------------- user routes

async function handleUser(db: Db, path: string, request: Request, body: Json): Promise<Response> {
  switch (path) {
    case "auth/register": {
      const name = str(body["name"]);
      const gmail = str(body["gmail"]).toLowerCase();
      const phone = str(body["phone"]);
      const password = str(body["password"]);
      const ref = str(body["ref"]);
      if (name.length < 2 || name.length > 60) return fail("Name 2-60 characters hona chahiye");
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(gmail) || gmail.length > 120)
        return fail("Gmail sahi nahi hai");
      if (password.length < 6 || password.length > 72) return fail("Password kam az kam 6 characters");
      if (phone.length > 25) return fail("Number sahi nahi hai");

      const { data: exists } = await db
        .from("app_users")
        .select("id")
        .eq("gmail", gmail)
        .maybeSingle();
      if (exists) return fail("Yeh Gmail pehle se registered hai");

      const { data: hash } = await db.rpc("predx_hash", { _pw: password });
      let uid = makeUid();
      for (let i = 0; i < 5; i++) {
        const { data: clash } = await db.from("app_users").select("id").eq("uid", uid).maybeSingle();
        if (!clash) break;
        uid = makeUid();
      }
      const { data: created, error } = await db
        .from("app_users")
        .insert({
          uid,
          name,
          gmail,
          phone,
          password_hash: hash as string,
          referred_by: ref || null,
        })
        .select("id,uid,name,gmail")
        .single();
      if (error || !created) return fail("Register nahi ho saka");
      const dv = await deviceCheck(db, { id: created.id, device_warned: false, device_warned_at: null }, devicesOf(body), false);
      if (dv === "lock") return fail("ACCOUNT_LOCKED", 403);

      const token = makeToken();
      await db.from("sessions").insert({ token, user_id: created.id, kind: "user" });
      return ok({ token, user: created, device_warning: dv === "warn" });
    }

    case "auth/login": {
      const gmail = str(body["gmail"]).toLowerCase();
      const password = str(body["password"]);
      if (!gmail || !password) return fail("Gmail aur password dalein");
      const { data: userId } = await db.rpc("predx_verify_user", { _gmail: gmail, _pw: password });
      if (!userId) return fail("Gmail ya password ghalat hai", 401);
      const { data: u } = await db
        .from("app_users")
        .select("id,uid,name,gmail,locked,unlock_notice,device_warned,device_warned_at")
        .eq("id", userId as string)
        .single();
      if (!u || u.locked) return fail("ACCOUNT_LOCKED", 403);
      const dv = await deviceCheck(db, u, devicesOf(body), true);
      if (dv === "lock") return fail("ACCOUNT_LOCKED", 403);
      if (u.unlock_notice) await db.from("app_users").update({ unlock_notice: false }).eq("id", u.id);
      const token = makeToken();
      await db.from("sessions").insert({ token, user_id: userId as string, kind: "user" });
      return ok({ token, user: { id: u.id, uid: u.uid, name: u.name, gmail: u.gmail }, unlocked: u.unlock_notice, device_warning: dv === "warn" });
    }

    case "auth/lock-status": {
      const gmail = str(body["gmail"]).toLowerCase();
      const { data } = await db.from("app_users").select("locked").eq("gmail", gmail).maybeSingle();
      return ok({ locked: Boolean(data?.locked) });
    }

    case "notice":
      return ok(await setting(db, "notice"));

    case "payment-accounts":
      return ok(await setting(db, "payment_accounts"));

    case "auth/lock-status-full": {
      const gmail = str(body["gmail"]).toLowerCase();
      const { data } = await db.from("app_users").select("locked,unlock_notice").eq("gmail", gmail).maybeSingle();
      return ok({ locked: Boolean(data?.locked), unlocked: Boolean(data?.unlock_notice) });
    }

    case "plans": {
      const { data } = await db
        .from("plans")
        .select("id,name,price,daily_return,duration_days,max_daily_withdraw")
        .eq("active", true)
        .order("sort_order");
      return ok(data ?? []);
    }

    default:
      return fail("Route nahi mila", 404);
  }
}

// ----------------------------------------------------- authenticated user ops

async function handleMe(
  db: Db,
  userId: string,
  path: string,
  request: Request,
  body: Json,
): Promise<Response> {
  const { data: user } = await db.from("app_users").select("*").eq("id", userId).single();
  if (!user) return fail("User nahi mila", 404);
  if (user.locked) return fail("ACCOUNT_LOCKED", 403);

  switch (path) {
    case "ping": {
      const dv = await deviceCheck(db, user, devicesOf(body), false);
      if (dv === "lock") return fail("ACCOUNT_LOCKED", 403);
      return ok({ locked: false, device_warning: dv === "warn" });
    }

    case "live-withdrawals": {
      const { data: wds } = await db
        .from("withdrawals")
        .select("user_id,amount,reviewed_at")
        .eq("status", "accepted")
        .order("reviewed_at", { ascending: false })
        .limit(40);
      const ids = [...new Set((wds ?? []).map((w) => w.user_id))];
      const [{ data: users }, { data: deps }] = ids.length
        ? await Promise.all([
            db.from("app_users").select("id,name").in("id", ids),
            db.from("deposits").select("user_id,reviewed_at").eq("status", "accepted").in("user_id", ids),
          ])
        : [{ data: [] as { id: string; name: string }[] }, { data: [] as { user_id: string; reviewed_at: string | null }[] }];
      const cutoff = Date.now() - PLAN_DAYS * DAY;
      const active = new Set((deps ?? []).filter((d) => d.reviewed_at && Date.parse(d.reviewed_at) > cutoff).map((d) => d.user_id));
      const names = new Map((users ?? []).map((u) => [u.id, u.name]));
      const mask = (n: string) => { const [a, b] = n.trim().split(/\s+/); return `${a}${b ? " " + b[0] + "." : ""}***`; };
      return ok((wds ?? []).filter((w) => active.has(w.user_id)).slice(0, 15).map((w) => ({
        name: mask(names.get(w.user_id) ?? "User"), amount: Number(w.amount), at: w.reviewed_at,
      })));
    }

    case "me": {
      const [ap, team] = await Promise.all([activePlans(db, userId), teamInfo(db, user.uid)]);
      const wi = await withdrawInfo(db, user, ap, team);
      return ok({
        id: user.id,
        uid: user.uid,
        name: user.name,
        gmail: user.gmail,
        phone: user.phone,
        locked: user.locked,
        balance: Number(user.balance),
        valid_amount: Number(user.valid_amount),
        withdraw_balance: Number(user.balance),
        withdrawable: wi.withdrawable,
        withdraw_restricted: wi.restricted,
        withdraw_reason: wi.reason,
        plans: ap.plans,
        plan_count: ap.plan_count,
        today_earning: ap.today_earning,
        team_count: team.members.length,
        team_bonus: team.team_bonus,
        weekly_salary: team.weekly_salary,
        is_agent: team.members.length >= AGENT_MIN,
        salary_eligible: team.salary_eligible,
        referred_by: user.referred_by,
        created_at: user.created_at,
      });
    }

    case "deposit": {
      const amount = num(body["amount"]);
      let planId: string | null = str(body["plan_id"]) || null;
      const txn = str(body["txn_id"]);
      const shot = str(body["screenshot"]);
      if (amount <= 0) return fail("Amount sahi nahi hai");
      if (!txn || txn.length > 120) return fail("Transaction ID dalein");
      if (!planId) {
        const { data: matched } = await db
          .from("plans")
          .select("id")
          .eq("price", amount)
          .eq("active", true)
          .maybeSingle();
        planId = matched?.id ?? null;
      }

      let screenshotPath: string | null = null;
      if (shot.startsWith("data:")) {
        const comma = shot.indexOf(",");
        const meta = shot.slice(5, comma);
        const mime = meta.split(";")[0] || "image/jpeg";
        const raw = atob(shot.slice(comma + 1));
        if (raw.length > 8_000_000) return fail("Screenshot bohat bari hai (max 8MB)");
        const bytes = new Uint8Array(raw.length);
        for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
        const ext = mime.includes("png") ? "png" : mime.includes("webp") ? "webp" : "jpg";
        const key = `${userId}/${Date.now()}.${ext}`;
        const { error: upErr } = await db.storage
          .from("payment-proofs")
          .upload(key, bytes, { contentType: mime });
        if (!upErr) screenshotPath = key;
      }

      const { data: dep, error } = await db
        .from("deposits")
        .insert({
          user_id: userId,
          plan_id: planId,
          amount,
          txn_id: txn,
          screenshot_url: screenshotPath,
        })
        .select("id,status,amount,created_at")
        .single();
      if (error) return fail("Request submit nahi hui");
      await logTxn(db, userId, "deposit_request", amount, `Txn ${txn}`);
      return ok(dep);
    }

    case "withdraw": {
      const amount = num(body["amount"]);
      const method = str(body["method"]);
      const accName = str(body["account_name"]);
      const accNo = str(body["account_number"]);
      if (amount <= 0) return fail("Amount sahi nahi hai");
      if (!method || !accName || !accNo) return fail("Saari details bharein");
      if (accNo.length > 40 || accName.length > 80) return fail("Details bohat lambi hain");

      if (amount < 100) return fail("Minimum withdrawal Rs 100 hai");
      const cap = Number(user.balance);
      const [ap, team] = await Promise.all([activePlans(db, userId), teamInfo(db, user.uid)]);
      const wi = await withdrawInfo(db, user, ap, team);
      if (wi.withdrawable < 100 && wi.reason) return fail(wi.reason);
      if (amount > wi.withdrawable) return fail(`Maximum withdraw Rs ${wi.withdrawable.toFixed(0)} hai${wi.reason ? " — " + wi.reason : ""}`);

      const { data: wd, error } = await db
        .from("withdrawals")
        .insert({ user_id: userId, amount, method, account_name: accName, account_number: accNo })
        .select("id,status,amount,created_at")
        .single();
      if (error) return fail("Request submit nahi hui");
      await db
        .from("app_users")
        .update({ balance: cap - amount, withdraw_balance: cap - amount })
        .eq("id", userId);
      await logTxn(db, userId, "withdraw_request", -amount, method);
      return ok(wd);
    }

    case "team": {
      const team = await teamInfo(db, user.uid);
      const { data: claims } = await db
        .from("gift_code_redemptions")
        .select("amount,created_at")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(100);
      return ok({
        referral_code: user.uid,
        ...team,
        member_count: team.members.length,
        is_agent: team.members.length >= AGENT_MIN,
        claims: claims ?? [],
      });
    }

    case "giftcode/redeem": {
      const code = str(body["code"]).toUpperCase();
      if (!code || code.length > 40) return fail("Gift code dalein");
      const { data: gc } = await db
        .from("gift_codes")
        .select("*")
        .eq("code", code)
        .eq("active", true)
        .maybeSingle();
      if (!gc) return fail("Gift code ghalat hai ya expire ho gaya");
      if (gc.uses >= gc.max_uses) return fail("Is code ki limit poori ho chuki hai");
      const { error: redErr } = await db
        .from("gift_code_redemptions")
        .insert({ code_id: gc.id, user_id: userId, amount: gc.amount });
      if (redErr) return fail("Aap yeh code pehle claim kar chuke hain");
      await db.from("gift_codes").update({ uses: gc.uses + 1 }).eq("id", gc.id);
      await db
        .from("app_users")
        .update({
          balance: Number(user.balance) + Number(gc.amount),
          withdraw_balance: Number(user.balance) + Number(gc.amount),
        })
        .eq("id", userId);
      await logTxn(db, userId, "giftcode", Number(gc.amount), code);
      return ok({ amount: Number(gc.amount) });
    }

    case "ads/watch": {
      const ap = await activePlans(db, userId);
      if (!ap.plans.length) return fail("Pehle plan activate karein");
      const wanted = str(body["deposit_id"]);
      const wantedDate = str(body["ad_date"]);
      const idx = Number.isInteger(body["index"]) ? Number(body["index"]) : -1;
      const plan =
        ap.plans.find((p) => p.deposit_id === wanted && p.ad_date === wantedDate && !p.watched_today) ??
        ap.plans.find((p) => p.deposit_id === wanted && !p.watched_today) ??
        (idx >= 0 && ap.plans[idx] && !ap.plans[idx].watched_today ? ap.plans[idx] : undefined) ??
        ap.plans.find((p) => !p.watched_today);
      if (!plan) return fail("Aaj ke saare ads dekh liye gaye hain — naya ad subah 5 baje");
      // Self-referral: first ad is allowed; on the second ad both accounts are locked.
      const refId = await selfReferrer(db, userId);
      if (refId) {
        const { count } = await db.from("ads_watches").select("id", { count: "exact", head: true }).eq("user_id", userId);
        if ((count ?? 0) >= 1) { await lockBoth(db, userId, refId); return fail("ACCOUNT_LOCKED", 403); }
      }
      const reward = plan.daily;
      const { error: watchErr } = await db
        .from("ads_watches")
        .insert({ user_id: userId, reward, deposit_id: plan.deposit_id, watch_date: plan.ad_date });
      if (watchErr) return fail("Is plan ka aaj ka ad pehle hi dekh liya hai");
      const { data: fresh } = await db.from("app_users").select("balance").eq("id", userId).single();
      const nb = Number(fresh?.balance ?? 0) + reward;
      await db.from("app_users").update({ balance: nb, withdraw_balance: nb }).eq("id", userId);
      await logTxn(db, userId, "ads", reward, `Ad Watched — Rs ${plan.amount} Plan`);
      return ok({ reward, plan_amount: plan.amount, deposit_id: plan.deposit_id });
    }

    case "ads/status": {
      const ap = await activePlans(db, userId);
      return ok({ plans: ap.plans, has_plan: ap.plan_count > 0 });
    }

    case "history/deposit": {
      const { data } = await db
        .from("deposits")
        .select("id,amount,txn_id,status,created_at,reviewed_at,plan_id")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(200);
      return ok(data ?? []);
    }

    case "history/withdraw": {
      const { data } = await db
        .from("withdrawals")
        .select("id,amount,method,account_name,account_number,status,created_at,reviewed_at,proof_path")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(200);
      const rows = await Promise.all((data ?? []).map(async ({ proof_path, ...w }) => ({ ...w, proof_url: await signed(db, "payment-proofs", proof_path) })));
      return ok(rows);
    }

    case "history/ads": {
      const { data } = await db
        .from("ads_watches")
        .select("id,watch_date,reward,created_at,deposit_id")
        .eq("user_id", userId)
        .order("watch_date", { ascending: false })
        .limit(200);
      return ok(data ?? []);
    }

    case "history/transactions": {
      const { data } = await db
        .from("transactions")
        .select("id,kind,amount,note,created_at")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(300);
      return ok(data ?? []);
    }

    case "support/list": {
      const { data } = await db
        .from("support_messages")
        .select("id,sender,body,created_at,attachment_path,attachment_type")
        .eq("user_id", userId)
        .order("created_at")
        .limit(200);
      return ok(await withAttachments(db, data ?? []));
    }

    case "support/send": {
      const text = str(body["text"]);
      const att = await attach(db, userId, body);
      if (att && "error" in att) return fail("File upload nahi hui (max 10MB)");
      if ((!text && !att) || text.length > 2000) return fail("Message 1-2000 characters");
      const { data: msg } = await db
        .from("support_messages")
        .insert({ user_id: userId, sender: "user", body: text, attachment_path: att?.path ?? null, attachment_type: att?.type ?? null })
        .select("id")
        .single();
      return ok({ sent: true, id: msg?.id });
    }

    case "change-password": {
      const oldPw = str(body["old_password"]);
      const newPw = str(body["new_password"]);
      if (newPw.length < 6 || newPw.length > 72) return fail("Naya password kam az kam 6 characters");
      const { data: verified } = await db.rpc("predx_verify_user", {
        _gmail: user.gmail,
        _pw: oldPw,
      });
      if (!verified) return fail("Purana password ghalat hai", 401);
      const { data: hash } = await db.rpc("predx_hash", { _pw: newPw });
      await db.from("app_users").update({ password_hash: hash as string }).eq("id", userId);
      await db.from("sessions").delete().eq("user_id", userId);
      return ok({ changed: true });
    }

    case "logout": {
      const header = request.headers.get("authorization") ?? "";
      await db.from("sessions").delete().eq("token", header.slice(7).trim());
      return ok({ out: true });
    }

    default:
      return fail("Route nahi mila", 404);
  }
}

// --------------------------------------------------------------- admin routes

async function handleAdmin(
  db: Db,
  path: string,
  request: Request,
  body: Json,
): Promise<Response> {
  if (path === "admin/login") {
    const gmail = str(body["gmail"]).toLowerCase();
    const password = str(body["password"]);
    if (!gmail || !password) return fail("Gmail aur password dalein");
    const { data: adminId } = await db.rpc("predx_verify_admin", { _gmail: gmail, _pw: password });
    if (!adminId) return fail("Gmail ya password ghalat hai", 401);
    const token = makeToken();
    await db.from("sessions").insert({ token, admin_id: adminId as string, kind: "admin" });
    return ok({ token, gmail });
  }

  const session = await resolveSession(db, request, "admin");
  if (!session) return fail("Unauthorized", 401);

  switch (path) {
    case "admin/stats": {
      const start = new Date();
      start.setUTCHours(0, 0, 0, 0);
      const since = start.toISOString();
      const online = new Date(Date.now() - 15 * 60_000).toISOString();
      const [users, joins, deps, wds, sess, pendDep, pendWd] = await Promise.all([
        db.from("app_users").select("balance,valid_amount"),
        db.from("app_users").select("id", { count: "exact", head: true }).gte("created_at", since),
        db.from("deposits").select("amount,status,created_at,reviewed_at").limit(5000),
        db.from("withdrawals").select("amount,status,created_at").limit(5000),
        db.from("sessions").select("user_id").eq("kind", "user").gt("expires_at", new Date().toISOString()).gte("created_at", online),
        db.from("deposits").select("id", { count: "exact", head: true }).eq("status", "pending"),
        db.from("withdrawals").select("id", { count: "exact", head: true }).eq("status", "pending"),
      ]);
      const D = deps.data ?? [];
      const W = wds.data ?? [];
      const todayD = D.filter((d) => d.created_at >= since);
      const todayW = W.filter((w) => w.created_at >= since);
      const acc = D.filter((d) => d.status === "accepted");
      const cutoff = Date.now() - PLAN_DAYS * 86_400_000;
      return ok({
        total_users: users.data?.length ?? 0,
        pending_deposits: pendDep.count ?? 0,
        pending_withdrawals: pendWd.count ?? 0,
        total_balance: (users.data ?? []).reduce((a, r) => a + Number(r.balance), 0),
        today_deposit: todayD.filter((d) => d.status !== "rejected").reduce((a, d) => a + Number(d.amount), 0),
        today_deposit_count: todayD.length,
        today_withdraw: todayW.filter((w) => w.status !== "rejected").reduce((a, w) => a + Number(w.amount), 0),
        today_withdraw_count: todayW.length,
        today_join: joins.count ?? 0,
        total_online: new Set((sess.data ?? []).map((s) => s.user_id)).size,
        active_plans: acc.filter((d) => new Date(d.reviewed_at ?? d.created_at).getTime() > cutoff).length,
        total_invested: acc.reduce((a, d) => a + Number(d.amount), 0),
        total_deposits: acc.reduce((a, d) => a + Number(d.amount), 0),
        total_withdrawals: W.filter((w) => w.status === "accepted").reduce((a, w) => a + Number(w.amount), 0),
      });
    }

    case "admin/users": {
      const q = str(body["q"]);
      let query = db
        .from("app_users")
        .select("id,uid,name,gmail,phone,balance,valid_amount,withdraw_balance,locked,referred_by,active_plan_id,created_at")
        .order("created_at", { ascending: false })
        .limit(500);
      if (q) query = query.or(`uid.ilike.%${q.replace(/[^\w@.]/g, "")}%,name.ilike.%${q.replace(/[^\w@.]/g, "")}%,gmail.ilike.%${q.replace(/[^\w@.]/g, "")}%`);
      const { data } = await query;
      const [{ data: deps }, { data: ads }] = await Promise.all([
        db.from("deposits").select("user_id,amount,reviewed_at,created_at").eq("status", "accepted").limit(10000),
        db.from("transactions").select("user_id,amount,kind").in("kind", ["ads", "referral_bonus", "giftcode"]).limit(20000),
      ]);
      const cutoff = Date.now() - PLAN_DAYS * 86_400_000;
      return ok((data ?? []).map((u) => {
        const mine = (deps ?? []).filter((d) => d.user_id === u.id);
        return {
          ...u,
          invested: mine.reduce((a, d) => a + Number(d.amount), 0),
          active_plans: mine.filter((d) => new Date(d.reviewed_at ?? d.created_at).getTime() > cutoff).length,
          team_size: (data ?? []).filter((m) => m.referred_by === u.uid).length,
          total_earned: (ads ?? []).filter((t) => t.user_id === u.id).reduce((a, t) => a + Number(t.amount), 0),
        };
      }));
    }

    case "admin/user/lock":
    case "admin/user/unlock": {
      const id = str(body["user_id"]);
      if (!id) return fail("User id chahiye");
      const column = /^\d+$/.test(id) ? "uid" : "id";
      const lock = path.endsWith("/lock");
      await db.from("app_users").update(lock ? { locked: true } : { locked: false, unlock_notice: true, device_warned: false, device_warned_at: null }).eq(column, id);
      if (!lock) {
        const { data: u } = await db.from("app_users").select("id").eq(column, id).maybeSingle();
        if (u) await db.from("user_devices").delete().eq("user_id", u.id);
      }
      return ok({ locked: path.endsWith("/lock") });
    }

    case "admin/wallet/adjust": {
      const id = str(body["user_id"]);
      const amount = num(body["amount"]);
      const reason = str(body["reason"]) || "Admin adjustment";
      const { data: u } = await db
        .from("app_users")
        .select("balance,withdraw_balance")
        .eq("id", id)
        .maybeSingle();
      if (!u) return fail("User nahi mila", 404);
      await db
        .from("app_users")
        .update({
          balance: Number(u.balance) + amount,
          withdraw_balance: Number(u.balance) + amount,
        })
        .eq("id", id);
      await logTxn(db, id, "admin_adjust", amount, reason);
      return ok({ adjusted: amount });
    }

    case "admin/deposits": {
      const status = str(body["status"]) || "pending";
      const { data } = await db
        .from("deposits")
        .select("id,user_id,plan_id,amount,txn_id,screenshot_url,status,created_at")
        .eq("status", status)
        .order("created_at", { ascending: false })
        .limit(300);
      const ids = [...new Set((data ?? []).map((d) => d.user_id))];
      const { data: users } = ids.length
        ? await db.from("app_users").select("id,uid,name,gmail").in("id", ids)
        : { data: [] };
      const map = new Map((users ?? []).map((u) => [u.id, u]));
      const rows = await Promise.all(
        (data ?? []).map(async (d) => {
          let shot: string | null = null;
          if (d.screenshot_url) {
            const { data: signed } = await db.storage
              .from("payment-proofs")
              .createSignedUrl(d.screenshot_url, 3600);
            shot = signed?.signedUrl ?? null;
          }
          return { ...d, screenshot_url: shot, user: map.get(d.user_id) ?? null };
        }),
      );
      return ok(rows);
    }

    case "admin/deposit/review": {
      const id = str(body["id"]);
      const action = str(body["action"]);
      const { data: dep } = await db.from("deposits").select("*").eq("id", id).maybeSingle();
      if (!dep || dep.status !== "pending") return fail("Request nahi mili ya pehle review ho chuki");
      if (action === "accept") {
        const { data: u } = await db
          .from("app_users")
          .select("valid_amount,referred_by")
          .eq("id", dep.user_id)
          .single();
        await db
          .from("app_users")
          .update({
            valid_amount: Number(u?.valid_amount ?? 0) + Number(dep.amount),
            plan_started_at: new Date().toISOString(),
            ...(dep.plan_id ? { active_plan_id: dep.plan_id } : {}),
          })
          .eq("id", dep.user_id);
        await logTxn(db, dep.user_id, "plan_activated", 0, `Rs ${Number(dep.amount)} Plan activated`);
        const { count: prior } = await db.from("deposits").select("id", { count: "exact", head: true }).eq("user_id", dep.user_id).eq("status", "accepted");
        const bonus = referralBonus(Number(dep.amount), prior ?? 0);
        if (bonus > 0 && u?.referred_by) {
          const { data: ref } = await db
            .from("app_users")
            .select("id,balance")
            .eq("uid", u.referred_by)
            .maybeSingle();
          if (ref) {
            const nb = Number(ref.balance) + bonus;
            await db.from("app_users").update({ balance: nb, withdraw_balance: nb }).eq("id", ref.id);
            await logTxn(db, ref.id, "referral_bonus", bonus, `Team bonus — Rs ${Number(dep.amount)} Plan${prior ? " (repeat)" : ""}`);
          }
        }
      } else {
        await logTxn(db, dep.user_id, "deposit_rejected", 0, dep.txn_id ?? "");
      }
      await db
        .from("deposits")
        .update({
          status: action === "accept" ? "accepted" : "rejected",
          reviewed_at: new Date().toISOString(),
        })
        .eq("id", id);
      return ok({ status: action });
    }

    case "admin/withdraws": {
      const status = str(body["status"]) || "pending";
      const { data } = await db
        .from("withdrawals")
        .select("id,user_id,amount,method,account_name,account_number,status,created_at,proof_path")
        .eq("status", status)
        .order("created_at", { ascending: false })
        .limit(300);
      const ids = [...new Set((data ?? []).map((d) => d.user_id))];
      const { data: users } = ids.length
        ? await db
            .from("app_users")
            .select("id,uid,name,gmail,balance,withdraw_balance")
            .in("id", ids)
        : { data: [] };
      const map = new Map((users ?? []).map((u) => [u.id, u]));
      return ok(await Promise.all((data ?? []).map(async ({ proof_path, ...d }) => ({ ...d, proof_url: await signed(db, "payment-proofs", proof_path), user: map.get(d.user_id) ?? null }))));
    }

    case "admin/agents": {
      const { data: all } = await db.from("app_users").select("id,uid,name,referred_by").limit(20000);
      const counts = new Map<string, number>();
      for (const u of all ?? []) if (u.referred_by) counts.set(u.referred_by, (counts.get(u.referred_by) ?? 0) + 1);
      const agents = (all ?? []).filter((u) => (counts.get(u.uid) ?? 0) >= AGENT_MIN);
      const rows = await Promise.all(agents.map(async (a) => {
        const t = await teamInfo(db, a.uid);
        return { uid: a.uid, name: a.name, members: t.members.length, buyers: t.buyers, salary: t.weekly_salary, salary_eligible: t.salary_eligible };
      }));
      return ok(rows.sort((a, b) => b.members - a.members));
    }

    case "admin/upload-image": {
      const up = await uploadDataUrl(db, "payment-proofs", `site/qr-${Date.now()}`, str(body["image"]), 5_000_000);
      if ("error" in up) return fail("Image upload nahi hui (max 5MB)");
      const origin = new URL(request.url).origin;
      return ok({ url: `${origin}/api/public/predx/asset/${up.path.slice(5)}` });
    }

    case "admin/withdraw/review": {
      const id = str(body["id"]);
      const action = str(body["action"]);
      const { data: wd } = await db.from("withdrawals").select("*").eq("id", id).maybeSingle();
      if (!wd || wd.status !== "pending") return fail("Request nahi mili ya pehle review ho chuki");
      if (action === "accept") {
        const shot = str(body["screenshot"]);
        if (shot.startsWith("data:")) {
          const up = await uploadDataUrl(db, "payment-proofs", `withdraw/${wd.id}`, shot, 8_000_000);
          if (!("error" in up)) await db.from("withdrawals").update({ proof_path: up.path }).eq("id", wd.id);
        }
        await logTxn(db, wd.user_id, "withdraw_paid", -Number(wd.amount), wd.method ?? "");
      } else {
        const { data: u } = await db.from("app_users").select("balance").eq("id", wd.user_id).single();
        const nb = Number(u?.balance ?? 0) + Number(wd.amount);
        await db.from("app_users").update({ balance: nb, withdraw_balance: nb }).eq("id", wd.user_id);
        await logTxn(db, wd.user_id, "withdraw_rejected", Number(wd.amount), "Refunded");
      }
      await db
        .from("withdrawals")
        .update({
          status: action === "accept" ? "accepted" : "rejected",
          reviewed_at: new Date().toISOString(),
        })
        .eq("id", id);
      return ok({ status: action });
    }

    case "admin/giftcodes": {
      const { data } = await db
        .from("gift_codes")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(200);
      return ok(data ?? []);
    }

    case "admin/giftcode/create": {
      const code = (str(body["code"]) || makeToken().slice(0, 10)).toUpperCase();
      const amount = num(body["amount"]);
      const maxUses = Math.max(1, Math.floor(num(body["max_uses"]) || 1));
      if (amount <= 0) return fail("Amount sahi nahi hai");
      const { data, error } = await db
        .from("gift_codes")
        .insert({ code, amount, max_uses: maxUses })
        .select("*")
        .single();
      if (error) return fail("Yeh code pehle se mojood hai");
      return ok(data);
    }

    case "admin/giftcode/delete": {
      await db.from("gift_codes").update({ active: false }).eq("id", str(body["id"]));
      return ok({ deleted: true });
    }

    case "admin/giftcode/claims": {
      const { data } = await db
        .from("gift_code_redemptions")
        .select("id,code_id,user_id,amount,created_at")
        .order("created_at", { ascending: false })
        .limit(300);
      const ids = [...new Set((data ?? []).map((d) => d.user_id))];
      const { data: users } = ids.length
        ? await db.from("app_users").select("id,uid,name,gmail").in("id", ids)
        : { data: [] };
      const map = new Map((users ?? []).map((u) => [u.id, u]));
      return ok((data ?? []).map((d) => ({ ...d, user: map.get(d.user_id) ?? null })));
    }

    case "admin/settings/get":
      return ok({
        notice: await setting(db, "notice"),
        payment_accounts: await setting(db, "payment_accounts"),
        salary_rules: await setting(db, "salary_rules"),
        withdraw_rules: await setting(db, "withdraw_rules"),
      });

    case "admin/settings/set": {
      const key = str(body["key"]);
      const allowed = ["notice", "payment_accounts", "salary_rules", "withdraw_rules"];
      if (!allowed.includes(key)) return fail("Yeh setting allowed nahi hai");
      await db
        .from("app_settings")
        .upsert({ key, value: body["value"] as never, updated_at: new Date().toISOString() });
      return ok({ saved: true });
    }

    case "admin/support/threads": {
      const { data } = await db
        .from("support_messages")
        .select("user_id,body,created_at,sender")
        .order("created_at", { ascending: false })
        .limit(500);
      const seen = new Set<string>();
      const threads: unknown[] = [];
      for (const m of data ?? []) {
        if (seen.has(m.user_id)) continue;
        seen.add(m.user_id);
        threads.push(m);
      }
      const ids = [...seen];
      const { data: users } = ids.length
        ? await db.from("app_users").select("id,uid,name,gmail").in("id", ids)
        : { data: [] };
      const map = new Map((users ?? []).map((u) => [u.id, u]));
      return ok(
        threads.map((t) => {
          const m = t as { user_id: string };
          return { ...m, user: map.get(m.user_id) ?? null };
        }),
      );
    }

    case "admin/support/messages": {
      const { data } = await db
        .from("support_messages")
        .select("id,sender,body,created_at,attachment_path,attachment_type")
        .eq("user_id", str(body["user_id"]))
        .order("created_at")
        .limit(300);
      return ok(await withAttachments(db, data ?? []));
    }

    case "admin/support/reply": {
      const text = str(body["text"]);
      const uid = str(body["user_id"]);
      const att = uid ? await attach(db, uid, body) : null;
      if (att && "error" in att) return fail("File upload nahi hui");
      if ((!text && !att) || !uid) return fail("Message aur user chahiye");
      await db.from("support_messages").insert({ user_id: uid, sender: "admin", body: text, attachment_path: att?.path ?? null, attachment_type: att?.type ?? null });
      return ok({ sent: true });
    }

    case "admin/plans": {
      const { data } = await db.from("plans").select("*").order("sort_order");
      return ok(data ?? []);
    }

    case "admin/plan/save": {
      const id = str(body["id"]);
      const row = {
        name: str(body["name"]),
        price: num(body["price"]),
        daily_return: num(body["daily_return"]),
        duration_days: Math.floor(num(body["duration_days"]) || 30),
        max_daily_withdraw: num(body["max_daily_withdraw"]),
        sort_order: Math.floor(num(body["sort_order"])),
        active: body["active"] !== false,
      };
      if (id) await db.from("plans").update(row).eq("id", id);
      else await db.from("plans").insert(row);
      return ok({ saved: true });
    }

    case "admin/logout": {
      await db.from("sessions").delete().eq("token", session.token);
      return ok({ out: true });
    }

    default:
      return fail("Route nahi mila", 404);
  }
}

// ------------------------------------------------------------------ dispatcher

async function dispatch({ request, params }: { request: Request; params: { _splat?: string } }) {
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });

  const path = (params._splat ?? "").replace(/^\/+|\/+$/g, "");
  let body: Json = {};
  if (request.method === "POST") {
    try {
      body = (await request.json()) as Json;
    } catch {
      body = {};
    }
  }

  try {
    const db = await getDb();

    if (path === "health") return ok({ up: true, time: new Date().toISOString() });

    if (path.startsWith("asset/")) {
      const name = path.slice(6);
      if (!/^qr-\d+\.[a-z0-9]{1,5}$/.test(name)) return fail("Not found", 404);
      const url = await signed(db, "payment-proofs", `site/${name}`);
      if (!url) return fail("Not found", 404);
      return new Response(null, { status: 302, headers: { location: url, "cache-control": "public, max-age=1800", ...CORS } });
    }

    if (path.startsWith("admin/")) return await handleAdmin(db, path, request, body);

    const publicPaths = [
      "auth/register",
      "auth/login",
      "auth/lock-status",
      "auth/lock-status-full",
      "notice",
      "payment-accounts",
      "plans",
    ];
    if (publicPaths.includes(path)) return await handleUser(db, path, request, body);

    const session = await resolveSession(db, request, "user");
    if (!session?.user_id) return fail("Unauthorized", 401);
    return await handleMe(db, session.user_id, path, request, body);
  } catch (error) {
    console.error("[predx-api]", error);
    return fail("Server error", 500);
  }
}

export const Route = createFileRoute("/api/public/predx/$")({
  server: { handlers: { GET: dispatch, POST: dispatch, OPTIONS: dispatch } },
});
