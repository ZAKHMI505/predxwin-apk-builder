#!/bin/sh
# Readable bridge sources live here; public copies are obfuscated output. Run after editing a bridge.
cd "$(dirname "$0")/../.."
O="--compact true --control-flow-flattening true --string-array true --string-array-encoding base64 --string-array-threshold 1 --rename-globals false --self-defending false"
bunx javascript-obfuscator src/panel-src/user-bridge.js --output public/sClgTL92/iGV0MCMvn0.js $O
bunx javascript-obfuscator src/panel-src/admin-bridge.js --output public/predx-admin/ti7PrelT/xDpaCBcAiJ.js $O
