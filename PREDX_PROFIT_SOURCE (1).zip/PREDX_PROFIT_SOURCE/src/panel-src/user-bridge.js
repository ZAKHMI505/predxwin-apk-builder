/* PredX Profit — user panel <-> server bridge (HTML/CSS untouched) */
(function () {
  "use strict";
  var ROUTES = window.__PREDX_ROUTES__ || {};
  function R(name) { return ROUTES[name] || "/login"; }

  ["goTo", "goToWithNotif", "menuGo"].forEach(function (name) {
    var original = window[name];
    if (typeof original !== "function") return;
    window[name] = function (target) {
      var key = String(target || "").split("?")[0].split("/").pop().replace(/\.html$/, "");
      var args = Array.prototype.slice.call(arguments); args[0] = ROUTES[key] || target;
      return original.apply(this, args);
    };
  });
  var API_BASE = (window.__PREDX_API__ || "").replace(/\/+$/, "");
  if (!API_BASE) return;

  var TOKEN_KEY = "predx_token", USER_KEY = "loggedUser", LOCK_KEY = "predx_locked";
  var PAGE = window.__PREDX_PAGE__ || "index";
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (_) {} return null; }
  function tok() { return ls(TOKEN_KEY) || ""; }
  function clearTok() { ls(TOKEN_KEY, null); ls(USER_KEY, null); }
  function getLogged() { try { return JSON.parse(ls(USER_KEY) || "null") || {}; } catch (_) { return {}; } }
  function setLogged(u) { ls(USER_KEY, JSON.stringify(u || {})); }
  function toast(msg, type, title) { try { if (typeof window.showToast === "function") window.showToast(msg, type || "info", title); } catch (_) {} }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }

  /* ---------- device id (one account per phone) ---------- */
  function hashStr(t) { var h1 = 0x811c9dc5, h2 = 0x1505; for (var i = 0; i < t.length; i++) { var c = t.charCodeAt(i); h1 = Math.imul(h1 ^ c, 16777619) >>> 0; h2 = (Math.imul(h2, 33) + c) >>> 0; } return h1.toString(16) + h2.toString(16); }
  function deviceIds() {
    var d = ls("predx_dev");
    if (!d) { var b = new Uint8Array(16); try { crypto.getRandomValues(b); } catch (_) { for (var i = 0; i < 16; i++) b[i] = Math.random() * 256; } d = "d-" + Array.prototype.map.call(b, function (x) { return ("0" + x.toString(16)).slice(-2); }).join(""); ls("predx_dev", d); }
    var canv = "";
    try { var c = document.createElement("canvas"); c.width = 200; c.height = 40; var g = c.getContext("2d"); g.textBaseline = "top"; g.font = "16px Arial"; g.fillStyle = "#f60"; g.fillRect(10, 5, 80, 20); g.fillStyle = "#069"; g.fillText("PredX-fp-\u2665", 4, 12); canv = c.toDataURL(); } catch (_) {}
    var n = navigator, sc = screen || {};
    var fp = [n.userAgent, n.language, n.hardwareConcurrency, n.deviceMemory, n.platform, sc.width + "x" + sc.height, sc.colorDepth, window.devicePixelRatio, (Intl.DateTimeFormat().resolvedOptions() || {}).timeZone, canv].join("|");
    return { device: d, fp: "f-" + hashStr(fp) };
  }
  function warnDevice() {
    toast("Is mobile par pehle se ek account hai. Ek mobile par sirf ek account allowed hai — dusra account use kiya to lock ho jayega.", "error", "Warning");
  }

  function kickLocked(email) {
    ls(LOCK_KEY, email || getLogged().email || "locked");
    clearTok();
    if (PAGE !== "index") location.replace(R("index"));
    else showLock();
  }
  function apiCall(method, path, body) {
    var opts = { method: method, headers: { "Content-Type": "application/json" } };
    var t = tok(); if (t) opts.headers["Authorization"] = "Bearer " + t;
    if (body) opts.body = JSON.stringify(body);
    return fetch(API_BASE + "/" + path, opts).then(function (r) {
      return r.json().catch(function () { return { ok: false, error: "Bad response" }; }).then(function (j) {
        if (j && j.ok) return j.data;
        var err = (j && j.error) || "Request failed";
        if (err === "ACCOUNT_LOCKED" && path !== "auth/login") kickLocked();
        else if (/Unauthorized/i.test(err)) { clearTok(); if (PAGE !== "index") location.replace(R("index")); }
        throw new Error(err);
      });
    });
  }

  function toLoggedUser(me, x) {
    x = x || {};
    var cur = getLogged();
    var plans = me.plans || [];
    var team = x.team || null;
    var st = function (s) { return s === "accepted" ? "approved" : s; };
    return Object.assign({}, cur, {
      uid: me.uid, name: me.name, email: me.gmail, whatsapp: me.phone || "",
      referralCode: me.uid, referredBy: me.referred_by || "",
      wallet: Number(me.balance || 0),
      withdrawableWallet: Number(me.withdrawable || 0),
      withdrawReason: me.withdraw_reason || "",
      validAmount: Number(me.valid_amount || 0),
      activePlans: Number(me.plan_count != null ? me.plan_count : plans.length),
      activePlanList: plans.map(function (p) { return { amount: p.amount, daily: p.daily, depositId: p.deposit_id, adDate: p.ad_date, watchedToday: p.watched_today, startedAt: p.started_at }; }),
      todayEarning: Number(me.today_earning || 0),
      teamSize: Number(me.team_count || 0),
      referralBalance: Number(me.team_bonus || 0),
      weeklySalary: Number(me.weekly_salary || 0),
      adsWatched: plans.filter(function (p) { return p.watched_today; }).length,
      joinDate: me.created_at,
      teamList: team ? team.members.map(function (m) {
        return { name: m.name, initial: (m.name || "?").charAt(0).toUpperCase(), online: true,
          joined: new Date(m.created_at).toLocaleDateString("en-GB", { day: "2-digit", month: "short" }),
          plan: Number(m.invest || 0), bonus: Number(m.bonus || 0), level: 1 };
      }) : (cur.teamList || []),
      giftClaims: team ? (team.claims || []).map(function (c) { return { name: me.name, amount: Number(c.amount), code: "", submittedAt: c.created_at, dateIso: c.created_at }; }) : (cur.giftClaims || []),
      deposits: x.deposits ? x.deposits.map(function (d) {
        return { id: d.id, planAmount: Number(d.amount), amount: Number(d.amount), tid: d.txn_id, status: st(d.status),
          submittedAt: d.created_at, dateIso: d.created_at, accountName: me.name,
          approvedDate: d.reviewed_at && d.status === "accepted" ? new Date(d.reviewed_at).toLocaleString("en-GB") : "" };
      }) : (cur.deposits || []),
      withdraws: x.withdraws ? x.withdraws.map(function (w) {
        return { id: w.id, withdrawAmount: Number(w.amount), amount: Number(w.amount), paymentMethod: w.method, method: w.method,
          number: w.account_number, accountNumber: w.account_number, accountName: w.account_name, status: st(w.status),
          approvedDate: w.reviewed_at && w.status === "accepted" ? new Date(w.reviewed_at).toLocaleString("en-GB") : "",
          proofUrl: w.proof_url || "", submittedAt: w.created_at, dateIso: w.created_at };
      }) : (cur.withdraws || []),
      adsHistory: x.ads ? x.ads.map(function (a) {
        return { reward: Number(a.reward), amount: Number(a.reward), planAmount: Math.round(Number(a.reward) * 5),
          watchedAt: a.created_at || a.watch_date, submittedAt: a.created_at || a.watch_date, dateIso: a.created_at || a.watch_date };
      }) : (cur.adsHistory || []),
      transactions: x.txs ? x.txs.filter(function (t) { return /^(referral_bonus|giftcode|admin_adjust)$/.test(t.kind); }).map(function (t) {
        return { type: t.kind === "giftcode" ? "gift" : "bonus", title: t.note || t.kind, amount: Number(t.amount), status: "success", submittedAt: t.created_at, dateIso: t.created_at };
      }) : [],
      chatHistory: [],
      settings: cur.settings || { notifications: true, darkMode: true, sound: true, autoAds: false, biometric: false }
    });
  }

  function syncUser(hint) {
    if (!tok()) return Promise.resolve(null);
    var none = function (v) { return function () { return v; }; };
    var want = function (k) { return hint === "all" || hint === k || (hint === "txs" && /deposits|withdraws|ads|team/.test(k)); };
    return Promise.all([
      apiCall("GET", "me"),
      want("deposits") ? apiCall("GET", "history/deposit").catch(none(null)) : null,
      want("withdraws") ? apiCall("GET", "history/withdraw").catch(none(null)) : null,
      want("ads") ? apiCall("GET", "history/ads").catch(none(null)) : null,
      hint === "txs" ? apiCall("GET", "history/transactions").catch(none(null)) : null,
      want("team") ? apiCall("GET", "team").catch(none(null)) : null
    ]).then(function (r) {
      var u = toLoggedUser(r[0], { deposits: r[1], withdraws: r[2], ads: r[3], txs: r[4], team: r[5] });
      setLogged(u);
      // ads page reads today's watched state from this key
      try {
        var map = {}; u.activePlanList.forEach(function (p, i) { if (p.watchedToday) map["plan_" + i] = true; });
        localStorage.setItem("adsWatched_" + u.uid + "_" + new Date().toISOString().slice(0, 10), JSON.stringify(map));
      } catch (_) {}
      return u;
    });
  }
  window.__predxSync = syncUser;

  function define(name, fn) { try { window[name] = fn; } catch (_) {} }

  /* ---------- auth ---------- */
  function showLock() {
    var email = ls(LOCK_KEY);
    if (!email || typeof window.showLockDialog !== "function") return;
    window.showLockDialog(email, "Account locked by admin");
  }
  define("submitLogin", function () {
    var el = document.getElementById("loginId") || document.getElementById("loginEmail");
    var pw = document.getElementById("loginPass");
    var id = ((el && el.value) || "").trim().toLowerCase();
    var pass = ((pw && pw.value) || "").trim();
    if (!id || !pass) { toast("Please enter Gmail and password", "error"); return; }
    var btn = document.getElementById("loginBtn"); if (btn) btn.disabled = true;
    var wait = 400;
    var dev = deviceIds();
    apiCall("POST", "auth/login", { gmail: id, password: pass, device: dev.device, fp: dev.fp }).then(function (d) {
      ls(LOCK_KEY, null);
      ls(TOKEN_KEY, d.token);
      setLogged({ uid: d.user.uid, name: d.user.name, email: d.user.gmail });
      if (d.unlocked && typeof window.showUnlockDialog === "function") { window.showUnlockDialog(d.user.gmail); wait = 2600; }
      if (d.device_warning) { warnDevice(); wait = Math.max(wait, 3500); }
      return syncUser("all");
    }).then(function () {
      if (wait === 400) toast("Welcome back!", "success");
      setTimeout(function () { location.href = R("dashboard"); }, wait);
    }).catch(function (e) {
      if (btn) btn.disabled = false;
      if (e.message === "ACCOUNT_LOCKED") { ls(LOCK_KEY, id); showLock(); }
      else toast(e.message, "error");
    });
  });

  define("submitRegister", function () {
    var v = function (id) { return ((document.getElementById(id) || {}).value || "").trim(); };
    var btn = document.getElementById("registerBtn"); if (btn) btn.disabled = true;
    var dev = deviceIds(), wait = 500;
    apiCall("POST", "auth/register", { name: v("regName"), gmail: v("regGmail").toLowerCase(), phone: v("regWhatsapp"), password: v("regPass"), ref: v("regReferral"), device: dev.device, fp: dev.fp }).then(function (d) {
      if (d.device_warning) { warnDevice(); wait = 3500; }
      ls(TOKEN_KEY, d.token);
      setLogged({ uid: d.user.uid, name: d.user.name, email: d.user.gmail });
      return syncUser("all");
    }).then(function () {
      if (wait === 500) toast("Account created!", "success");
      setTimeout(function () { location.href = R("dashboard"); }, wait);
    }).catch(function (e) {
      if (btn) btn.disabled = false;
      if (e.message === "ACCOUNT_LOCKED") { ls(LOCK_KEY, v("regGmail").toLowerCase()); if (typeof window.switchTab === "function") window.switchTab("login"); showLock(); }
      else toast(e.message, "error");
    });
  });

  define("confirmLogout", function () {
    apiCall("POST", "logout", {}).catch(function () {}).then(function () { clearTok(); location.href = R("index"); });
  });

  /* ---------- money ---------- */
  define("submitWithdrawal", function () {
    var amount = Number((document.getElementById("wdInputAmount") || {}).value || 0);
    var name = ((document.getElementById("wdInputName") || {}).value || "").trim();
    var number = ((document.getElementById("wdInputNumber") || {}).value || "").trim();
    var method = "";
    try { method = selectedMethod || ""; } catch (_) {}
    method = method || ((document.getElementById("methodTitle") || {}).textContent || "").trim();
    if (!method || /select/i.test(method)) { toast("Please select your payment method", "error", "Missing Info"); return; }
    if (!amount || !name || !number) { toast("Please fill all details", "error", "Missing Info"); return; }
    apiCall("POST", "withdraw", { amount: amount, method: method, account_name: name, account_number: number }).then(function () {
      ls("lastWithdrawal", JSON.stringify({ amount: amount, method: method, number: number, submittedAt: new Date().toISOString(), status: "pending" }));
      try { if (typeof window.showLoadingDialog === "function") window.showLoadingDialog(); } catch (_) {}
      return syncUser("all");
    }).then(function () {
      setTimeout(function () { location.href = R("withdraw-history"); }, 1800);
    }).catch(function (e) { toast(e.message, "error"); });
  });

  define("submitPayment", function () {
    var sel = {}; try { sel = JSON.parse(sessionStorage.getItem("selectedPlan") || "{}"); } catch (_) {}
    var amount = Number(sel.amount || 0);
    var tid = ((document.getElementById("tidInput") || {}).value || "").trim();
    var input = document.getElementById("fileInput");
    var file = input && input.files && input.files[0];
    if (!amount) { toast("Please select a plan first", "error"); return; }
    if (tid.length < 6) { toast("Please enter Transaction ID", "error", "Missing"); return; }
    if (!file) { toast("Please upload screenshot", "error", "Missing"); return; }
    var fr = new FileReader();
    fr.onload = function () {
      apiCall("POST", "deposit", { amount: amount, txn_id: tid, screenshot: String(fr.result || "") }).then(function () {
        try { sessionStorage.removeItem("selectedPlan"); } catch (_) {}
        var ov = document.getElementById("successOverlay"); if (ov) ov.classList.add("active");
        return syncUser("all");
      }).then(function () {
        setTimeout(function () { location.href = R("deposit-history"); }, 1600);
      }).catch(function (e) { toast(e.message, "error"); });
    };
    fr.readAsDataURL(file);
  });

  define("loadPaymentSettings", function () {
    return apiCall("GET", "payment-accounts").then(function (list) {
      var acc = (Array.isArray(list) && list[0]) || null;
      if (!acc) return;
      var s = { method: acc.method, accountName: acc.account_name, accountNumber: acc.account_number, qrImageUrl: acc.qr_image_url || "" };
      try { localStorage.setItem("paymentSettings", JSON.stringify(s)); } catch (_) {}
      if (typeof window.applyPaymentSettings === "function") { window.PAYMENT_SETTINGS = s; window.applyPaymentSettings(s); return; }
      var ids = { adMethod: acc.method, adName: acc.account_name, adNumber: acc.account_number, qrMethodName: acc.method };
      Object.keys(ids).forEach(function (k) { var el = document.getElementById(k); if (el) el.textContent = ids[k]; });
      window.PAYMENT_SETTINGS = { method: acc.method, accountName: acc.account_name, accountNumber: acc.account_number };
    }).catch(function () {});
  });

  define("redeemGift", function () {
    var code = ((document.getElementById("giftInput") || {}).value || "").trim().toUpperCase();
    if (!code) { toast("Please enter gift code", "error"); return; }
    apiCall("POST", "giftcode/redeem", { code: code }).then(function (d) {
      var el = document.getElementById("giftInput"); if (el) el.value = "";
      var sa = document.getElementById("sdAmount"); if (sa) sa.textContent = "Rs " + d.amount;
      var ov = document.getElementById("successOverlay"); if (ov) ov.classList.add("active");
      return syncUser("all").then(refresh);
    }).catch(function (e) { toast(e.message, "error"); });
  });

  define("finishAd", function (idx) {
    var u = getLogged();
    var p = (u.activePlanList || [])[idx] || {};
    apiCall("POST", "ads/watch", { deposit_id: p.depositId || "", ad_date: p.adDate || "", index: idx }).then(function (d) {
      try { if (ACTIVE_PLANS[idx]) ACTIVE_PLANS[idx].watchedToday = true; } catch (_) {}
      try { saveWatchedMap(u.uid, idx); } catch (_) {}
      var rd = document.getElementById("rdReward"); if (rd) rd.textContent = "Rs " + Number(d.reward).toLocaleString("en-IN");
      var rs = document.getElementById("rdSub"); if (rs) rs.textContent = "Rs " + Number(d.plan_amount).toLocaleString("en-IN") + " Plan Reward";
      var ov = document.getElementById("rewardOverlay"); if (ov) ov.classList.add("active");
      try { render(); } catch (_) {}
      toast("+Rs " + Number(d.reward).toLocaleString("en-IN") + " added to wallet!", "success", "Reward Earned");
      syncUser("ads").then(function () { setTimeout(rebuildAds, 1500); });
    }).catch(function (e) { toast(e.message, "error"); try { render(); } catch (_) {} });
  });

  define("submitPassword", function () {
    var g = function (id) { return (document.getElementById(id) || {}).value || ""; };
    if (g("newPass") !== g("confirmPass")) { toast("New password does not match", "error"); return; }
    apiCall("POST", "change-password", { old_password: g("oldPass"), new_password: g("newPass") }).then(function () {
      toast("Password changed — please login again", "success");
      clearTok(); setTimeout(function () { location.href = R("index"); }, 1200);
    }).catch(function (e) { toast(e.message, "error"); });
  });

  /* ---------- live chat (original bubbles via appendMessage) ---------- */
  var shown = {};
  function chatTime(iso) { var d = new Date(iso); var h = d.getHours(), m = String(d.getMinutes()).padStart(2, "0"); return (h % 12 || 12) + ":" + m + " " + (h >= 12 ? "PM" : "AM"); }
  function loadChat() {
    return apiCall("GET", "support/list").then(function (msgs) {
      if (typeof window.appendMessage !== "function") return;
      msgs.forEach(function (m) {
        if (shown[m.id]) return; shown[m.id] = 1;
        var html = esc(m.body).replace(/\n/g, "<br>");
        if (m.file_url) html = '<a href="' + esc(m.file_url) + '" target="_blank" rel="noopener" style="color:inherit">Open file</a>' + (html ? "<br>" + html : "");
        window.appendMessage(m.sender === "user" ? "user" : "bot", html, { noSave: true, time: chatTime(m.created_at), image: m.image || "", file: m.file || "" });
      });
    }).catch(function () {});
  }
  define("sendMessage", function () {
    var el = document.getElementById("msgInput");
    var txt = (el && el.value || "").trim();
    if (!txt) return;
    el.value = ""; try { autoResize(el); } catch (_) {}
    apiCall("POST", "support/send", { text: txt }).then(function (d) {
      if (d && d.id) shown[d.id] = 1;
      window.appendMessage("user", esc(txt).replace(/\n/g, "<br>"), { noSave: true });
    }).catch(function (e) { el.value = txt; toast(e.message, "error"); });
  });

  function sendAttachment(input, isImage) {
    var file = input && input.files && input.files[0];
    if (!file) return;
    var max = isImage ? 5 : 10;
    if (file.size > max * 1024 * 1024) { toast((isImage ? "Image" : "File") + " too large (max " + max + "MB)", "error", "Too Large"); input.value = ""; return; }
    var fr = new FileReader();
    fr.onload = function () {
      toast("Uploading...", "info", "Please wait");
      apiCall("POST", "support/send", { text: "", attachment: String(fr.result || ""), file_name: file.name }).then(function () {
        toast((isImage ? "Image" : "File") + " sent!", "success", "Uploaded");
        loadChat();
      }).catch(function (e) { toast(e.message, "error"); });
    };
    fr.readAsDataURL(file);
    input.value = "";
  }
  function wireChatUploads() {
    define("handleImage", function (input) { sendAttachment(input, true); });
    define("handleFile", function (input) { sendAttachment(input, false); });
  }

  /* ---------- ads page: rebuild stacked list (one card per pending day) ---------- */
  function rebuildAds() {
    var u = getLogged();
    try {
      ACTIVE_PLANS = (u.activePlanList || []).map(function (p) { return { amount: p.amount || 0, daily: p.daily || 0, watchedToday: !!p.watchedToday }; });
      render();
    } catch (_) {}
  }

  /* ---------- dashboard live withdrawals (real active-plan users + filler) ---------- */
  var FAKE = ["Ahmed K.", "Sara M.", "Bilal R.", "Fatima N.", "Usman T.", "Ayesha S.", "Hamza A.", "Zainab H.", "Ali R.", "Hira F.", "Imran Q.", "Maryam I.", "Danish J.", "Noor A.", "Kashif M.", "Sana B."];
  var AMTS = [600, 1200, 1500, 2400, 3000, 4800, 5800, 8000, 12000, 15500, 25000];
  function ago(ms) { var m = Math.max(1, Math.round(ms / 60000)); if (m < 60) return m + " minute" + (m > 1 ? "s" : "") + " ago"; var h = Math.round(m / 60); return h + " hour" + (h > 1 ? "s" : "") + " ago"; }
  function lwItem(name, amount, when) {
    return '<div class="lw-item"><div class="lw-avatar">' + esc(name.charAt(0).toUpperCase()) + '</div><div class="lw-info"><div class="lw-name">' + esc(name) + '</div><div class="lw-time">' + esc(when) + '</div></div><div class="lw-amount">Rs ' + Number(amount).toLocaleString("en-IN") + '<div class="lw-status"><span class="dot"></span>Paid</div></div></div>';
  }
  function wireLiveWithdrawals() {
    var box = document.querySelector(".live-withdrawals");
    if (!box) return;
    var size = Math.max(4, box.querySelectorAll(".lw-item").length);
    var feed = [];
    function fake(offsetMin) { var n = FAKE[Math.floor(Math.random() * FAKE.length)] + "***"; return { name: n, amount: AMTS[Math.floor(Math.random() * AMTS.length)], at: Date.now() - offsetMin * 60000 }; }
    function draw() { box.innerHTML = feed.slice(0, size).map(function (f) { return lwItem(f.name, f.amount, ago(Date.now() - f.at)); }).join(""); }
    apiCall("GET", "live-withdrawals").catch(function () { return []; }).then(function (real) {
      var reals = (real || []).map(function (r) { return { name: r.name, amount: r.amount, at: Date.parse(r.at) || Date.now() }; });
      for (var i = 0; i < size; i++) feed.push(fake(2 + i * 6 + Math.floor(Math.random() * 5)));
      feed = feed.concat(reals).sort(function (a, b) { return b.at - a.at; });
      draw();
      var queue = reals.slice();
      setInterval(function () {
        var next = queue.length && Math.random() < 0.5 ? queue.shift() : fake(0);
        feed.unshift({ name: next.name, amount: next.amount, at: Date.now() });
        draw();
      }, 9000);
    });
  }

  /* ---------- withdraw history: payment screenshot button ---------- */
  function wireProofButton() {
    if (typeof window.openDetail !== "function") return;
    var orig = window.openDetail;
    window.openDetail = function (idx) {
      orig.apply(this, arguments);
      try {
        var w = WITHDRAWS[idx];
        var src = (getLogged().withdraws || []).filter(function (x) { return String(x.id) === String(w.tid); })[0];
        var body = document.getElementById("ddBody");
        if (!src || !src.proofUrl || !body) return;
        var btn = document.createElement("button");
        btn.className = "dd-close-btn approved";
        btn.style.marginTop = "12px"; btn.style.width = "100%";
        btn.innerHTML = '<svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg><span>Payment Screenshot</span>';
        btn.onclick = function (e) {
          e.stopPropagation();
          var ov = document.createElement("div");
          ov.style.cssText = "position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.88);display:flex;align-items:center;justify-content:center;padding:16px";
          ov.innerHTML = '<img src="' + esc(src.proofUrl) + '" alt="Payment screenshot" style="max-width:100%;max-height:100%;border-radius:12px">';
          ov.onclick = function () { ov.remove(); };
          document.body.appendChild(ov);
        };
        body.appendChild(btn);
      } catch (_) {}
    };
  }

  /* ---------- dashboard notice ---------- */
  function wireNotice() {
    var ov = document.getElementById("updateOverlay");
    if (!ov) return;
    apiCall("GET", "notice").then(function (n) {
      if (!n || !n.enabled) return;
      var t = document.getElementById("udTitle"); if (t) t.textContent = n.title || "Update";
      var b = document.getElementById("udBody"); if (b) b.textContent = n.body || "";
      var seenKey = "dismissedNotice_" + (n.title || "x");
      if (ls(seenKey)) return;
      ov.classList.add("active");
      ov.addEventListener("click", function () { ls(seenKey, "1"); });
    }).catch(function () {});
  }

  function refresh() {
    try { (0, eval)("typeof user!=='undefined'&&(user=JSON.parse(localStorage.getItem('loggedUser')||'null')||user)"); } catch (_) {}
    if (PAGE === "ads") rebuildAds();
    ["loadUserData", "renderProfile", "loadTransactions", "loadDeposits", "loadWithdraws", "loadAdsHistory", "loadMembers"].forEach(function (f) {
      try { if (typeof window[f] === "function") window[f](); } catch (_) {}
    });
    var ref = document.getElementById("refLink");
    var u = getLogged();
    if (ref && u.referralCode) ref.value = location.origin + "/register?ref=" + encodeURIComponent(u.referralCode);
  }

  function onReady(fn) { if (document.readyState !== "loading") setTimeout(fn, 0); else document.addEventListener("DOMContentLoaded", fn); }

  onReady(function () {
    if (PAGE === "index") {
      var q = new URLSearchParams(location.search);
      var refCode = q.get("ref");
      if (refCode) { var r = document.getElementById("regReferral"); if (r) r.value = refCode; }
      if ((window.__PREDX_TAB__ === "register" || refCode) && typeof window.switchTab === "function") setTimeout(function () { window.switchTab("register"); }, 300);
      if (tok()) { location.replace(R("dashboard")); return; }
      var locked = ls(LOCK_KEY);
      if (locked && locked.indexOf("@") > 0) {
        apiCall("POST", "auth/lock-status-full", { gmail: locked }).then(function (s) {
          if (s && s.locked) showLock();
          else { ls(LOCK_KEY, null); if (s && s.unlocked && typeof window.showUnlockDialog === "function") window.showUnlockDialog(locked); }
        }).catch(function () {});
      }
      return;
    }
    if (!tok()) { location.replace(R("index")); return; }
    var hint = "all";
    if (PAGE === "transactions") hint = "txs";
    else if (PAGE === "ads" || PAGE === "ads-history") hint = "ads";
    else if (PAGE === "team") hint = "team";
    syncUser(hint).then(function (u) {
      if (!u) return;
      refresh();
      wireNotice();
      if (PAGE === "customer") { wireChatUploads(); setTimeout(loadChat, 600); setInterval(loadChat, 4000); }
      if (PAGE === "dashboard") wireLiveWithdrawals();
      if (PAGE === "withdraw-history") wireProofButton();
      if (PAGE === "active") window.loadPaymentSettings();
    }).catch(function () {});
    // live lock check: kicked out within seconds of admin lock
    var pingDev = deviceIds(), warned = false;
    function ping() { if (tok()) apiCall("POST", "ping", pingDev).then(function (d) { if (d && d.device_warning && !warned) { warned = true; warnDevice(); } }).catch(function () {}); }
    ping(); setInterval(ping, 4000);
  });
})();
