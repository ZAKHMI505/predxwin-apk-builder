/* PredX Profit — admin panel ↔ server bridge */
(function () {
  "use strict";
  var navigationNames = ["goTo", "goToWithNotif", "menuGo"];
  navigationNames.forEach(function (name) {
    var original = window[name];
    if (typeof original !== "function") return;
    window[name] = function (target) {
      var key = String(target || "").split("/").pop().replace(/\.html$/, "");
      var route = (window.__PREDX_ROUTES__ || {})[key] || target;
      var args = Array.prototype.slice.call(arguments); args[0] = route;
      return original.apply(this, args);
    };
  });
  var ROUTES = window.__PREDX_ROUTES__ || {};
  function R(n) { return ROUTES[n] || "/predx-admin/login"; }
  var API_BASE = (window.__PREDX_API__ || "").replace(/\/+$/, "");
  if (!API_BASE) return;

  var TOK = "predx_admin_token";
  function tok() { try { return localStorage.getItem(TOK) || ""; } catch (_) { return ""; } }
  function saveTok(t) { try { localStorage.setItem(TOK, t); localStorage.setItem("adminLoggedIn", "true"); } catch (_) {} }
  function clearTok() { try { localStorage.removeItem(TOK); localStorage.removeItem("adminLoggedIn"); } catch (_) {} }

  function toast(msg, type) {
    try { if (typeof window.showToast === "function") window.showToast(msg, type || "info"); else console.log("[admin]", msg); } catch (_) {}
  }

  function call(method, path, body) {
    var opts = { method: method, headers: { "Content-Type": "application/json" } };
    var t = tok(); if (t) opts.headers["Authorization"] = "Bearer " + t;
    if (body) opts.body = JSON.stringify(body);
    return fetch(API_BASE + "/" + path.replace(/^\/+/, ""), opts).then(function (r) {
      return r.json().catch(function () { return { ok: false, error: "Bad response" }; }).then(function (j) {
        if (j && j.ok) return j.data;
        var e = (j && j.error) || "Request failed";
        if (/Unauthorized/i.test(e)) { clearTok(); if (window.__PREDX_PAGE__ !== "index") location.href = R("index"); }
        throw new Error(e);
      });
    });
  }
  window.__predxAdminCall = call;

  function def(name, fn) { try { window[name] = fn; } catch (_) {} }

  def("submitAdminLogin", function () {
    var e = ((document.getElementById("adminEmail") || {}).value || "").trim().toLowerCase();
    var p = ((document.getElementById("adminPass") || {}).value || "").trim();
    if (!e || !p) { toast("Email aur password dalein", "error"); return; }
    var btn = document.getElementById("loginBtn"); if (btn) btn.classList.add("loading");
    call("POST", "admin/login", { gmail: e, password: p }).then(function (d) {
      saveTok(d.token);
      try { localStorage.setItem("adminEmail", d.gmail); localStorage.setItem("adminName", "Admin"); localStorage.setItem("adminRole", "Super Admin"); } catch (_) {}
      toast("Welcome Admin!", "success");
      setTimeout(function () { location.href = R("admin-dashboard"); }, 400);
    }).catch(function (err) {
      if (btn) btn.classList.remove("loading");
      toast(err.message, "error");
    });
  });

  def("logoutAdmin", function () {
    call("POST", "admin/logout", {}).catch(function(){}).then(function () { clearTok(); location.href = R("index"); });
  });

  /* ---- data normalizers ---- */
  function userShape(u) {
    return {
      id: u.id, uid: u.uid, name: u.name, email: u.gmail,
      online: true, locked: !!u.locked,
      wallet: Number(u.balance || 0),
      invested: Number(u.invested || 0),
      withdrawable: Number(u.balance || 0),
      dashboard: Number(u.balance || 0),
      teamSize: Number(u.team_size || 0), salary: 0, totalEarned: Number(u.total_earned || 0),
      activePlans: Number(u.active_plans || 0),
      joinDate: u.created_at
    };
  }
  function depShape(d) {
    return {
      id: d.id, uid: d.user ? d.user.uid : "", name: d.user ? d.user.name : "",
      amount: Number(d.amount),
      plan: "Rs " + Number(d.amount).toLocaleString("en-IN") + " Plan",
      tid: d.txn_id, status: d.status === "accepted" ? "success" : d.status,
      screenshot: d.screenshot_url || "",
      submittedAt: d.created_at
    };
  }
  function dmy(iso) { var d = new Date(iso); return String(d.getDate()).padStart(2, "0") + "/" + String(d.getMonth() + 1).padStart(2, "0") + "/" + d.getFullYear(); }
  function hms(iso) { var d = new Date(iso); var h = d.getHours(); return String(h % 12 || 12).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0") + " " + (h >= 12 ? "pm" : "am"); }
  function wdShape(w) {
    return {
      id: w.id, uid: w.user ? w.user.uid : "", name: w.user ? w.user.name : "",
      amount: Number(w.amount), method: w.method,
      paymentMethod: w.method, tid: w.id,
      number: w.account_number, accountNumber: w.account_number, accountName: w.account_name,
      date: dmy(w.created_at), time: hms(w.created_at),
      dashboard: w.user ? Number(w.user.balance || 0) : 0,
      adminSS: w.proof_url || "", screenshot: w.proof_url || "",
      status: w.status === "accepted" ? "success" : w.status,
      submittedAt: w.created_at
    };
  }

  /* ---- override API object so existing page code works ---- */
  var ENDPOINT_MAP = {
    "/admin/users": function () { return call("POST", "admin/users", {}).then(function (list) { var showL = window.__PX_SHOW_LOCKED === true; window.__PX_LOCKED_N = list.filter(function (u) { return u.locked; }).length; setTimeout(lockBtnLabel, 0); return { users: list.filter(function (u) { return showL ? u.locked : !u.locked; }).map(userShape) }; }); },
    "/admin/deposits": function () { return call("POST", "admin/deposits", { status: "accepted" }).then(function (list) { return { deposits: list.map(depShape) }; }); },
    "/admin/deposits/pending": function () { return call("POST", "admin/deposits", { status: "pending" }).then(function (list) { return { deposits: list.map(depShape) }; }); },
    "/admin/withdraws": function () { return call("POST", "admin/withdraws", { status: "accepted" }).then(function (list) { return { withdraws: list.map(wdShape) }; }); },
    "/admin/withdraws/pending": function () { return call("POST", "admin/withdraws", { status: "pending" }).then(function (list) { return { withdraws: list.map(wdShape) }; }); },
    "/admin/gifts": function () { return call("POST", "admin/giftcodes", {}).then(function (list) { return { codes: list.map(function (g) { return { code: g.code, amount: Number(g.amount), maxMembers: g.max_uses, claimed: g.uses, planFilter: "all", planLabel: "All Plans", created: g.created_at, status: g.active ? "active" : "expired" }; }) }; }); },
    "/admin/profile": function () { return Promise.resolve({ profile: { name: "Admin", email: localStorage.getItem("adminEmail") || "", role: "Super Admin" } }); },
    "/admin/stats": function () { return call("POST", "admin/stats", {}).then(function (s) { return { todayDeposit: s.today_deposit, todayDepositCount: s.today_deposit_count, todayWithdraw: s.today_withdraw, todayWithdrawCount: s.today_withdraw_count, todayJoin: s.today_join, totalDeposits: s.total_deposits, totalWithdrawals: s.total_withdrawals, totalInvested: s.total_invested, totalOnline: s.total_online, activePlansTotal: s.active_plans, totalUsers: s.total_users, pendingDeposits: s.pending_deposits, pendingWithdrawals: s.pending_withdrawals }; }); },
    "/admin/agents": function () { return call("POST", "admin/agents", {}).then(function (list) { return { agents: list }; }); },
    "/admin/updates": function () { return call("POST", "admin/settings/get", {}).then(function (s) { var n = s.notice || {}; return { updates: n.title ? [{ id: "notice", title: n.title, version: "1.0", body: n.body, createdAt: new Date().toISOString() }] : [] }; }); }
  };

  function matchDynamic(ep) {
    var m;
    if ((m = ep.match(/^\/admin\/users\/([^/]+)\/(lock|unlock)$/))) return { action: m[2], uid: m[1] };
    if ((m = ep.match(/^\/admin\/deposits\/([^/]+)\/(approve|reject)$/))) return { action: "dep_" + m[2], id: m[1] };
    if ((m = ep.match(/^\/admin\/withdraws\/([^/]+)\/(approve|reject)$/))) return { action: "wd_" + m[2], id: m[1] };
    if ((m = ep.match(/^\/admin\/gifts\/([^/]+)\/claims$/))) return { action: "claims", code: m[1] };
    if ((m = ep.match(/^\/admin\/gifts\/([^/]+)$/))) return { action: "del_gift", code: m[1] };
    return null;
  }

  var ADMIN_API = {
    call: function (ep, method, body) {
      try {
        if (method === "GET" || !method) {
          if (ENDPOINT_MAP[ep]) return ENDPOINT_MAP[ep]().then(function (d) { return { success: true, data: d }; }).catch(function (e) { return { success: false, error: e.message }; });
        }
        var dyn = matchDynamic(ep);
        if (dyn) {
          var pr;
          if (dyn.action === "lock" || dyn.action === "unlock") {
            pr = call("POST", "admin/user/" + dyn.action, { user_id: dyn.uid });
          } else if (dyn.action === "dep_approve" || dyn.action === "dep_reject") {
            pr = call("POST", "admin/deposit/review", { id: dyn.id, action: dyn.action === "dep_approve" ? "accept" : "reject" });
          } else if (dyn.action === "wd_approve" || dyn.action === "wd_reject") {
            pr = call("POST", "admin/withdraw/review", { id: dyn.id, action: dyn.action === "wd_approve" ? "accept" : "reject", screenshot: (body && body.screenshot) || "" });
          } else if (dyn.action === "del_gift") {
            pr = call("POST", "admin/giftcode/delete", { id: dyn.code });
          } else if (dyn.action === "claims") {
            pr = call("POST", "admin/giftcode/claims", {}).then(function (list) { return { claims: list }; });
          } else {
            pr = Promise.resolve({});
          }
          return pr.then(function (d) { return { success: true, data: d }; }).catch(function (e) { return { success: false, error: e.message }; });
        }
        if (method === "POST" && ep === "/admin/gifts") {
          return call("POST", "admin/giftcode/create", { code: body.code, amount: body.amount, max_uses: body.maxMembers || 1 }).then(function (d) { return { success: true, data: d }; }).catch(function (e) { return { success: false, error: e.message }; });
        }
        if (method === "POST" && ep === "/admin/updates") {
          return call("POST", "admin/settings/set", { key: "notice", value: { enabled: true, title: body.title, body: body.body, button_text: "OK" } }).then(function (d) { return { success: true, data: d }; }).catch(function (e) { return { success: false, error: e.message }; });
        }
        if (method === "POST" && ep === "/admin/settings") {
          return Promise.resolve({ success: true, data: {} });
        }
        if (method === "POST" && ep === "/auth/admin-login") {
          return call("POST", "admin/login", body).then(function (d) { saveTok(d.token); return { success: true, data: { token: d.token, admin: { email: d.gmail, name: "Admin", role: "Super Admin" } } }; }).catch(function (e) { return { success: false, error: e.message }; });
        }
      } catch (e) { return Promise.resolve({ success: false, error: e.message }); }
      return Promise.resolve({ success: false, error: "Not routed: " + ep });
    },
    get: function (ep) { return this.call(ep, "GET"); },
    post: function (ep, body) { return this.call(ep, "POST", body); },
    put: function (ep, body) { return this.call(ep, "PUT", body); }
  };

  function wire() {
    window.ADMIN_API = ADMIN_API;
    if (window.ADMIN_API_CONFIG) {
      window.ADMIN_API_CONFIG.baseURL = API_BASE;
    }
    if (window.ADMIN_APP_MODE) {
      window.ADMIN_APP_MODE.DEMO_MODE = false;
    }
  }
  wire();

  /* ---- override admin-wallet save ---- */
  function overrideWalletSave() {
    var btn = document.getElementById("saveBtn"); if (!btn) return;
    btn.addEventListener("click", function (ev) {
      ev.preventDefault(); ev.stopPropagation();
      var payload = [{
        qr_image_url: ((document.getElementById("qrUrl") || {}).value || "").trim(),
        method: (document.getElementById("bankName") || {}).value || "Easypaisa",
        account_name: (document.getElementById("accName") || {}).value || "",
        account_number: (document.getElementById("accNumber") || {}).value || (document.getElementById("iban") || {}).value || ""
      }];
      call("POST", "admin/settings/set", { key: "payment_accounts", value: payload }).then(function () {
        toast("Payment account save ho gaya", "success");
      }).catch(function (e) { toast(e.message, "error"); });
    }, true);
  }

  function wireQrUpload() {
    var url = document.getElementById("qrUrl"); if (!url) return;
    var file = document.createElement("input");
    file.type = "file"; file.accept = "image/*"; file.style.display = "none";
    var btn = document.createElement("button");
    btn.type = "button"; btn.className = url.className; btn.textContent = "Upload QR Image";
    btn.style.cssText = "margin-top:8px;cursor:pointer;text-align:center;font-weight:800";
    btn.onclick = function () { file.click(); };
    file.onchange = function () {
      var f = file.files && file.files[0]; if (!f) return;
      if (f.size > 5 * 1024 * 1024) { toast("Image 5MB se choti honi chahiye", "error"); return; }
      var fr = new FileReader();
      btn.textContent = "Uploading...";
      fr.onload = function () {
        call("POST", "admin/upload-image", { image: String(fr.result || "") }).then(function (d) {
          url.value = d.url;
          try { if (typeof window.updateQRPreview === "function") window.updateQRPreview(); } catch (_) {}
          url.dispatchEvent(new Event("input", { bubbles: true }));
          toast("QR upload ho gaya — Save dabayein", "success");
        }).catch(function (e) { toast(e.message, "error"); }).then(function () { btn.textContent = "Upload QR Image"; file.value = ""; });
      };
      fr.readAsDataURL(f);
    };
    url.parentNode.insertBefore(btn, url.nextSibling);
    url.parentNode.insertBefore(file, btn);
    // load saved account from server
    call("POST", "admin/settings/get", {}).then(function (s) {
      var a = (s.payment_accounts && s.payment_accounts[0]) || null; if (!a) return;
      var set = function (id, v) { var el = document.getElementById(id); if (el && v) el.value = v; };
      set("bankName", a.method); set("accName", a.account_name); set("accNumber", a.account_number); set("qrUrl", a.qr_image_url);
      try { if (typeof window.updateQRPreview === "function") window.updateQRPreview(); } catch (_) {}
    }).catch(function () {});
  }

  /* ---- support chat: fill the original CHATS list from server ---- */
  function hm(iso) { var d = new Date(iso); var h = d.getHours(); return (h % 12 || 12) + ":" + String(d.getMinutes()).padStart(2, "0") + " " + (h >= 12 ? "PM" : "AM"); }
  function fetchChats() {
    return call("POST", "admin/support/threads", {}).then(function (threads) {
      return Promise.all(threads.map(function (t) {
        return call("POST", "admin/support/messages", { user_id: t.user_id }).then(function (msgs) {
          return { id: t.user_id, uid: t.user ? t.user.uid : "", name: t.user ? t.user.name : "User", online: true,
            messages: msgs.map(function (m) { return { mid: m.id, from: m.sender === "admin" ? "admin" : "user", text: m.file_url ? (m.body ? m.body + " " : "") + "[" + m.file + "] " + m.file_url : m.body, image: m.image || "", file: m.file || "", time: hm(m.created_at) }; }),
            time: hm(t.created_at), unread: 0 };
        });
      }));
    });
  }
  function wireSupport() {
    if (typeof window.renderChats !== "function") return;
    var seen = {};
    function sync(first) {
      return fetchChats().then(function (list) {
        var openId = null;
        try { if (currentChatIdx !== null && CHATS[currentChatIdx]) openId = CHATS[currentChatIdx].id; } catch (_) {}
        list.forEach(function (c) {
          var last = c.messages[c.messages.length - 1];
          var key = last ? last.mid : "";
          if (!first && seen[c.id] !== key && c.id !== openId && last && last.from === "user") c.unread = 1;
          else { try { var old = CHATS.find(function (o) { return o.id === c.id; }); if (old && old.unread && c.id !== openId) c.unread = old.unread; } catch (_) {} }
          seen[c.id] = key;
        });
        try {
          CHATS = list;
          currentChatIdx = openId ? list.findIndex(function (c) { return c.id === openId; }) : null;
          if (currentChatIdx === -1) currentChatIdx = null;
        } catch (_) {}
        window.renderChats();
        try { if (currentChatIdx !== null) { window.renderMessages(); } } catch (_) {}
        var el = document.getElementById("connStatus"); if (el) el.textContent = "Live • Connected";
      }).catch(function () {});
    }
    window.loadChats = function () { return sync(false); };
    window.saveChats = function () {};
    window.sendMessage = function () {
      var c; try { c = CHATS[currentChatIdx]; } catch (_) {}
      var input = document.getElementById("msgInput");
      var text = (input && input.value || "").trim();
      if (!c || !text) return;
      c.messages.push({ from: "admin", text: text, time: hm(new Date().toISOString()) });
      input.value = ""; try { autoResize(input); } catch (_) {}
      window.renderMessages(); try { scrollChatBottom(); } catch (_) {}
      call("POST", "admin/support/reply", { user_id: c.id, text: text }).then(function () { sync(false); })
        .catch(function (e) { toast("Message failed: " + e.message); });
    };
    window.handleImage = function (input) {
      var c; try { c = CHATS[currentChatIdx]; } catch (_) {}
      var f = input && input.files && input.files[0];
      if (!c || !f) return;
      if (f.size > 5 * 1024 * 1024) { toast("Image too large (max 5MB)"); input.value = ""; return; }
      var fr = new FileReader();
      fr.onload = function () {
        call("POST", "admin/support/reply", { user_id: c.id, text: "", attachment: String(fr.result || ""), file_name: f.name })
          .then(function () { toast("Image sent!"); sync(false); }).catch(function (e) { toast("Image failed: " + e.message); });
      };
      fr.readAsDataURL(f); input.value = "";
    };
    sync(true);
    setInterval(function () { sync(false); }, 4000);
  }

  /* Locked accounts stay hidden; this button switches the list between active and locked members. */
  function lockBtnLabel() {
    var b = document.getElementById("pxLockedBtn"); if (!b) return;
    b.textContent = window.__PX_SHOW_LOCKED ? "\u2190 Active Members" : "\uD83D\uDD12 Locked Accounts (" + (window.__PX_LOCKED_N || 0) + ")";
  }
  function wireLockedBtn() {
    if (typeof window.loadUsers !== "function" || document.getElementById("pxLockedBtn")) return;
    var b = document.createElement("button");
    b.id = "pxLockedBtn"; b.type = "button";
    b.style.cssText = "position:fixed;right:14px;bottom:84px;z-index:9999;padding:10px 14px;border:0;border-radius:22px;font:600 13px system-ui,sans-serif;color:#fff;background:linear-gradient(135deg,#ef4444,#b91c1c);box-shadow:0 6px 18px rgba(0,0,0,.35);cursor:pointer";
    b.onclick = function () { window.__PX_SHOW_LOCKED = !window.__PX_SHOW_LOCKED; lockBtnLabel(); try { window.loadUsers(); } catch (_) {} };
    document.body.appendChild(b); lockBtnLabel();
  }

  function onReady(fn) {
    if (document.readyState !== "loading") setTimeout(fn, 0);
    else document.addEventListener("DOMContentLoaded", fn);
  }
  var path = window.__PREDX_PAGE__ || "index";
  var isLogin = path === "index" || path === "admin-login";

  onReady(function () {
    wire();
    if (isLogin) {
      if (tok()) location.href = R("admin-dashboard");
      return;
    }
    if (!tok()) { location.href = R("index"); return; }
    if (/wallet/.test(path)) { overrideWalletSave(); wireQrUpload(); }
    if (path === "admin-support") { wireSupport(); return; }
    wireLockedBtn();
    try { if (typeof window.loadUsers === "function") window.loadUsers(); } catch (_) {}
    try { if (typeof window.loadDeposits === "function") window.loadDeposits(); } catch (_) {}
    try { if (typeof window.loadWithdraws === "function") window.loadWithdraws(); } catch (_) {}
    try { if (typeof window.loadRequests === "function") window.loadRequests(); } catch (_) {}
    try { if (typeof window.loadCodes === "function") window.loadCodes(); } catch (_) {}
    try { if (typeof window.loadProfile === "function") window.loadProfile(); } catch (_) {}
    try { if (typeof window.loadStats === "function") window.loadStats(); } catch (_) {}
    try { if (typeof window.loadAgents === "function") window.loadAgents(); } catch (_) {}
  });
})();
